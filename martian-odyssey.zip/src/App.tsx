/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useState } from 'react';
import Navbar, { type ModalContext } from './components/Navbar';
import HeroSection from './components/HeroSection';
import CapabilitiesSection from './components/CapabilitiesSection';
import MissionsSection from './components/MissionsSection';
import MarsModelSection from './components/MarsModelSection';
import ExploreSection from './components/ExploreSection';
import LaunchModal from './components/LaunchModal';
import SimulatorApp from './simulator/SimulatorApp';
import type { SiteId } from './simulator/data/marsSites';

type AppRouteView = 'home' | SiteId;

function getRouteFromPathname(pathname: string): AppRouteView {
  const normalized = pathname.replace(/\/+$/, '') || '/';
  if (normalized === '/jezero-crater') return 'jezero';
  if (normalized === '/candor-chasma') return 'candor';
  return 'home';
}

function getPathnameFromRoute(route: AppRouteView): string {
  if (route === 'jezero') return '/jezero-crater';
  if (route === 'candor') return '/candor-chasma';
  return '/';
}

export default function App() {
  const [modalContext, setModalContext] = useState<ModalContext | null>(null);
  const [routeView, setRouteView] = useState<AppRouteView>(() =>
    getRouteFromPathname(window.location.pathname)
  );

  useEffect(() => {
    const handlePopState = () => {
      setRouteView(getRouteFromPathname(window.location.pathname));
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigateToView = useCallback((nextView: AppRouteView) => {
    const nextPath = getPathnameFromRoute(nextView);
    if (window.location.pathname !== nextPath) {
      window.history.pushState({}, '', nextPath);
    }
    setRouteView(nextView);
    if (nextView === 'home') {
      window.scrollTo({ top: 0, behavior: 'auto' });
    }
  }, []);

  if (routeView === 'jezero' || routeView === 'candor') {
    return (
      <SimulatorApp
        initialSiteId={routeView}
        onSiteChange={(id) => navigateToView(id)}
        onBackToHome={() => navigateToView('home')}
      />
    );
  }

  return (
    <div className="min-h-screen w-full overflow-x-hidden bg-[#050608] font-sans text-white">
      <Navbar onOpenModal={setModalContext} />

      <main>
        <HeroSection onOpenModal={setModalContext} />
        <CapabilitiesSection onOpenModal={setModalContext} />
        <MissionsSection onNavigateToSite={(siteId) => navigateToView(siteId)} />
        <MarsModelSection />
        <ExploreSection />
      </main>

      <LaunchModal
        context={modalContext}
        onClose={() => setModalContext(null)}
        onSwitchContext={(ctx) => setModalContext(ctx)}
      />
    </div>
  );
}

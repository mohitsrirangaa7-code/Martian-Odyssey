import { useState, type FormEvent } from 'react';
import { X, Check } from 'lucide-react';
import type { ModalContext } from './Navbar';

interface LaunchModalProps {
  context: ModalContext | null;
  onClose: () => void;
  onSwitchContext: (ctx: ModalContext) => void;
}

export default function LaunchModal({ context, onClose, onSwitchContext }: LaunchModalProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [transit, setTransit] = useState('Jezero Crater');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!context) return null;

  const resetAndClose = () => {
    setError('');
    setSubmitted(false);
    setName('');
    setEmail('');
    setTransit('Jezero Crater');
    setNotes('');
    onClose();
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please enter your name or organization.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError('Please enter a valid contact email address.');
      return;
    }
    setError('');
    setSubmitted(true);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-4 py-6"
      onClick={resetAndClose}
    >
      <div
        className="relative w-full max-w-lg border border-white/20 bg-[#080A0E] p-6 text-white shadow-2xl sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          aria-label="Close modal"
          onClick={resetAndClose}
          className="absolute top-4 right-4 flex h-9 w-9 cursor-pointer items-center justify-center border border-white/15 text-white/70 transition-colors hover:border-white/50 hover:text-white"
        >
          <X className="h-4 w-4" />
        </button>

        {context.type === 'info' && (
          <div>
            <h3 className="font-pixel text-2xl tracking-wide text-white uppercase">
              {context.title}
            </h3>
            <p className="mt-2 text-xs text-white/65">{context.subtitle}</p>
            <div className="mt-6 divide-y divide-white/10 border-t border-b border-white/10">
              {context.items.map((item) => (
                <div key={item.name} className="py-4">
                  <p className="text-sm font-medium text-white">{item.name}</p>
                  <p className="mt-1 text-xs leading-relaxed text-white/60">{item.detail}</p>
                </div>
              ))}
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => onSwitchContext({ type: 'contact' })}
                className="cursor-pointer bg-white px-5 py-2 text-xs font-medium text-[#050608] hover:bg-white/90"
              >
                Get in Touch
              </button>
            </div>
          </div>
        )}

        {context.type === 'mission' && (
          <div>
            <p className="font-mono text-[11px] tracking-widest text-teal-300/80 uppercase">
              MISSION MANIFEST · ST-3
            </p>
            <h3 className="font-pixel mt-2 text-2xl tracking-wide text-white uppercase">
              Aurora 1 — Mission ST-3
            </h3>
            <p className="mt-3 text-xs leading-relaxed text-white/75">
              Following SpectraSat&apos;s orbital insertion around Mars, Aurora 1 — Mission ST-3
              launches in August 2025 to deploy modular deep-space relays and validate reusable
              upper-stage recovery.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-4 border-t border-b border-white/10 py-4">
              <div>
                <p className="text-[11px] text-white/45 uppercase">Launch Window</p>
                <p className="font-mono mt-1 text-sm text-white">August 2025</p>
              </div>
              <div>
                <p className="text-[11px] text-white/45 uppercase">Vehicle</p>
                <p className="font-mono mt-1 text-sm text-white">Aurora 1 Reusable</p>
              </div>
              <div>
                <p className="text-[11px] text-white/45 uppercase">Primary Payload</p>
                <p className="font-mono mt-1 text-sm text-white">SpectraSat Node-2</p>
              </div>
              <div>
                <p className="text-[11px] text-white/45 uppercase">Cost Reduction</p>
                <p className="font-mono mt-1 text-sm text-white tabular-nums">30% via Reuse</p>
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={resetAndClose}
                className="cursor-pointer border border-white/20 px-4 py-2 text-xs text-white/80 hover:border-white/50 hover:text-white"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => onSwitchContext({ type: 'launch', preset: 'Aurora 1 — Mission ST-3' })}
                className="cursor-pointer bg-white px-5 py-2 text-xs font-medium text-[#050608] hover:bg-white/90"
              >
                Book Rideshare Slot
              </button>
            </div>
          </div>
        )}

        {(context.type === 'launch' || context.type === 'contact') && (
          <div>
            {submitted ? (
              <div className="py-6 text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full border border-teal-400/50 bg-teal-400/10 text-teal-300">
                  <Check className="h-5 w-5" />
                </div>
                <h3 className="font-pixel mt-4 text-2xl text-white uppercase">
                  {context.type === 'launch' ? 'Launch Inquiry Received' : 'Message Sent'}
                </h3>
                <p className="mt-2 text-xs leading-relaxed text-white/70">
                  Our mission operations team will review your request for{' '}
                  <span className="text-white">{name}</span> and respond at{' '}
                  <span className="text-white">{email}</span>.
                </p>
                <button
                  type="button"
                  onClick={resetAndClose}
                  className="mt-6 cursor-pointer bg-white px-6 py-2 text-xs font-medium text-[#050608] hover:bg-white/90"
                >
                  Done
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate>
                <h3 className="font-pixel text-2xl tracking-wide text-white uppercase">
                  {context.type === 'launch' ? 'Book a Launch' : 'Contact Mission Control'}
                </h3>
                <p className="mt-1 text-xs text-white/60">
                  {context.type === 'launch'
                    ? context.preset
                      ? `Selected configuration: ${context.preset}`
                      : 'Reserve dedicated or rideshare orbital delivery on Aurora Rockets.'
                    : 'Reach our engineering and commercial mission team.'}
                </p>

                <div className="mt-5 space-y-4">
                  <div>
                    <label htmlFor="cw-name" className="block text-[11px] text-white/60 uppercase">
                      Name / Organization
                    </label>
                    <input
                      id="cw-name"
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Dr. Elena Vance · Orbital Lab"
                      className="mt-1.5 w-full border border-white/20 bg-[#050608] px-3 py-2 text-xs text-white placeholder:text-white/30 focus:border-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor="cw-email" className="block text-[11px] text-white/60 uppercase">
                      Email Address
                    </label>
                    <input
                      id="cw-email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="mission@organization.org"
                      className="mt-1.5 w-full border border-white/20 bg-[#050608] px-3 py-2 text-xs text-white placeholder:text-white/30 focus:border-white focus:outline-none"
                    />
                  </div>

                  {context.type === 'launch' && (
                    <div>
                      <label
                        htmlFor="cw-transit"
                        className="block text-[11px] text-white/60 uppercase"
                      >
                        Choose Your Transit
                      </label>
                      <select
                        id="cw-transit"
                        value={transit}
                        onChange={(e) => setTransit(e.target.value)}
                        className="mt-1.5 w-full border border-white/20 bg-[#050608] px-3 py-2 text-xs text-white focus:border-white focus:outline-none"
                      >
                        <option>Jezero Crater</option>
                        <option>Valles Marineris</option>
                      </select>
                    </div>
                  )}

                  {context.type === 'contact' && (
                    <div>
                      <label htmlFor="cw-notes" className="block text-[11px] text-white/60 uppercase">
                        Message
                      </label>
                      <textarea
                        id="cw-notes"
                        rows={3}
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="Tell us about your mission or partnership inquiry..."
                        className="mt-1.5 w-full border border-white/20 bg-[#050608] px-3 py-2 text-xs text-white placeholder:text-white/30 focus:border-white focus:outline-none"
                      />
                    </div>
                  )}

                  {error && <p className="text-xs text-rose-400">{error}</p>}
                </div>

                <div className="mt-6 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={resetAndClose}
                    className="cursor-pointer border border-white/20 px-4 py-2 text-xs text-white/75 hover:border-white/50 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="cursor-pointer bg-white px-6 py-2 text-xs font-medium text-[#050608] hover:bg-white/90"
                  >
                    {context.type === 'launch' ? 'Submit Launch Request' : 'Send Message'}
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Maximize2, Minimize2, RotateCcw } from 'lucide-react';

interface MarsWaypoint {
  id: 'global' | 'jezero' | 'valles';
  name: string;
  lat: number;
  lon: number;
  distance: number;
  coordinates: string;
  elevation: string;
  summary: string;
}

const WAYPOINTS: MarsWaypoint[] = [
  {
    id: 'global',
    name: 'Mars Global Orbit',
    lat: 12,
    lon: 18,
    distance: 4.15,
    coordinates: '0.00° N · 0.00° E',
    elevation: 'Radius 3,389.5 km',
    summary: 'Drag to rotate and scroll to zoom across NASA high-resolution Martian orbital topography.',
  },
  {
    id: 'jezero',
    name: 'Jezero Crater',
    lat: 18.38,
    lon: 77.58,
    distance: 2.55,
    coordinates: '18.38° N · 77.58° E',
    elevation: '-2,569 m Datum',
    summary: 'Ancient river delta basin selected for MarsWalk astrobiology sampling and surface traverses.',
  },
  {
    id: 'valles',
    name: 'Valles Marineris',
    lat: -13.9,
    lon: 300.8,
    distance: 2.65,
    coordinates: '13.90° S · 300.80° E',
    elevation: '-7,000 m Canyon Floor',
    summary: '4,000 km tectonic canyon system exposing deep Martian crust stratigraphy.',
  },
];

const MARS_RADIUS = 1.35;

/**
 * Converts Martian planetocentric latitude/longitude (deg East) into
 * the exact 3D unit vector matching NASA's Mars_1_6792.glb UV orientation.
 */
function latLonToMarsDir(latDeg: number, lonDeg: number): THREE.Vector3 {
  const normalizedLon = ((((lonDeg + 180) % 360) + 360) % 360) - 180;
  const u = (normalizedLon + 180) / 360;
  const alpha = -Math.PI / 4 - u * Math.PI * 2;
  const latRad = (latDeg * Math.PI) / 180;

  return new THREE.Vector3(
    Math.cos(latRad) * Math.cos(alpha),
    Math.sin(latRad),
    Math.cos(latRad) * Math.sin(alpha),
  ).normalize();
}

// Pre-allocated math helpers outside render loop
const _targetSunPos = new THREE.Vector3();
const _currentDir = new THREE.Vector3();
const _nextPos = new THREE.Vector3();
const _mouse = new THREE.Vector2();

export default function MarsModelSection() {
  const [activeWaypoint, setActiveWaypoint] = useState<MarsWaypoint>(WAYPOINTS[0]);
  const [expanded, setExpanded] = useState(false);
  const [modelLoaded, setModelLoaded] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const canvasMountRef = useRef<HTMLDivElement>(null);
  const flyToFnRef = useRef<((wp: MarsWaypoint) => void) | null>(null);
  const resizeFnRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = mount.clientWidth || 800;
    const height = mount.clientHeight || 460;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x050608);

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    const initialDir = latLonToMarsDir(WAYPOINTS[0].lat, WAYPOINTS[0].lon);
    camera.position.copy(initialDir).multiplyScalar(WAYPOINTS[0].distance);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    mount.appendChild(renderer.domElement);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTexture = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTexture;
    pmremGenerator.dispose();

    // Solar & space lighting rig tuned for NASA's Mars_1_6792.glb PBR surface
    const hemiLight = new THREE.HemisphereLight(0xaec8ff, 0x26120c, 0.75);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfff5e8, 2.4);
    sunLight.position.copy(initialDir).multiplyScalar(6).add(new THREE.Vector3(2.2, 1.8, 1.5));
    scene.add(sunLight);

    const rimLight = new THREE.DirectionalLight(0x5eead4, 0.4);
    rimLight.position.set(-4, -2, -5);
    scene.add(rimLight);

    const marsGroup = new THREE.Group();
    scene.add(marsGroup);

    // Subtle Atmospheric Limb Halo around Mars
    const atmoGeo = new THREE.SphereGeometry(MARS_RADIUS * 1.028, 48, 36);
    const atmoMat = new THREE.MeshBasicMaterial({
      color: 0xd97757,
      transparent: true,
      opacity: 0.09,
      side: THREE.BackSide,
      depthWrite: false,
    });
    const atmoMesh = new THREE.Mesh(atmoGeo, atmoMat);
    marsGroup.add(atmoMesh);

    // Subtle Orbital Reticle Rings matching website HUD
    const orbitRingGeo = new THREE.RingGeometry(MARS_RADIUS * 1.31, MARS_RADIUS * 1.316, 128);
    const orbitRingMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.14,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const orbitRing = new THREE.Mesh(orbitRingGeo, orbitRingMat);
    orbitRing.rotation.x = Math.PI / 2 - 0.18;
    marsGroup.add(orbitRing);

    // 3D Surface Waypoint Pins (Composite 3-part markers on NASA's Mars surface)
    const clickablePins: THREE.Object3D[] = [];
    const pinMeshes: Record<
      string,
      { group: THREE.Group; ringMat: THREE.MeshBasicMaterial; tipMat: THREE.MeshBasicMaterial }
    > = {};

    const pinBaseGeo = new THREE.RingGeometry(0.028, 0.044, 32);
    const pinMastGeo = new THREE.CylinderGeometry(0.004, 0.004, 0.095, 8);
    const pinTipGeo = new THREE.SphereGeometry(0.018, 16, 12);
    const pinHitGeo = new THREE.SphereGeometry(0.11, 12, 10);
    const pinHitMat = new THREE.MeshBasicMaterial({ visible: false });

    WAYPOINTS.filter((wp) => wp.id !== 'global').forEach((wp) => {
      const normal = latLonToMarsDir(wp.lat, wp.lon);
      // Slight polar flattening match (497.055 / 500 = 0.9941)
      const surfacePos = new THREE.Vector3(
        normal.x * MARS_RADIUS,
        normal.y * MARS_RADIUS * 0.9941,
        normal.z * MARS_RADIUS,
      );

      const pinGroup = new THREE.Group();
      pinGroup.position.copy(surfacePos);
      pinGroup.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normal);

      const ringMat = new THREE.MeshBasicMaterial({
        color: 0x5eead4,
        transparent: true,
        opacity: 0.8,
        side: THREE.DoubleSide,
      });
      const baseRing = new THREE.Mesh(pinBaseGeo, ringMat);
      baseRing.rotation.x = -Math.PI / 2;
      baseRing.position.y = 0.01;
      pinGroup.add(baseRing);

      const mastMat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        roughness: 0.35,
        metalness: 0.8,
      });
      const mast = new THREE.Mesh(pinMastGeo, mastMat);
      mast.position.y = 0.052;
      pinGroup.add(mast);

      const tipMat = new THREE.MeshBasicMaterial({ color: 0x5eead4 });
      const tip = new THREE.Mesh(pinTipGeo, tipMat);
      tip.position.y = 0.105;
      pinGroup.add(tip);

      const hitProxy = new THREE.Mesh(pinHitGeo, pinHitMat);
      hitProxy.position.y = 0.055;
      hitProxy.userData.waypoint = wp;
      pinGroup.add(hitProxy);
      clickablePins.push(hitProxy);

      marsGroup.add(pinGroup);
      pinMeshes[wp.id] = { group: pinGroup, ringMat, tipMat };
    });

    // Subtle Starfield
    const starCount = 300;
    const starPositions = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const r = 18 + Math.random() * 14;
      starPositions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      starPositions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      starPositions[i * 3 + 2] = r * Math.cos(phi);
    }
    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    const starMat = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.065,
      transparent: true,
      opacity: 0.5,
    });
    const stars = new THREE.Points(starGeo, starMat);
    scene.add(stars);

    // Load exact NASA Mars_1_6792.glb model
    let loadedMarsRoot: THREE.Object3D | null = null;
    const maxAniso = renderer.capabilities.getMaxAnisotropy();
    const gltfLoader = new GLTFLoader();

    gltfLoader.load(
      '/assets/mars/Mars_1_6792.glb',
      (gltf) => {
        if (disposed) return;
        const model = gltf.scene;
        // Scale from NASA radius 500 down to MARS_RADIUS (1.35)
        model.scale.setScalar(MARS_RADIUS / 500);
        model.traverse((child) => {
          if ((child as THREE.Mesh).isMesh) {
            const mesh = child as THREE.Mesh;
            const mat = mesh.material as THREE.MeshStandardMaterial;
            if (mat) {
              if (mat.map) {
                mat.map.colorSpace = THREE.SRGBColorSpace;
                mat.map.anisotropy = maxAniso;
              }
              if (mat.normalMap) {
                mat.normalMap.anisotropy = maxAniso;
              }
              mat.envMapIntensity = 0.25;
              mat.needsUpdate = true;
            }
          }
        });
        loadedMarsRoot = model;
        marsGroup.add(model);
        setModelLoaded(true);
        requestRender();
      },
      undefined,
      () => {
        if (!disposed) {
          setLoadError('Unable to load Mars 3D asset.');
        }
      },
    );

    // OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enablePan = false;
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.06;
    controls.minDistance = 1.95;
    controls.maxDistance = 6.2;
    controls.rotateSpeed = 0.65;
    controls.zoomSpeed = 0.85;

    // Camera Fly-To Transition State
    let isFlying = false;
    let targetDist = WAYPOINTS[0].distance;
    const targetSphericalDir = new THREE.Vector3().copy(initialDir);
    let lastTime = performance.now();

    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let disposed = false;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function requestRender() {
      if (disposed) return;
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame(() => {
        if (disposed) return;
        renderDirty = false;

        const now = performance.now();
        const delta = Math.min((now - lastTime) / 1000, 0.1);
        lastTime = now;

        let needsMoreFrames = false;

        if (isFlying) {
          const currentDist = camera.position.length();
          _currentDir.copy(camera.position).normalize();
          const t = 1 - Math.exp(-5.5 * delta);

          _currentDir.lerp(targetSphericalDir, t).normalize();
          const nextDist = THREE.MathUtils.lerp(currentDist, targetDist, t);

          _nextPos.copy(_currentDir).multiplyScalar(nextDist);
          camera.position.copy(_nextPos);

          _targetSunPos
            .copy(_currentDir)
            .multiplyScalar(6)
            .add(new THREE.Vector3(2.2, 1.8, 1.5));
          sunLight.position.lerp(_targetSunPos, t);

          const angleErr = _currentDir.angleTo(targetSphericalDir);
          const distErr = Math.abs(nextDist - targetDist);
          if (angleErr < 0.0025 && distErr < 0.005) {
            camera.position.copy(targetSphericalDir).multiplyScalar(targetDist);
            isFlying = false;
          } else {
            needsMoreFrames = true;
          }
        }

        const controlsChanged = controls.update();
        if (controlsChanged) needsMoreFrames = true;

        renderer.render(scene, camera);

        const done = () => {
          renderBusy = false;
          if (!disposed && (renderDirty || needsMoreFrames)) {
            requestRender();
          }
        };

        if (isSoftwareGl) afterDraw(done);
        else done();
      });
    }

    function updatePinHighlights(activeId: string) {
      Object.entries(pinMeshes).forEach(([id, entry]) => {
        const isActive = id === activeId;
        entry.group.scale.setScalar(isActive ? 1.35 : 1.0);
        entry.ringMat.color.setHex(isActive ? 0xffffff : 0x5eead4);
        entry.ringMat.opacity = isActive ? 1.0 : 0.75;
        entry.tipMat.color.setHex(isActive ? 0xffffff : 0x5eead4);
      });
    }

    function flyToWaypoint(wp: MarsWaypoint) {
      targetSphericalDir.copy(latLonToMarsDir(wp.lat, wp.lon));
      targetDist = wp.distance;
      isFlying = true;
      lastTime = performance.now();
      updatePinHighlights(wp.id);
      requestRender();
    }

    flyToFnRef.current = flyToWaypoint;

    const handleControlsStart = () => {
      isFlying = false;
    };
    const handleControlsChange = () => {
      requestRender();
    };
    controls.addEventListener('start', handleControlsStart);
    controls.addEventListener('change', handleControlsChange);

    // Raycast click on 3D surface pins
    const raycaster = new THREE.Raycaster();
    let pointerDownPos = { x: 0, y: 0 };

    const onPointerDown = (e: PointerEvent) => {
      pointerDownPos = { x: e.clientX, y: e.clientY };
    };

    const onPointerUp = (e: PointerEvent) => {
      const moved = Math.hypot(e.clientX - pointerDownPos.x, e.clientY - pointerDownPos.y);
      if (moved > 6) return;

      const rect = renderer.domElement.getBoundingClientRect();
      _mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      _mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(_mouse, camera);
      const hits = raycaster.intersectObjects(clickablePins, false);
      if (hits.length > 0) {
        const wp = hits[0].object.userData.waypoint as MarsWaypoint | undefined;
        if (wp) {
          setActiveWaypoint(wp);
          flyToWaypoint(wp);
        }
      }
    };

    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    renderer.domElement.addEventListener('pointerup', onPointerUp);

    const handleResize = () => {
      if (!mount || disposed) return;
      const w = mount.clientWidth || 800;
      const h = mount.clientHeight || 460;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      requestRender();
    };
    resizeFnRef.current = handleResize;
    window.addEventListener('resize', handleResize);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }
    updatePinHighlights(WAYPOINTS[0].id);
    requestRender();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', handleResize);
      controls.removeEventListener('start', handleControlsStart);
      controls.removeEventListener('change', handleControlsChange);
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.domElement.removeEventListener('pointerup', onPointerUp);
      controls.dispose();
      if (loadedMarsRoot) {
        loadedMarsRoot.traverse((child) => {
          const mesh = child as THREE.Mesh;
          if (mesh.isMesh) {
            mesh.geometry.dispose();
            const mat = mesh.material as THREE.MeshStandardMaterial;
            if (mat) {
              mat.map?.dispose();
              mat.normalMap?.dispose();
              mat.dispose();
            }
          }
        });
      }
      atmoGeo.dispose();
      atmoMat.dispose();
      orbitRingGeo.dispose();
      orbitRingMat.dispose();
      pinBaseGeo.dispose();
      pinMastGeo.dispose();
      pinTipGeo.dispose();
      pinHitGeo.dispose();
      pinHitMat.dispose();
      starGeo.dispose();
      starMat.dispose();
      envTexture.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === mount) {
        mount.removeChild(renderer.domElement);
      }
    };
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      resizeFnRef.current?.();
    }, 320);
    return () => window.clearTimeout(timer);
  }, [expanded]);

  const handleSelectWaypoint = (wp: MarsWaypoint) => {
    setActiveWaypoint(wp);
    flyToFnRef.current?.(wp);
  };

  const handleReset = () => {
    setActiveWaypoint(WAYPOINTS[0]);
    flyToFnRef.current?.(WAYPOINTS[0]);
  };

  return (
    <section
      id="mars-3d-model"
      className="mx-auto w-full max-w-[1440px] border-t border-white/10 px-6 py-24 md:px-10 md:py-32"
    >
      {/* Section Header matching Cosmic Witness / MarsWalk Pixel Typography */}
      <div className="mx-auto max-w-2xl text-center">
        <h2 className="font-pixel text-4xl leading-[1.02] tracking-wide text-white uppercase sm:text-5xl md:text-[54px]">
          MARS 3D
          <br />
          EXPLORER
        </h2>
        <p className="mt-4 text-xs leading-relaxed text-white/75 sm:text-sm">
          Interactive Martian globe powered by NASA Solar System 3D telemetry.
          <br />
          Select a destination to navigate the 3D surface camera.
        </p>
      </div>

      {/* Formatted 3D Viewport Container */}
      <div className="mx-auto mt-12 max-w-5xl">
        {/* Top Telemetry & Waypoint Controls Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 border border-b-0 border-white/15 bg-[#080A0E] px-4 py-3 sm:px-6">
          <div className="flex flex-wrap items-center gap-2">
            {WAYPOINTS.map((wp) => {
              const isActive = activeWaypoint.id === wp.id;
              return (
                <button
                  key={wp.id}
                  type="button"
                  onClick={() => handleSelectWaypoint(wp)}
                  className={`cursor-pointer whitespace-nowrap px-3 py-1.5 text-[11px] tracking-wide transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white ${
                    isActive
                      ? 'bg-white font-medium text-[#050608]'
                      : 'border border-white/15 text-white/70 hover:border-white/40 hover:text-white'
                  }`}
                >
                  {wp.name}
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleReset}
              aria-label="Reset 3D Mars view"
              className="flex cursor-pointer items-center gap-1.5 whitespace-nowrap border border-white/15 px-3 py-1.5 text-[11px] text-white/75 transition-colors hover:border-white/45 hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
            >
              <RotateCcw className="h-3 w-3" />
              <span>Reset</span>
            </button>
            <button
              type="button"
              onClick={() => setExpanded((prev) => !prev)}
              aria-label={expanded ? 'Collapse 3D viewport' : 'Expand 3D viewport'}
              className="flex cursor-pointer items-center gap-1.5 whitespace-nowrap border border-white/15 px-3 py-1.5 text-[11px] text-white/75 transition-colors hover:border-white/45 hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
            >
              {expanded ? <Minimize2 className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
              <span>{expanded ? 'Compact' : 'Expand'}</span>
            </button>
          </div>
        </div>

        {/* 3D Canvas Aperture with HUD Corner Reticles */}
        <div className="relative overflow-hidden border border-white/15 bg-[#050608]">
          {/* Precision HUD Corner Brackets */}
          <span
            aria-hidden="true"
            className="pointer-events-none absolute top-3 left-3 z-20 h-4 w-4 border-t border-l border-teal-300/60"
          />
          <span
            aria-hidden="true"
            className="pointer-events-none absolute top-3 right-3 z-20 h-4 w-4 border-t border-r border-teal-300/60"
          />
          <span
            aria-hidden="true"
            className="pointer-events-none absolute bottom-3 left-3 z-20 h-4 w-4 border-b border-l border-teal-300/60"
          />
          <span
            aria-hidden="true"
            className="pointer-events-none absolute right-3 bottom-3 z-20 h-4 w-4 border-r border-b border-teal-300/60"
          />

          {/* Loading / Error State Overlay */}
          {!modelLoaded && !loadError && (
            <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center">
              <span className="font-mono text-xs tracking-widest text-white/60 uppercase">
                Loading NASA Mars 3D Model...
              </span>
            </div>
          )}
          {loadError && (
            <div className="absolute inset-0 z-10 flex items-center justify-center">
              <span className="font-mono text-xs text-rose-400">{loadError}</span>
            </div>
          )}

          {/* Isolated Three.js Canvas Mount */}
          <div
            ref={canvasMountRef}
            aria-label="Interactive NASA 3D Mars globe"
            className={`w-full cursor-grab active:cursor-grabbing transition-[height] duration-300 ${
              expanded ? 'h-[620px]' : 'h-[460px]'
            }`}
          />
        </div>

        {/* Bottom Coordinate & Target Brief Bar */}
        <div className="flex flex-col justify-between gap-3 border border-t-0 border-white/15 bg-[#080A0E] px-4 py-3.5 sm:flex-row sm:items-center sm:px-6">
          <p className="text-xs text-white/75">{activeWaypoint.summary}</p>
          <div className="font-mono flex shrink-0 items-center gap-3 text-[11px] text-white/55 tabular-nums">
            <span>{activeWaypoint.coordinates}</span>
            <span aria-hidden="true">/</span>
            <span className="text-teal-300/80">{activeWaypoint.elevation}</span>
          </div>
        </div>
      </div>
    </section>
  );
}

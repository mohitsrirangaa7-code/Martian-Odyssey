interface ShowcaseSlide {
  id: string;
  name: string;
  leftCaption: string;
  rightCaption: string;
  orbitTag: string;
}

const DEFAULT_SLIDE: ShowcaseSlide = {
  id: 'spectrasat',
  name: 'SpectraSat Deep-Space Bus',
  leftCaption: 'Pioneering modular spacecraft architectures.',
  rightCaption: 'Expanding the edge of known space.',
  orbitTag: 'Mars Travel Planner: Bon Voyage',
};

export default function ExploreSection() {
  const current = DEFAULT_SLIDE;

  return (
    <section
      id="explore"
      className="mx-auto flex w-full max-w-[1440px] flex-col justify-between border-t border-white/10 px-6 pt-12 pb-10 md:px-10 md:pt-16 md:pb-12"
    >
      {/* Top 3-Word Pixel Display Header */}
      <div className="grid grid-cols-3 items-center gap-2 text-center">
        <span className="font-pixel text-left text-2xl tracking-wider text-white uppercase sm:text-4xl md:text-6xl lg:text-7xl">
          EXPLORE
        </span>
        <span className="font-pixel text-center text-2xl tracking-wider text-white uppercase sm:text-4xl md:text-6xl lg:text-7xl">
          ASCEND
        </span>
        <span className="font-pixel text-right text-2xl tracking-wider text-white uppercase sm:text-4xl md:text-6xl lg:text-7xl">
          BUILD
        </span>
      </div>

      {/* Central Minimalist Spacecraft Wireframe & Reticle Stage (No Background Image) */}
      <div className="relative my-16 flex min-h-[280px] flex-col items-center justify-center md:my-24 md:min-h-[340px]">
        {/* Large Subtle Orbital Target Reticle */}
        <svg
          viewBox="0 0 560 300"
          fill="none"
          className="h-64 w-full max-w-2xl text-white md:h-80"
          aria-label={current.name}
        >
          {/* Faint Outer Reticle Arcs */}
          <circle cx="280" cy="150" r="138" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
          <circle
            cx="280"
            cy="150"
            r="104"
            stroke="rgba(255,255,255,0.12)"
            strokeWidth="0.75"
            strokeDasharray="3 5"
          />

          {/* Spacecraft Schematic Wireframe */}
          <g stroke="rgba(255,255,255,0.75)" strokeWidth="1.1">
            {/* Central Hexagonal Bus */}
            <polygon points="262,130 298,130 306,150 298,170 262,170 254,150" fill="rgba(255,255,255,0.04)" />
            {/* Dish Antenna */}
            <ellipse cx="280" cy="118" rx="14" ry="5" />
            <line x1="280" y1="123" x2="280" y2="130" />
            {/* Left Solar Array Wing */}
            <polygon points="108,176 246,144 246,164 108,196" fill="rgba(255,255,255,0.03)" />
            <line x1="246" y1="152" x2="254" y2="152" />
            <line x1="142" y1="168" x2="142" y2="188" strokeOpacity="0.4" />
            <line x1="176" y1="160" x2="176" y2="180" strokeOpacity="0.4" />
            <line x1="210" y1="152" x2="210" y2="172" strokeOpacity="0.4" />
            {/* Right Solar Array Wing */}
            <polygon points="314,136 452,104 452,124 314,156" fill="rgba(255,255,255,0.03)" />
            <line x1="306" y1="148" x2="314" y2="148" />
            <line x1="348" y1="128" x2="348" y2="148" strokeOpacity="0.4" />
            <line x1="382" y1="120" x2="382" y2="140" strokeOpacity="0.4" />
            <line x1="416" y1="112" x2="416" y2="132" strokeOpacity="0.4" />
          </g>
        </svg>

        <p className="font-mono mt-4 text-[10px] tracking-[0.2em] text-white/45">
          {current.orbitTag}
        </p>
      </div>

      {/* Bottom Captions Row */}
      <div className="grid grid-cols-1 items-center gap-4 border-t border-white/10 pt-6 md:grid-cols-3">
        <p className="text-center text-[11px] text-white/60 md:text-left">
          {current.leftCaption}
        </p>

        <p className="text-center text-[11px] text-white/60 md:col-start-3 md:text-right">
          {current.rightCaption}
        </p>
      </div>
    </section>
  );
}

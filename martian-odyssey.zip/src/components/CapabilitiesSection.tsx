import { useState } from 'react';
import { X } from 'lucide-react';
import type { ModalContext } from './Navbar';

interface CapabilityItem {
  id: string;
  title: string;
  subtitle: string;
  size: 'sm' | 'lg';
  summary: string;
  specs: { label: string; value: string }[];
}

const CAPABILITIES: CapabilityItem[] = [
  {
    id: 'science-missions',
    title: 'Science Missions',
    subtitle: 'From Earth to Mars',
    size: 'lg',
    summary:
      'Turnkey deep-space science buses supporting lunar surface relays, heliophysics payloads, and sustained Martian orbital instrumentation.',
    specs: [
      { label: 'Target Reach', value: 'Lunar & Martian Orbit' },
      { label: 'Payload Mass', value: 'Up to 850 kg' },
      { label: 'Data Downlink', value: 'Ka-Band 320 Mbps' },
    ],
  },
  {
    id: 'satellites-spectra',
    title: 'Scientific Research',
    subtitle: 'Platform to Perform Science Research on a Planet away from Home!',
    size: 'lg',
    summary:
      'Modular flight-proven SpectraSat spacecraft platforms ready for rapid payload integration across Earth observation and planetary imaging.',
    specs: [
      { label: 'Bus Architecture', value: 'Spectra-M Modular' },
      { label: 'Power Array', value: '4.8 kW GaAs' },
      { label: 'Integration Lead', value: '90 Days' },
    ],
  },
];

interface CapabilitiesSectionProps {
  onOpenModal: (ctx: ModalContext) => void;
}

export default function CapabilitiesSection({ onOpenModal }: CapabilitiesSectionProps) {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const selectedCapability = CAPABILITIES.find((c) => c.id === selectedId) ?? null;

  return (
    <section
      id="capabilities"
      className="mx-auto w-full max-w-[1440px] px-6 py-24 md:px-10 md:py-32"
    >
      {/* Heading & Subtitle */}
      <div className="mx-auto max-w-xl text-center">
        <h2 className="font-pixel text-4xl leading-[1.02] tracking-wide text-white uppercase sm:text-5xl md:text-[54px]">
          OUR
          <br />
          CAPABILITIES
        </h2>
        <p className="mt-4 text-xs leading-relaxed text-white/75 sm:text-sm">
          Innovative space technologies for launch,
          <br />
          orbit, and deep space exploration.
        </p>
      </div>

      {/* 4 Concentric HUD Circular Modules */}
      <div className="mt-16 flex flex-col items-center justify-center gap-6 sm:flex-row sm:flex-wrap lg:flex-nowrap lg:gap-5 xl:gap-8">
        {CAPABILITIES.map((cap) => {
          const isSelected = selectedId === cap.id;
          const sizeClasses =
            cap.size === 'lg'
              ? 'h-60 w-60 sm:h-64 sm:w-64 lg:h-[270px] lg:w-[270px] xl:h-[300px] xl:w-[300px]'
              : 'h-48 w-48 sm:h-52 sm:w-52 lg:h-[210px] lg:w-[210px] xl:h-[230px] xl:w-[230px]';

          return (
            <button
              key={cap.id}
              type="button"
              onClick={() => setSelectedId(isSelected ? null : cap.id)}
              aria-pressed={isSelected}
              className={`group relative flex shrink-0 cursor-pointer items-center justify-center rounded-full transition-transform duration-200 hover:scale-[1.03] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-cyan-400 ${sizeClasses}`}
            >
              {/* Precision Orbital HUD Reticle SVG */}
              <svg
                viewBox="0 0 200 200"
                fill="none"
                className={`pointer-events-none absolute inset-0 h-full w-full transition-transform duration-500 ${
                  isSelected ? 'rotate-45' : 'group-hover:rotate-12'
                }`}
                aria-hidden="true"
              >
                {/* Outer thin hairline circle */}
                <circle
                  cx="100"
                  cy="100"
                  r="95"
                  stroke={isSelected ? 'rgba(94, 234, 212, 0.7)' : 'rgba(255, 255, 255, 0.22)'}
                  strokeWidth="1"
                />
                {/* Inner subtle ring */}
                <circle
                  cx="100"
                  cy="100"
                  r="88"
                  stroke="rgba(255, 255, 255, 0.08)"
                  strokeWidth="0.75"
                  strokeDasharray="2 4"
                />
                {/* 4 Calibrated Telemetry Arc Brackets */}
                <path
                  d="M 55 18 A 93 93 0 0 1 145 18"
                  stroke={isSelected ? '#5EEAD4' : 'rgba(94, 234, 212, 0.45)'}
                  strokeWidth="1.75"
                  strokeLinecap="round"
                />
                <path
                  d="M 182 55 A 93 93 0 0 1 182 145"
                  stroke={isSelected ? '#5EEAD4' : 'rgba(94, 234, 212, 0.45)'}
                  strokeWidth="1.75"
                  strokeLinecap="round"
                />
                <path
                  d="M 145 182 A 93 93 0 0 1 55 182"
                  stroke={isSelected ? '#5EEAD4' : 'rgba(94, 234, 212, 0.45)'}
                  strokeWidth="1.75"
                  strokeLinecap="round"
                />
                <path
                  d="M 18 145 A 93 93 0 0 1 18 55"
                  stroke={isSelected ? '#5EEAD4' : 'rgba(94, 234, 212, 0.45)'}
                  strokeWidth="1.75"
                  strokeLinecap="round"
                />
                {/* Cardinal Tick Marks */}
                <line x1="100" y1="2" x2="100" y2="9" stroke="rgba(255,255,255,0.45)" strokeWidth="1" />
                <line x1="100" y1="191" x2="100" y2="198" stroke="rgba(255,255,255,0.45)" strokeWidth="1" />
                <line x1="2" y1="100" x2="9" y2="100" stroke="rgba(255,255,255,0.45)" strokeWidth="1" />
                <line x1="191" y1="100" x2="198" y2="100" stroke="rgba(255,255,255,0.45)" strokeWidth="1" />
              </svg>

              {/* Center Labels */}
              <div className="relative z-10 flex flex-col items-center px-6 text-center">
                <span className="text-xs font-medium tracking-wide text-white sm:text-sm">
                  {cap.title}
                </span>
                <span className="mt-1 text-[10px] tracking-wide text-white/50 sm:text-[11px]">
                  {cap.subtitle}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Expandable Capability Specification Panel */}
      {selectedCapability && (
        <div className="mx-auto mt-10 max-w-3xl border border-white/15 bg-[#090B10] p-6 transition-opacity duration-200">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-xs tracking-wider text-teal-300/80 uppercase">
                {selectedCapability.subtitle}
              </p>
              <h3 className="mt-1 text-lg font-medium text-white">{selectedCapability.title}</h3>
            </div>
            <button
              type="button"
              aria-label="Close capability details"
              onClick={() => setSelectedId(null)}
              className="flex h-8 w-8 cursor-pointer items-center justify-center border border-white/15 text-white/70 transition-colors hover:border-white/40 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-white/75">
            {selectedCapability.summary}
          </p>
          <div className="mt-5 grid grid-cols-1 gap-4 border-t border-white/10 pt-4 sm:grid-cols-3">
            {selectedCapability.specs.map((spec) => (
              <div key={spec.label}>
                <p className="text-[11px] tracking-wider text-white/45 uppercase">{spec.label}</p>
                <p className="font-mono mt-1 text-sm text-white tabular-nums">{spec.value}</p>
              </div>
            ))}
          </div>
          <div className="mt-5 flex justify-end">
            <button
              type="button"
              onClick={() => onOpenModal({ type: 'launch', preset: selectedCapability.title })}
              className="cursor-pointer bg-white px-5 py-2 text-xs font-medium text-[#050608] transition-colors hover:bg-white/90"
            >
              Request Payload Integration
            </button>
          </div>
        </div>
      )}
    </section>
  );
}

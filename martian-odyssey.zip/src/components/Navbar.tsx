import { useState } from 'react';
import { Menu, X } from 'lucide-react';

export type ModalContext =
  | { type: 'launch'; preset?: string }
  | { type: 'contact' }
  | { type: 'mission' }
  | { type: 'info'; title: string; subtitle: string; items: { name: string; detail: string }[] };

interface NavbarProps {
  onOpenModal: (ctx: ModalContext) => void;
}

export default function Navbar({ onOpenModal }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleScrollTo = (id: string) => {
    setMobileOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="relative z-40 w-full">
      <div className="mx-auto flex max-w-[1440px] items-start justify-between px-6 pt-5 pb-4 md:px-10">
        {/* Left: Circular Shuttle Emblem */}
        <a
          href="#top"
          aria-label="Cosmic Witness Home"
          className="group flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-white/25 bg-[#0A0C10] transition-colors duration-200 hover:border-white/60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
        >
          <svg
            viewBox="0 0 32 32"
            fill="none"
            className="h-6 w-6 text-white transition-transform duration-200 group-hover:scale-105"
            aria-hidden="true"
          >
            <path
              d="M16 4C14.3 6.8 13.5 10.2 13.5 14V20L10 23.5V25.5L13.5 24.2V26.5H18.5V24.2L22 25.5V23.5L18.5 20V14C18.5 10.2 17.7 6.8 16 4Z"
              fill="currentColor"
            />
            <path d="M14.7 10.5H17.3L16 8.2L14.7 10.5Z" fill="#050608" />
            <rect x="14.9" y="13" width="2.2" height="5" rx="0.6" fill="#050608" />
          </svg>
        </a>

        {/* Center-Right: Replaced nav content with simple text */}
        <nav aria-label="Primary navigation" className="hidden md:flex items-center pt-1">
          <span className="text-xs tracking-wide text-white/85">Martian Odyssey</span>
        </nav>

        {/* Right: Contacts */}
        <div className="flex items-center gap-4 pt-0.5">
          <button
            type="button"
            onClick={() => onOpenModal({ type: 'contact' })}
            className="hidden cursor-pointer whitespace-nowrap text-[11px] tracking-wide text-white/85 transition-colors hover:text-white focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white md:inline-block"
          >
            Contact Us
          </button>

          {/* Mobile Menu Toggle */}
          <button
            type="button"
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen(!mobileOpen)}
            className="flex h-10 w-10 cursor-pointer items-center justify-center border border-white/20 text-white md:hidden"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="border-t border-b border-white/15 bg-[#080A0E] px-6 py-5 md:hidden">
          <div className="grid grid-cols-2 gap-4 text-xs text-white/80">
            <button type="button" onClick={() => handleScrollTo('capabilities')} className="py-2 text-left hover:text-white">
              Products
            </button>
            <button type="button" onClick={() => handleScrollTo('missions')} className="py-2 text-left hover:text-white">
              Missions
            </button>
            <button type="button" onClick={() => handleScrollTo('missions')} className="py-2 text-left hover:text-white">
              About Us
            </button>
            <button type="button" onClick={() => handleScrollTo('explore')} className="py-2 text-left hover:text-white">
              Spacecraft
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileOpen(false);
                onOpenModal({ type: 'launch', preset: 'Aurora 1' });
              }}
              className="py-2 text-left hover:text-white"
            >
              Rockets
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileOpen(false);
                onOpenModal({ type: 'launch', preset: 'SpectraSat' });
              }}
              className="py-2 text-left hover:text-white"
            >
              Satellites
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileOpen(false);
                onOpenModal({ type: 'contact' });
              }}
              className="col-span-2 mt-2 border border-white/25 py-2.5 text-center font-medium text-white hover:bg-white/10"
            >
              Contacts
            </button>
          </div>
        </div>
      )}
    </header>
  );
}

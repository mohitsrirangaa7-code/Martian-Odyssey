interface MissionsSectionProps {
  onNavigateToSite: (siteId: 'jezero' | 'candor') => void;
}

export default function MissionsSection({ onNavigateToSite }: MissionsSectionProps) {

  return (
    <section
      id="missions"
      className="mx-auto w-full max-w-[1440px] px-6 py-24 md:px-10 md:py-32"
    >
      <div className="mx-auto flex max-w-2xl flex-col items-center text-center">
        {/* Heading */}
        <h2 className="font-pixel text-4xl leading-[1.02] tracking-wide text-white uppercase sm:text-5xl md:text-[54px]">
          OUR
          <br />
          MISSIONS
        </h2>

        {/* Rocket Emblem */}
        <div className="mt-6 flex justify-center" aria-hidden="true">
          <svg viewBox="0 0 48 64" fill="none" className="h-12 w-10 text-white">
            {/* Rocket Nose & Body */}
            <path
              d="M24 4C19.2 12.2 17 22.5 17 34V43H31V34C31 22.5 28.8 12.2 24 4Z"
              fill="currentColor"
              fillOpacity="0.92"
            />
            {/* Left Fin */}
            <path d="M17 35L9.5 44.5V48.5L17 44V35Z" fill="currentColor" fillOpacity="0.7" />
            {/* Right Fin */}
            <path d="M31 35L38.5 44.5V48.5L31 44V35Z" fill="currentColor" fillOpacity="0.7" />
            {/* Center Nozzle */}
            <path d="M20.5 43L19 49H29L27.5 43H20.5Z" fill="currentColor" fillOpacity="0.6" />
            {/* Viewport Window */}
            <circle cx="24" cy="24" r="3.2" fill="#050608" stroke="rgba(255,255,255,0.45)" strokeWidth="1" />
            {/* Exhaust Flame Plume */}
            <path d="M22 50L24 58L26 50H22Z" fill="currentColor" fillOpacity="0.45" />
          </svg>
        </div>

        {/* Mission Copy */}
        <p className="mt-6 max-w-md text-[11px] leading-relaxed text-white/75 sm:text-xs">
          MarsWalk is a futuristic space travel experience that takes you beyond Earth on an
          extraordinary journey to the Red Planet. Discover the wonders of Mars, experience life
          beyond Earth, explore its mysterious landscapes, and participate in exciting scientific
          discoveries. From launching into space to safely returning home, every moment is designed
          to bring humanity one step closer to becoming an interplanetary civilization.
        </p>

        {/* Destination Redirect Buttons */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
          <button
            type="button"
            onClick={() => onNavigateToSite('jezero')}
            className="cursor-pointer whitespace-nowrap rounded-md bg-white px-8 py-2.5 text-xs font-medium text-[#050608] transition-colors duration-150 hover:bg-white/90 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white"
          >
            Explore Jezero Crater
          </button>

          <button
            type="button"
            onClick={() => onNavigateToSite('candor')}
            className="cursor-pointer whitespace-nowrap rounded-md bg-white px-8 py-2.5 text-xs font-medium text-[#050608] transition-colors duration-150 hover:bg-white/90 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white"
          >
            Explore Valles Marineris
          </button>
        </div>

        {/* Intricate Wireframe Globe with Subtle Radiating Lines */}
        <div className="relative mt-10 flex w-full items-center justify-center">
          <svg
            viewBox="0 0 420 420"
            fill="none"
            className="h-72 w-72 text-white sm:h-88 sm:w-88 md:h-[400px] md:w-[400px]"
            aria-label="Orbital trajectory wireframe globe"
          >
            {/* Subtle Radiating Starburst Lines Behind Globe */}
            <g stroke="rgba(255,255,255,0.06)" strokeWidth="0.75">
              {Array.from({ length: 36 }).map((_, i) => {
                const angle = (i * 10 * Math.PI) / 180;
                const x1 = 210 + Math.cos(angle) * 118;
                const y1 = 210 + Math.sin(angle) * 118;
                const x2 = 210 + Math.cos(angle) * 204;
                const y2 = 210 + Math.sin(angle) * 204;
                return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} />;
              })}
            </g>

            {/* Outer Sphere Boundary */}
            <circle cx="210" cy="210" r="126" stroke="rgba(255,255,255,0.5)" strokeWidth="0.9" />

            {/* Tilted Meridian & Orbital Great-Circle Ellipses */}
            <ellipse
              cx="210"
              cy="210"
              rx="42"
              ry="126"
              transform="rotate(-12 210 210)"
              stroke="rgba(255,255,255,0.35)"
              strokeWidth="0.8"
            />
            <ellipse
              cx="210"
              cy="210"
              rx="82"
              ry="126"
              transform="rotate(-12 210 210)"
              stroke="rgba(255,255,255,0.38)"
              strokeWidth="0.8"
            />
            <ellipse
              cx="210"
              cy="210"
              rx="52"
              ry="126"
              transform="rotate(28 210 210)"
              stroke="rgba(255,255,255,0.32)"
              strokeWidth="0.8"
            />
            <ellipse
              cx="210"
              cy="210"
              rx="105"
              ry="126"
              transform="rotate(52 210 210)"
              stroke="rgba(255,255,255,0.28)"
              strokeWidth="0.8"
            />
            <ellipse
              cx="210"
              cy="210"
              rx="126"
              ry="46"
              transform="rotate(-18 210 210)"
              stroke="rgba(255,255,255,0.38)"
              strokeWidth="0.8"
            />
            <ellipse
              cx="210"
              cy="210"
              rx="126"
              ry="84"
              transform="rotate(14 210 210)"
              stroke="rgba(255,255,255,0.3)"
              strokeWidth="0.8"
            />
            <ellipse
              cx="210"
              cy="210"
              rx="126"
              ry="22"
              transform="rotate(42 210 210)"
              stroke="rgba(255,255,255,0.25)"
              strokeWidth="0.75"
            />
          </svg>
        </div>
      </div>

      {/* Bottom Triad Labels */}
      <div className="mx-auto mt-10 flex max-w-6xl items-center justify-between text-xs tracking-wide sm:text-sm">
        <span className="text-white/55">From Earth</span>
        <span className="font-medium tracking-widest text-white uppercase">BEYOND</span>
        <span className="text-white/55">Into Tomorrow</span>
      </div>
    </section>
  );
}

import type { ModalContext } from './Navbar';

interface HeroSectionProps {
  onOpenModal: (ctx: ModalContext) => void;
}

export default function HeroSection({ onOpenModal }: HeroSectionProps) {
  return (
    <section
      id="top"
      className="relative mx-auto flex w-full max-w-[1440px] flex-col justify-between px-6 pt-16 pb-8 md:px-10 md:pt-28 md:pb-12"
    >
      {/* Top 3-column Horizon Row: Left tagline, Center circular CTA, Right mission intro */}
      <div className="grid grid-cols-1 items-center gap-10 md:grid-cols-3 md:gap-6">
        {/* Left Tagline */}
        <div className="flex justify-center md:justify-start">
          <p className="font-pixel text-center text-lg leading-tight tracking-wider text-white uppercase md:text-left md:text-xl">
            WITNESSES OF
            <br />
            NEW HORIZONS
          </p>
        </div>

        {/* Center Circular CTA Button */}
        <div className="flex justify-center">
          <button
            type="button"
            onClick={() => onOpenModal({ type: 'launch' })}
            className="group relative flex h-28 w-28 cursor-pointer items-center justify-center rounded-full border border-white/30 p-1.5 transition-transform duration-200 hover:scale-105 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white md:h-32 md:w-32"
          >
            <span className="flex h-full w-full items-center justify-center rounded-full bg-white/90 px-3 text-center text-[10px] leading-tight font-semibold tracking-wide text-[#050608] transition-colors duration-200 group-hover:bg-white md:text-[10.5px]">
              Book the Ultimate Out-and Back
            </span>
          </button>
        </div>

        {/* Right Copy */}
        <div className="flex justify-center md:justify-end">
          <p className="max-w-sm whitespace-pre-line text-center text-xs leading-relaxed text-white/80 md:text-left">
            {`MARSWALK – Beyond the Boundaries of Earth

A journey that begins on Earth and reaches the mysterious Red Planet.
Explore the vast Martian landscapes and uncover secrets hidden for billions of years.
Conduct scientific experiments and discover the possibilities of life beyond Earth.
Navigate the unknown, overcome challenges, and push the boundaries of human exploration.
Explore Mars. Expand Humanity's Horizons. Return with Discovery.`}
          </p>
        </div>
      </div>

      {/* Massive Full-Width Pixel Display Headline */}
      <div className="mt-16 w-full md:mt-24">
        <h1 className="font-pixel w-full text-center text-[clamp(2.8rem,10vw,9.25rem)] leading-[0.88] font-normal tracking-tight text-white select-none">
          Martian Odyssey
        </h1>
        <p className="mt-4 text-center text-xs tracking-widest text-white/75 sm:text-sm">
          Conquer the Crater-Master the Terrain
        </p>
      </div>
    </section>
  );
}

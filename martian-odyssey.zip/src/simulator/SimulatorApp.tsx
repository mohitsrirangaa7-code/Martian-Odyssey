import { useCallback, useEffect, useRef, useState } from 'react';
import { ExplorerOverlay } from './components/ExplorerOverlay';
import { HelmetHudOverlay } from './components/HelmetHudOverlay';
import {
  CameraAction,
  EvaTelemetry,
  MarsViewport,
  ProjectedMarker,
} from './components/MarsViewport';
import { MARS_SITES, MarsPoi, OverlayLayerId, SiteId } from './data/marsSites';
import { EvaRouteResult, computeSafeEvaRoute } from './engine/pathfinding';
import { TerrainGrid, TerrainSample } from './engine/terrainMath';

interface SimulatorAppProps {
  initialSiteId?: SiteId;
  onSiteChange?: (id: SiteId) => void;
  onBackToHome?: () => void;
}

export default function SimulatorApp({
  initialSiteId = 'jezero',
  onSiteChange,
  onBackToHome,
}: SimulatorAppProps) {
  const [siteId, setSiteId] = useState<SiteId>(initialSiteId);
  const [activeLayer, setActiveLayer] = useState<OverlayLayerId>('natural');
  const [solHour, setSolHour] = useState<number>(15.4); // Raking Martian afternoon light
  const [isSolPlaying, setIsSolPlaying] = useState<boolean>(false);

  const [evaMode, setEvaMode] = useState<boolean>(false);
  const [isWalkingRoute, setIsWalkingRoute] = useState<boolean>(false);
  const [pickRouteMode, setPickRouteMode] = useState<boolean>(false);
  const [prioritizeShelter, setPrioritizeShelter] = useState<boolean>(false);

  const [selectedPoi, setSelectedPoi] = useState<MarsPoi | null>(null);
  const [hoverSample, setHoverSample] = useState<TerrainSample | null>(null);
  const [dockCollapsed, setDockCollapsed] = useState<boolean>(false);
  const [azimuthDeg, setAzimuthDeg] = useState<number>(0);
  const [cameraAction, setCameraAction] = useState<CameraAction | null>(null);

  const [route, setRoute] = useState<EvaRouteResult | null>(null);
  const [routeDestination, setRouteDestination] = useState<{
    x: number;
    z: number;
    name: string;
  } | null>(null);

  const [evaTelemetry, setEvaTelemetry] = useState<EvaTelemetry>({
    x: -74,
    z: 95,
    elevationM: -2560,
    slopeDeg: 2.1,
    radiationMsv: 0.64,
    thermalInertia: 540,
    mineralCode: 0,
    headingDeg: 45,
    oxygenPct: 98.5,
    batteryPct: 96.0,
    distanceWalkedM: 0,
    routeProgress: 0,
  });
  const [projectedMarkers, setProjectedMarkers] = useState<ProjectedMarker[]>([]);

  const gridRef = useRef<TerrainGrid | null>(null);
  const site = MARS_SITES[siteId];

  // Recompute route whenever destination, shelter bias, or grid updates
  const computeRouteTo = useCallback(
    (dest: { x: number; z: number; name: string }, shelterBias: boolean) => {
      const grid = gridRef.current;
      if (!grid) return;
      const currentSite = MARS_SITES[grid.siteId];
      const result = computeSafeEvaRoute(
        grid,
        currentSite.habitatPos,
        { x: dest.x, z: dest.z },
        { prioritizeShelter: shelterBias }
      );
      setRoute(result);
    },
    []
  );

  const handleGridReady = useCallback(
    (grid: TerrainGrid) => {
      gridRef.current = grid;
      const currentSite = MARS_SITES[grid.siteId];
      const defaultPoi =
        currentSite.pois.find((p) => p.id === currentSite.defaultTargetId) ??
        currentSite.pois[1];
      if (defaultPoi) {
        const dest = { x: defaultPoi.x, z: defaultPoi.z, name: defaultPoi.name };
        setRouteDestination(dest);
        const result = computeSafeEvaRoute(
          grid,
          currentSite.habitatPos,
          { x: dest.x, z: dest.z },
          { prioritizeShelter }
        );
        setRoute(result);
      }
    },
    [prioritizeShelter]
  );

  useEffect(() => {
    setSiteId(initialSiteId);
    setSelectedPoi(null);
    setPickRouteMode(false);
    setIsWalkingRoute(false);
  }, [initialSiteId]);

  const handleSelectSite = useCallback(
    (id: SiteId) => {
      setSiteId(id);
      setSelectedPoi(null);
      setPickRouteMode(false);
      setIsWalkingRoute(false);
      onSiteChange?.(id);
    },
    [onSiteChange]
  );

  const handlePlanRouteToPoi = useCallback(
    (poi: MarsPoi) => {
      const dest = { x: poi.x, z: poi.z, name: poi.name };
      setRouteDestination(dest);
      computeRouteTo(dest, prioritizeShelter);
      setPickRouteMode(false);
    },
    [computeRouteTo, prioritizeShelter]
  );

  const handleTerrainClickForRoute = useCallback(
    (x: number, z: number) => {
      const dest = {
        x,
        z,
        name: `Waypoint (${Math.round(x)}, ${Math.round(z)})`,
      };
      setRouteDestination(dest);
      computeRouteTo(dest, prioritizeShelter);
      setPickRouteMode(false);
    },
    [computeRouteTo, prioritizeShelter]
  );

  const handleTogglePrioritizeShelter = useCallback(() => {
    setPrioritizeShelter((prev) => {
      const next = !prev;
      if (routeDestination) {
        computeRouteTo(routeDestination, next);
      }
      return next;
    });
  }, [computeRouteTo, routeDestination]);

  const handleClearRoute = useCallback(() => {
    setRoute(null);
    setRouteDestination(null);
    setIsWalkingRoute(false);
  }, []);

  const handleFlyToPoi = useCallback((poi: MarsPoi) => {
    setCameraAction({ type: 'flyTo', x: poi.x, z: poi.z, nonce: Date.now() });
  }, []);

  const handleCameraAction = useCallback((type: 'reset' | 'zoomIn' | 'zoomOut' | 'tilt') => {
    setCameraAction({ type, nonce: Date.now() });
  }, []);

  const handleEnterEvaMode = useCallback(() => {
    setPickRouteMode(false);
    setEvaMode(true);
  }, []);

  const handleWalkRouteInEva = useCallback(() => {
    setPickRouteMode(false);
    setEvaMode(true);
    setIsWalkingRoute(true);
  }, []);

  // Sol day-night cycle playback
  useEffect(() => {
    if (!isSolPlaying) return;
    const id = window.setInterval(() => {
      setSolHour((h) => (h + 0.08) % 24.62);
    }, 50);
    return () => window.clearInterval(id);
  }, [isSolPlaying]);

  // Global keyboard shortcuts (V = EVA Helmet toggle, H = Dock toggle, Esc = Cancel)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement &&
        (document.activeElement.tagName === 'INPUT' ||
          document.activeElement.tagName === 'TEXTAREA')
      ) {
        return;
      }
      if (e.code === 'KeyV') {
        setEvaMode((v) => {
          if (v) setIsWalkingRoute(false);
          return !v;
        });
      } else if (e.code === 'KeyH' && !evaMode) {
        setDockCollapsed((c) => !c);
      } else if (e.code === 'Escape') {
        if (pickRouteMode) setPickRouteMode(false);
        else if (selectedPoi) setSelectedPoi(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [evaMode, pickRouteMode, selectedPoi]);

  return (
    <main className="fixed inset-0 w-screen h-screen overflow-hidden bg-[#07090E] text-slate-100 select-none">
      <MarsViewport
        siteId={siteId}
        activeLayer={activeLayer}
        solHour={solHour}
        evaMode={evaMode}
        pickRouteMode={pickRouteMode}
        route={route}
        isWalkingRoute={isWalkingRoute}
        selectedPoiId={selectedPoi?.id ?? null}
        cameraAction={cameraAction}
        onGridReady={handleGridReady}
        onSelectPoi={setSelectedPoi}
        onTerrainClickForRoute={handleTerrainClickForRoute}
        onHoverSample={setHoverSample}
        onEvaTelemetry={setEvaTelemetry}
        onProjectedMarkers={setProjectedMarkers}
        onWalkComplete={() => setIsWalkingRoute(false)}
        onCameraAzimuthChange={setAzimuthDeg}
      />

      {evaMode ? (
        <HelmetHudOverlay
          siteName={site.name}
          solHour={solHour}
          telemetry={evaTelemetry}
          markers={projectedMarkers}
          route={route}
          isWalkingRoute={isWalkingRoute}
          onToggleWalkRoute={() => setIsWalkingRoute((w) => !w)}
          onExitEva={() => {
            setIsWalkingRoute(false);
            setEvaMode(false);
          }}
        />
      ) : (
        <ExplorerOverlay
          site={site}
          activeLayer={activeLayer}
          solHour={solHour}
          isSolPlaying={isSolPlaying}
          pickRouteMode={pickRouteMode}
          route={route}
          routeTargetName={routeDestination?.name ?? ''}
          prioritizeShelter={prioritizeShelter}
          selectedPoi={selectedPoi}
          hoverSample={hoverSample}
          azimuthDeg={azimuthDeg}
          dockCollapsed={dockCollapsed}
          onSelectSite={handleSelectSite}
          onSelectLayer={setActiveLayer}
          onChangeSolHour={setSolHour}
          onToggleSolPlay={() => setIsSolPlaying((p) => !p)}
          onEnterEvaMode={handleEnterEvaMode}
          onWalkRouteInEva={handleWalkRouteInEva}
          onTogglePickRouteMode={() => setPickRouteMode((p) => !p)}
          onTogglePrioritizeShelter={handleTogglePrioritizeShelter}
          onPlanRouteToPoi={handlePlanRouteToPoi}
          onClearRoute={handleClearRoute}
          onSelectPoi={setSelectedPoi}
          onFlyToPoi={handleFlyToPoi}
          onCameraAction={handleCameraAction}
          onToggleDock={() => setDockCollapsed((c) => !c)}
          onBackToHome={onBackToHome}
        />
      )}
    </main>
  );
}

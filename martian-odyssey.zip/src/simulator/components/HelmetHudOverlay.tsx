import React from 'react';
import { Compass, Footprints, Pause, Play, ShieldAlert, ShieldCheck, X } from 'lucide-react';
import { EvaRouteResult } from '../engine/pathfinding';
import { getMineralLabel } from '../engine/terrainMath';
import { EvaTelemetry, ProjectedMarker } from './MarsViewport';

interface HelmetHudOverlayProps {
  siteName: string;
  solHour: number;
  telemetry: EvaTelemetry;
  markers: ProjectedMarker[];
  route: EvaRouteResult | null;
  isWalkingRoute: boolean;
  onToggleWalkRoute: () => void;
  onExitEva: () => void;
}

function formatSolTime(hour: number): string {
  const h = Math.floor(hour) % 24;
  const m = Math.floor((hour - Math.floor(hour)) * 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export const HelmetHudOverlay: React.FC<HelmetHudOverlayProps> = ({
  siteName,
  solHour,
  telemetry,
  markers,
  route,
  isWalkingRoute,
  onToggleWalkRoute,
  onExitEva,
}) => {
  const slopeStatus =
    telemetry.slopeDeg > 15
      ? { label: 'Steep Hazard', tone: 'text-rose-400' }
      : telemetry.slopeDeg > 10
        ? { label: 'Caution Grade', tone: 'text-amber-400' }
        : { label: 'Nominal Grade', tone: 'text-emerald-400' };

  const radSheltered = telemetry.radiationMsv < 0.44;
  const looseDust = telemetry.thermalInertia < 260;

  // Compute compass tape ticks around current heading
  const compassLabels: { deg: number; label: string }[] = [
    { deg: 0, label: 'N' },
    { deg: 45, label: 'NE' },
    { deg: 90, label: 'E' },
    { deg: 135, label: 'SE' },
    { deg: 180, label: 'S' },
    { deg: 225, label: 'SW' },
    { deg: 270, label: 'W' },
    { deg: 315, label: 'NW' },
  ];

  const categoryColor: Record<string, string> = {
    science: 'border-sky-400 text-sky-300',
    shelter: 'border-emerald-400 text-emerald-300',
    habitat: 'border-amber-400 text-amber-300',
    hazard: 'border-rose-400 text-rose-300',
  };

  return (
    <div className="absolute inset-0 z-20 pointer-events-none select-none overflow-hidden">
      {/* Subtle curved helmet visor vignette */}
      <div className="absolute inset-0 helmet-visor-vignette" />

      {/* Visor corner reticle brackets */}
      <div className="absolute top-5 left-5 w-8 h-8 border-t-2 border-l-2 border-sky-400/40 rounded-tl-lg" />
      <div className="absolute top-5 right-5 w-8 h-8 border-t-2 border-r-2 border-sky-400/40 rounded-tr-lg" />
      <div className="absolute bottom-5 left-5 w-8 h-8 border-b-2 border-l-2 border-sky-400/40 rounded-bl-lg" />
      <div className="absolute bottom-5 right-5 w-8 h-8 border-b-2 border-r-2 border-sky-400/40 rounded-br-lg" />

      {/* Projected 3D Waypoint & Target Markers */}
      {markers.map(
        (m) =>
          m.visible && (
            <div
              key={m.id}
              style={{
                transform: `translate3d(${Math.round(m.screenX)}px, ${Math.round(m.screenY)}px, 0) translate(-50%, -100%)`,
              }}
              className="absolute top-0 left-0 flex flex-col items-center gap-1"
            >
              <div className="px-2 py-1 rounded bg-[#070B12]/85 border border-white/15 text-[11px] leading-tight whitespace-nowrap">
                <span className="font-medium text-slate-100">{m.name}</span>
                <span className="text-slate-400 mx-1">·</span>
                <span className="font-mono-tabular text-sky-300">{Math.round(m.distanceM)} m</span>
              </div>
              <div
                className={`w-3 h-3 rotate-45 border-2 bg-[#070B12]/70 ${categoryColor[m.category]}`}
              />
            </div>
          )
      )}

      {/* Top Azimuth Compass Tape & Exit Button */}
      <div className="absolute top-4 inset-x-0 flex items-start justify-between px-6">
        <div className="bg-[#080C14]/85 border border-white/12 rounded-lg px-3.5 py-2 text-xs">
          <div className="font-display font-semibold text-slate-100 tracking-wide">
            EVA Helmet View · {siteName}
          </div>
          <div className="text-slate-400 font-mono-tabular mt-0.5">
            Sol 142 · {formatSolTime(solHour)} MTC · Suit 29.6 kPa
          </div>
        </div>

        {/* Center Compass Tape */}
        <div className="hidden sm:flex flex-col items-center bg-[#080C14]/85 border border-white/12 rounded-lg px-4 py-1.5 w-72 overflow-hidden">
          <div className="relative w-full h-5 overflow-hidden">
            {compassLabels.map((item) => {
              let diff = item.deg - telemetry.headingDeg;
              if (diff > 180) diff -= 360;
              if (diff < -180) diff += 360;
              if (Math.abs(diff) > 80) return null;
              const pct = 50 + (diff / 80) * 50;
              return (
                <span
                  key={item.label}
                  style={{ left: `${pct}%` }}
                  className="absolute top-0 -translate-x-1/2 font-mono-tabular text-[11px] font-semibold text-slate-300"
                >
                  {item.label}
                </span>
              );
            })}
            <div className="absolute left-1/2 bottom-0 -translate-x-1/2 w-0.5 h-2 bg-amber-400" />
          </div>
          <div className="flex items-center gap-1.5 text-[11px] font-mono-tabular text-amber-300">
            <Compass className="w-3 h-3" />
            <span>HDG {Math.round(telemetry.headingDeg).toString().padStart(3, '0')}°</span>
          </div>
        </div>

        <button
          type="button"
          onClick={onExitEva}
          className="pointer-events-auto flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#0B101B]/90 hover:bg-[#141D2F] border border-white/15 text-xs font-medium text-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <X className="w-3.5 h-3.5 text-amber-400" />
          <span>Exit Helmet View</span>
        </button>
      </div>

      {/* Left Suit Vitals */}
      <div className="absolute left-6 top-1/2 -translate-y-1/2 w-52 bg-[#080C14]/85 border border-white/12 rounded-lg p-3.5 space-y-3">
        <div>
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Oxygen Reserve</span>
            <span className="font-mono-tabular text-sky-300 font-semibold">
              {telemetry.oxygenPct.toFixed(1)}%
            </span>
          </div>
          <div className="mt-1.5 h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
            <div
              className={`h-full transition-all duration-150 ${
                telemetry.oxygenPct < 25 ? 'bg-rose-500' : 'bg-sky-400'
              }`}
              style={{ width: `${Math.max(0, Math.min(100, telemetry.oxygenPct))}%` }}
            />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Suit Battery</span>
            <span className="font-mono-tabular text-emerald-300 font-semibold">
              {telemetry.batteryPct.toFixed(1)}%
            </span>
          </div>
          <div className="mt-1.5 h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-emerald-400 transition-all duration-150"
              style={{ width: `${Math.max(0, Math.min(100, telemetry.batteryPct))}%` }}
            />
          </div>
        </div>

        <div className="pt-2 border-t border-white/10 grid grid-cols-2 gap-2 text-xs">
          <div>
            <div className="text-[11px] text-slate-400">Traversed</div>
            <div className="font-mono-tabular font-semibold text-slate-100">
              {Math.round(telemetry.distanceWalkedM)} m
            </div>
          </div>
          <div>
            <div className="text-[11px] text-slate-400">Elevation</div>
            <div className="font-mono-tabular font-semibold text-slate-100">
              {Math.round(telemetry.elevationM)} m
            </div>
          </div>
        </div>
      </div>

      {/* Right Terrain & Hazard Telemetry */}
      <div className="absolute right-6 top-1/2 -translate-y-1/2 w-56 bg-[#080C14]/85 border border-white/12 rounded-lg p-3.5 space-y-2.5 text-xs">
        <div>
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Local Slope</span>
            <span className={`font-medium ${slopeStatus.tone}`}>{slopeStatus.label}</span>
          </div>
          <div className="font-mono-tabular text-lg font-semibold text-slate-100">
            {telemetry.slopeDeg.toFixed(1)}°
          </div>
        </div>

        <div className="pt-2 border-t border-white/10">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Surface Radiation</span>
            <span className={radSheltered ? 'text-emerald-400 font-medium' : 'text-amber-400'}>
              {radSheltered ? 'Sheltered' : 'Exposed'}
            </span>
          </div>
          <div className="flex items-center gap-1.5 mt-0.5">
            {radSheltered ? (
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            ) : (
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            )}
            <span className="font-mono-tabular text-sm font-semibold text-slate-100">
              {telemetry.radiationMsv.toFixed(2)} mSv/d
            </span>
          </div>
        </div>

        <div className="pt-2 border-t border-white/10">
          <div className="text-[11px] text-slate-400">Footing & Composition</div>
          <div className="font-mono-tabular text-xs font-medium text-slate-100 mt-0.5">
            {Math.round(telemetry.thermalInertia)} TIU · {looseDust ? 'Loose Dust' : 'Firm Bedrock'}
          </div>
          <div className="text-[11px] text-slate-400 truncate mt-0.5">
            {getMineralLabel(telemetry.mineralCode)}
          </div>
        </div>
      </div>

      {/* Center subtle crosshair */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-5 h-5 opacity-45">
        <div className="absolute left-1/2 top-0 w-px h-1.5 bg-sky-300 -translate-x-1/2" />
        <div className="absolute left-1/2 bottom-0 w-px h-1.5 bg-sky-300 -translate-x-1/2" />
        <div className="absolute top-1/2 left-0 h-px w-1.5 bg-sky-300 -translate-y-1/2" />
        <div className="absolute top-1/2 right-0 h-px w-1.5 bg-sky-300 -translate-y-1/2" />
      </div>

      {/* Bottom EVA Action & Keybinds Bar */}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex items-center gap-3 bg-[#080C14]/88 border border-white/12 rounded-xl px-4 py-2.5">
        {route && (
          <button
            type="button"
            onClick={onToggleWalkRoute}
            className="pointer-events-auto flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {isWalkingRoute ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isWalkingRoute ? 'Pause Traverse' : 'Follow Planned Route'}</span>
          </button>
        )}

        {route && isWalkingRoute && (
          <div className="flex items-center gap-2 text-xs font-mono-tabular text-sky-300 whitespace-nowrap">
            <Footprints className="w-3.5 h-3.5" />
            <span>{Math.round(telemetry.routeProgress * 100)}%</span>
          </div>
        )}

        <div className="text-xs text-slate-400 whitespace-nowrap">
          WASD Move · Drag Look · Shift Sprint · V Exit
        </div>
      </div>
    </div>
  );
};

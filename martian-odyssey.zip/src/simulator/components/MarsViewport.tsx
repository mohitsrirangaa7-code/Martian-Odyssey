import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { MARS_SITES, MarsPoi, OverlayLayerId, SiteId } from '../data/marsSites';
import { EvaRouteResult } from '../engine/pathfinding';
import {
  MarsRoverRig,
  TerrainLayerTextures,
  buildBoulderInstances,
  buildCommsTower,
  buildHabitatComplex,
  buildHorizonSkirt,
  buildMarsAscentVehicle,
  buildMarsRover,
  buildOutcropSlabs,
  buildPoiBeacon,
  buildSolarArray,
  buildTerrainGeometry,
  generateTerrainLayerTextures,
  getLayerTexture,
} from '../engine/proceduralAssets';
import {
  TerrainGrid,
  TerrainSample,
  bakeTerrainGrid,
  sampleElevation,
  sampleTerrainFull,
  sampleTerrainNormal,
} from '../engine/terrainMath';

export interface ProjectedMarker {
  id: string;
  name: string;
  category: MarsPoi['category'];
  screenX: number;
  screenY: number;
  distanceM: number;
  visible: boolean;
}

export interface EvaTelemetry {
  x: number;
  z: number;
  elevationM: number;
  slopeDeg: number;
  radiationMsv: number;
  thermalInertia: number;
  mineralCode: number;
  headingDeg: number;
  oxygenPct: number;
  batteryPct: number;
  distanceWalkedM: number;
  routeProgress: number; // 0..1
}

export interface CameraAction {
  type: 'reset' | 'zoomIn' | 'zoomOut' | 'tilt' | 'flyTo';
  x?: number;
  z?: number;
  nonce: number;
}

interface MarsViewportProps {
  siteId: SiteId;
  activeLayer: OverlayLayerId;
  solHour: number; // 0 .. 24.62
  evaMode: boolean;
  pickRouteMode: boolean;
  route: EvaRouteResult | null;
  isWalkingRoute: boolean;
  selectedPoiId: string | null;
  cameraAction: CameraAction | null;
  onGridReady: (grid: TerrainGrid) => void;
  onSelectPoi: (poi: MarsPoi | null) => void;
  onTerrainClickForRoute: (x: number, z: number) => void;
  onHoverSample: (sample: TerrainSample | null) => void;
  onEvaTelemetry: (telemetry: EvaTelemetry) => void;
  onProjectedMarkers: (markers: ProjectedMarker[]) => void;
  onWalkComplete: () => void;
  onCameraAzimuthChange: (azimuthDeg: number) => void;
}

// Reusable math scratch objects (zero GC in animation loop)
const _vec3A = new THREE.Vector3();
const _vec3B = new THREE.Vector3();
const _vec3C = new THREE.Vector3();
const _vec3Up = new THREE.Vector3(0, 1, 0);
const _quatA = new THREE.Quaternion();
const _quatB = new THREE.Quaternion();
const _colorA = new THREE.Color();
const _colorB = new THREE.Color();

export const MarsViewport: React.FC<MarsViewportProps> = ({
  siteId,
  activeLayer,
  solHour,
  evaMode,
  pickRouteMode,
  route,
  isWalkingRoute,
  selectedPoiId,
  cameraAction,
  onGridReady,
  onSelectPoi,
  onTerrainClickForRoute,
  onHoverSample,
  onEvaTelemetry,
  onProjectedMarkers,
  onWalkComplete,
  onCameraAzimuthChange,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [contextLost, setContextLost] = useState(false);

  // Mutable refs so React prop changes never recreate the WebGL context
  const propsRef = useRef({
    siteId,
    activeLayer,
    solHour,
    evaMode,
    pickRouteMode,
    route,
    isWalkingRoute,
    selectedPoiId,
  });
  propsRef.current = {
    siteId,
    activeLayer,
    solHour,
    evaMode,
    pickRouteMode,
    route,
    isWalkingRoute,
    selectedPoiId,
  };

  const callbacksRef = useRef({
    onGridReady,
    onSelectPoi,
    onTerrainClickForRoute,
    onHoverSample,
    onEvaTelemetry,
    onProjectedMarkers,
    onWalkComplete,
    onCameraAzimuthChange,
  });
  callbacksRef.current = {
    onGridReady,
    onSelectPoi,
    onTerrainClickForRoute,
    onHoverSample,
    onEvaTelemetry,
    onProjectedMarkers,
    onWalkComplete,
    onCameraAzimuthChange,
  };

  // Internal scene controller ref for imperative updates on prop changes
  const engineRef = useRef<{
    rebuildSite: (id: SiteId) => void;
    updateLayer: (layer: OverlayLayerId) => void;
    updateSolLighting: (hour: number) => void;
    updateRouteVisual: (r: EvaRouteResult | null) => void;
    setEvaMode: (enabled: boolean) => void;
    handleCameraAction: (action: CameraAction) => void;
    startRouteWalk: (walking: boolean) => void;
  } | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      const probe = document.createElement('canvas').getContext('webgl2');
      if (!probe) return true;
      const ext = probe.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
      const gpu = String(probe.getParameter(param));
      probe.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setContextLost(true);
    };
    const handleContextRestored = () => {
      setContextLost(false);
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xc87d55);
    scene.fog = new THREE.FogExp2(0xc87d55, 0.0014);

    // Mandatory studio/environment map for metallic spacecraft/habitat PBR reflections
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environmentIntensity = 0.55;
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(
      52,
      container.clientWidth / container.clientHeight,
      0.3,
      2600
    );
    camera.position.set(-165, 145, 225);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.07;
    controls.minDistance = 24;
    controls.maxDistance = 520;
    controls.minPolarAngle = 0.08;
    controls.maxPolarAngle = Math.PI * 0.455;
    controls.target.set(0, 0, 0);

    // Lighting rig
    const hemiLight = new THREE.HemisphereLight(0xf6b995, 0x4b291d, 0.72);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfff1de, 2.25);
    sunLight.position.set(200, 220, 140);
    sunLight.castShadow = !isSoftwareGl;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 20;
    sunLight.shadow.camera.far = 900;
    const d = 310;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    sunLight.shadow.bias = -0.0005;
    sunLight.shadow.normalBias = 0.025;
    scene.add(sunLight);
    scene.add(sunLight.target);

    // Astronaut helmet headlamp (active at dusk/night in EVA mode)
    const headlamp = new THREE.SpotLight(0xe0f2fe, 0, 90, Math.PI / 5, 0.45, 1.4);
    scene.add(headlamp);
    scene.add(headlamp.target);

    // Procedural Martian Sky Dome Shader (dusty salmon-butterscotch day + blue twilight halo)
    const skyUniforms = {
      uZenithColor: { value: new THREE.Color(0x8e5d45) },
      uHorizonColor: { value: new THREE.Color(0xc9835b) },
      uSunGlowColor: { value: new THREE.Color(0xffdcb8) },
      uSunDir: { value: new THREE.Vector3(0.5, 0.5, 0.3).normalize() },
      uGlowStrength: { value: 0.45 },
    };
    const skyGeo = new THREE.SphereGeometry(1650, 32, 20);
    const skyMat = new THREE.ShaderMaterial({
      uniforms: skyUniforms,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      vertexShader: `
        varying vec3 vWorldDir;
        void main() {
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorldDir = normalize(wp.xyz);
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: `
        uniform vec3 uZenithColor;
        uniform vec3 uHorizonColor;
        uniform vec3 uSunGlowColor;
        uniform vec3 uSunDir;
        uniform float uGlowStrength;
        varying vec3 vWorldDir;
        void main() {
          float h = clamp(vWorldDir.y, 0.0, 1.0);
          vec3 col = mix(uHorizonColor, uZenithColor, pow(h, 0.52));
          float sunDot = max(0.0, dot(normalize(vWorldDir), normalize(uSunDir)));
          float halo = pow(sunDot, 12.0) * 0.45 + pow(sunDot, 180.0) * 1.1;
          col += uSunGlowColor * halo * uGlowStrength;
          gl_FragColor = vec4(col, 1.0);
        }
      `,
    });
    const skyDome = new THREE.Mesh(skyGeo, skyMat);
    scene.add(skyDome);

    // Night starfield dome
    const starCount = 900;
    const starPos = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 0.85 + 0.15);
      const r = 1400;
      starPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      starPos[i * 3 + 1] = r * Math.cos(phi);
      starPos[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
    }
    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    const starMat = new THREE.PointsMaterial({
      color: 0xe2e8f0,
      size: 2.4,
      transparent: true,
      opacity: 0.0,
      fog: false,
    });
    const starField = new THREE.Points(starGeo, starMat);
    scene.add(starField);

    // Sculpted distant Martian rim/canyon horizon skirt
    let skirtMesh: THREE.Mesh = buildHorizonSkirt(-16);
    scene.add(skirtMesh);

    // Dynamic site container
    const siteGroup = new THREE.Group();
    scene.add(siteGroup);

    const routeGroup = new THREE.Group();
    scene.add(routeGroup);

    let currentGrid: TerrainGrid | null = null;
    let currentTextures: TerrainLayerTextures | null = null;
    let terrainMesh: THREE.Mesh | null = null;
    let terrainMat: THREE.MeshStandardMaterial | null = null;
    let poiBeaconMeshes: THREE.Object3D[] = [];
    let currentBoulders: THREE.InstancedMesh | null = null;
    let currentOutcrops: THREE.InstancedMesh | null = null;
    let roverRig: MarsRoverRig | null = null;
    let roverTime = 0;
    let roverLastX = 0;
    let roverLastZ = 0;

    // Camera fly-to transition state
    let flyActive = false;
    const flyCamTarget = new THREE.Vector3();
    const flyLookTarget = new THREE.Vector3();

    // First-person EVA state
    const evaState = {
      x: -74,
      z: 95,
      yaw: -0.7,
      pitch: -0.05,
      oxygenPct: 98.5,
      batteryPct: 96.0,
      distanceWalkedM: 0,
      routeDistCursor: 0,
      totalRouteLen: 0,
      walkingRoute: false,
      routeCumDist: [] as number[],
    };

    const keysDown: Record<string, boolean> = {};
    let isLookingEva = false;
    let lastLookX = 0;
    let lastLookY = 0;
    let pointerDownPos = { x: 0, y: 0 };

    const disposeSiteObjects = () => {
      siteGroup.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          const m = obj as THREE.Mesh;
          m.geometry?.dispose();
          if (Array.isArray(m.material)) m.material.forEach((mt) => mt.dispose());
          else m.material?.dispose();
        }
      });
      while (siteGroup.children.length > 0) {
        siteGroup.remove(siteGroup.children[0]);
      }
      if (currentTextures) {
        currentTextures.natural.dispose();
        currentTextures.topography.dispose();
        currentTextures.radiation.dispose();
        currentTextures.thermal.dispose();
        currentTextures.roughnessMap.dispose();
        currentTextures.normalMap.dispose();
        currentTextures = null;
      }
      poiBeaconMeshes = [];
      terrainMesh = null;
      terrainMat = null;
      currentBoulders = null;
      currentOutcrops = null;
      roverRig = null;
    };

    const maxAniso = renderer.capabilities.getMaxAnisotropy();

    const rebuildSite = (id: SiteId) => {
      disposeSiteObjects();
      const site = MARS_SITES[id];
      const grid = bakeTerrainGrid(id, 176);
      currentGrid = grid;
      callbacksRef.current.onGridReady(grid);

      const textures = generateTerrainLayerTextures(grid, maxAniso);
      currentTextures = textures;

      const terrainGeo = buildTerrainGeometry(grid);
      const tMat = new THREE.MeshStandardMaterial({
        map: getLayerTexture(textures, propsRef.current.activeLayer),
        normalMap: textures.normalMap,
        normalScale: new THREE.Vector2(1.3, 1.3),
        roughnessMap: textures.roughnessMap,
        roughness: 0.94,
        metalness: 0.03,
      });
      terrainMat = tMat;

      const tMesh = new THREE.Mesh(terrainGeo, tMat);
      tMesh.receiveShadow = true;
      tMesh.castShadow = false;
      terrainMesh = tMesh;
      siteGroup.add(tMesh);

      // Update distant sculpted rim skirt to match site basin floor
      scene.remove(skirtMesh);
      skirtMesh.geometry.dispose();
      (skirtMesh.material as THREE.Material).dispose();
      skirtMesh = buildHorizonSkirt(grid.minHeight);
      scene.add(skirtMesh);

      // Grounded Habitat, MAV, Solar, Comms
      siteGroup.add(buildHabitatComplex(id, site.habitatPos.x, site.habitatPos.z));
      siteGroup.add(buildMarsAscentVehicle(id, site.mavPos.x, site.mavPos.z));
      siteGroup.add(buildSolarArray(id, site.solarPos.x, site.solarPos.z, maxAniso));
      siteGroup.add(buildCommsTower(id, site.commsPos.x, site.commsPos.z));

      // Grounded Perseverance-class Mars Rover on active surface survey
      roverRig = buildMarsRover(maxAniso);
      roverRig.group.scale.setScalar(1.35);
      roverTime = 0;
      const roverCenter = id === 'jezero' ? { x: -34, z: -14 } : { x: -82, z: 46 };
      const startRx = roverCenter.x + 22;
      const startRz = roverCenter.z;
      roverLastX = startRx;
      roverLastZ = startRz;
      roverRig.group.position.set(startRx, sampleElevation(id, startRx, startRz), startRz);
      siteGroup.add(roverRig.group);

      // Instanced stratified bedrock slabs + embedded basaltic boulders
      currentOutcrops = buildOutcropSlabs(id, grid);
      siteGroup.add(currentOutcrops);

      currentBoulders = buildBoulderInstances(id, grid);
      siteGroup.add(currentBoulders);

      // Clickable POI beacons
      site.pois.forEach((poi) => {
        const beacon = buildPoiBeacon(id, poi);
        siteGroup.add(beacon);
        poiBeaconMeshes.push(beacon);
      });

      // Reset EVA spawn near habitat airlock
      evaState.x = site.habitatPos.x + 11;
      evaState.z = site.habitatPos.z;
      evaState.oxygenPct = 98.5;
      evaState.batteryPct = 96.0;
      evaState.distanceWalkedM = 0;
      evaState.routeDistCursor = 0;

      // Smoothly frame the landing site & verified landmarks looking North (-Z)
      if (!propsRef.current.evaMode) {
        flyActive = true;
        flyLookTarget.set(site.habitatPos.x * 0.25, 2, site.habitatPos.z * 0.25);
        flyCamTarget.set(site.habitatPos.x * 0.25 - 68, 118, site.habitatPos.z * 0.25 + 178);
      }

      requestRender();
    };

    const updateLayer = (layer: OverlayLayerId) => {
      if (!terrainMat || !currentTextures) return;
      terrainMat.map = getLayerTexture(currentTextures, layer);
      terrainMat.needsUpdate = true;
      requestRender();
    };

    const updateSolLighting = (hour: number) => {
      // Mars Sol is ~24.62h. Daylight approx 06:00 - 18:30
      const dayFrac = (hour - 6.0) / 12.5; // 0 at dawn, 0.5 at noon, 1 at sunset
      const sunAngle = dayFrac * Math.PI;
      const elevation = Math.sin(sunAngle); // > 0 during day
      const azimuth = (hour / 24.62) * Math.PI * 2 - Math.PI * 0.5;

      const sunDist = 360;
      const sx = Math.cos(azimuth) * Math.max(0.18, Math.cos(sunAngle * 0.45)) * sunDist;
      const sy = Math.max(-40, elevation * sunDist);
      const sz = Math.sin(azimuth) * sunDist * 0.7;
      sunLight.position.set(sx, sy, sz);
      skyUniforms.uSunDir.value.set(sx, sy, sz).normalize();

      if (elevation > 0.08) {
        // Martian daylight: dusty salmon-ochre horizon grading to warm butterscotch sky
        const noonFactor = Math.min(1, elevation / 0.85);
        _colorA.setRGB(0.71, 0.42, 0.30); // low sun horizon dust
        _colorB.setRGB(0.81, 0.54, 0.40); // mid-day butterscotch haze
        _colorA.lerp(_colorB, noonFactor);
        skyUniforms.uHorizonColor.value.copy(_colorA);
        skyUniforms.uZenithColor.value.setRGB(
          0.52 + noonFactor * 0.12,
          0.34 + noonFactor * 0.10,
          0.26 + noonFactor * 0.09
        );
        skyUniforms.uSunGlowColor.value.setRGB(1.0, 0.84, 0.68);
        skyUniforms.uGlowStrength.value = 0.42;

        (scene.background as THREE.Color).copy(_colorA);
        (scene.fog as THREE.FogExp2).color.copy(_colorA);
        (scene.fog as THREE.FogExp2).density = 0.00125;

        sunLight.intensity = 1.0 + noonFactor * 1.65;
        sunLight.color.setRGB(1.0, 0.87 + noonFactor * 0.09, 0.74 + noonFactor * 0.16);
        hemiLight.intensity = 0.48 + noonFactor * 0.32;
        hemiLight.color.setRGB(0.95, 0.72, 0.58);
        starMat.opacity = 0;
        headlamp.intensity = 0;
      } else if (elevation > -0.14) {
        // Authentic Martian blue sunset/sunrise twilight glow
        const twi = (elevation + 0.14) / 0.22;
        _colorA.setRGB(0.04, 0.06, 0.11); // night
        _colorB.setRGB(0.32, 0.41, 0.52); // dusty blue twilight
        _colorA.lerp(_colorB, twi);
        skyUniforms.uHorizonColor.value.copy(_colorA);
        skyUniforms.uZenithColor.value.setRGB(0.08, 0.11, 0.19).lerp(_colorA, 0.35);
        skyUniforms.uSunGlowColor.value.setRGB(0.58, 0.76, 0.98);
        skyUniforms.uGlowStrength.value = 0.85 * twi;

        (scene.background as THREE.Color).copy(_colorA);
        (scene.fog as THREE.FogExp2).color.copy(_colorA);
        (scene.fog as THREE.FogExp2).density = 0.00145;

        sunLight.intensity = Math.max(0.08, twi * 0.85);
        sunLight.color.setRGB(0.75, 0.82, 0.96);
        hemiLight.intensity = 0.28 + twi * 0.18;
        hemiLight.color.setRGB(0.45, 0.56, 0.72);
        starMat.opacity = Math.max(0, 1 - twi) * 0.75;
        headlamp.intensity = propsRef.current.evaMode ? (1 - twi) * 28 : 0;
      } else {
        // Martian night sky
        _colorA.setRGB(0.025, 0.035, 0.065);
        skyUniforms.uHorizonColor.value.copy(_colorA);
        skyUniforms.uZenithColor.value.setRGB(0.015, 0.022, 0.045);
        skyUniforms.uGlowStrength.value = 0.0;

        (scene.background as THREE.Color).copy(_colorA);
        (scene.fog as THREE.FogExp2).color.copy(_colorA);
        (scene.fog as THREE.FogExp2).density = 0.0012;

        sunLight.intensity = 0.06;
        hemiLight.intensity = 0.22;
        hemiLight.color.setRGB(0.24, 0.31, 0.45);
        starMat.opacity = 0.92;
        headlamp.intensity = propsRef.current.evaMode ? 38 : 0;
      }

      requestRender();
    };

    const updateRouteVisual = (r: EvaRouteResult | null) => {
      routeGroup.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          const m = obj as THREE.Mesh;
          m.geometry?.dispose();
          if (Array.isArray(m.material)) m.material.forEach((mt) => mt.dispose());
          else m.material?.dispose();
        }
      });
      while (routeGroup.children.length > 0) {
        routeGroup.remove(routeGroup.children[0]);
      }

      evaState.routeCumDist = [];
      evaState.totalRouteLen = 0;
      evaState.routeDistCursor = 0;

      if (!r || r.points.length < 2) {
        requestRender();
        return;
      }

      const vecs = r.points.map((p) => new THREE.Vector3(p.x, p.y + 0.55, p.z));
      const curve = new THREE.CatmullRomCurve3(vecs);
      const tubeGeo = new THREE.TubeGeometry(curve, Math.min(240, r.points.length * 3), 0.52, 8, false);

      // Vertex colors along route: green/cyan for safe slope (<11°), amber for caution (>=11°)
      const posAttr = tubeGeo.attributes.position as THREE.BufferAttribute;
      const colors = new Float32Array(posAttr.count * 3);
      const safeCol = new THREE.Color(0x22d3ee);
      const warnCol = new THREE.Color(0xf59e0b);
      const radialSegs = 9; // 8 + 1

      for (let i = 0; i < posAttr.count; i++) {
        const ringIdx = Math.floor(i / radialSegs);
        const t = Math.min(1, ringIdx / Math.max(1, posAttr.count / radialSegs - 1));
        const ptIdx = Math.min(r.points.length - 1, Math.floor(t * (r.points.length - 1)));
        const slope = r.points[ptIdx].slopeDeg;
        const c = slope > 11 ? warnCol : safeCol;
        colors[i * 3] = c.r;
        colors[i * 3 + 1] = c.g;
        colors[i * 3 + 2] = c.b;
      }
      tubeGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

      const tubeMat = new THREE.MeshStandardMaterial({
        vertexColors: true,
        emissive: 0x0ea5e9,
        emissiveIntensity: 0.55,
        roughness: 0.25,
        metalness: 0.1,
      });
      const tubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
      routeGroup.add(tubeMesh);

      // Start & destination ring markers
      const endPt = r.points[r.points.length - 1];
      const destRing = new THREE.Mesh(
        new THREE.RingGeometry(1.6, 2.5, 28),
        new THREE.MeshBasicMaterial({
          color: 0x38bdf8,
          side: THREE.DoubleSide,
          polygonOffset: true,
          polygonOffsetFactor: -1,
        })
      );
      destRing.rotation.x = -Math.PI / 2;
      destRing.position.set(endPt.x, endPt.y + 0.35, endPt.z);
      routeGroup.add(destRing);

      // Precompute cumulative distance table for autopilot walking
      let acc = 0;
      evaState.routeCumDist.push(0);
      for (let i = 1; i < r.points.length; i++) {
        const a = r.points[i - 1];
        const b = r.points[i];
        acc += Math.hypot(b.x - a.x, b.z - a.z);
        evaState.routeCumDist.push(acc);
      }
      evaState.totalRouteLen = acc;

      requestRender();
    };

    const setEvaMode = (enabled: boolean) => {
      controls.enabled = !enabled;
      flyActive = false;

      if (enabled) {
        const site = MARS_SITES[propsRef.current.siteId];
        // If route exists, spawn at route start facing next waypoint; else near habitat
        const r = propsRef.current.route;
        if (r && r.points.length >= 2) {
          evaState.x = r.points[0].x;
          evaState.z = r.points[0].z;
          const dx = r.points[1].x - r.points[0].x;
          const dz = r.points[1].z - r.points[0].z;
          evaState.yaw = Math.atan2(-dx, -dz);
        } else {
          evaState.x = site.habitatPos.x + 12;
          evaState.z = site.habitatPos.z;
          evaState.yaw = -0.8;
        }
        evaState.pitch = -0.04;
        evaState.routeDistCursor = 0;
        updateSolLighting(propsRef.current.solHour);
        startLoop();
      } else {
        evaState.walkingRoute = false;
        headlamp.intensity = 0;
        // Pull back smoothly to orbital view centered on astronaut's last position
        const gy = sampleElevation(propsRef.current.siteId, evaState.x, evaState.z);
        flyLookTarget.set(evaState.x, gy, evaState.z);
        flyCamTarget.set(evaState.x - 95, gy + 115, evaState.z + 125);
        flyActive = true;
        requestRender();
      }
    };

    const handleCameraAction = (action: CameraAction) => {
      if (propsRef.current.evaMode) return;
      flyActive = true;
      if (action.type === 'reset') {
        const site = MARS_SITES[propsRef.current.siteId];
        flyLookTarget.set(site.habitatPos.x * 0.25, 2, site.habitatPos.z * 0.25);
        flyCamTarget.set(site.habitatPos.x * 0.25 - 68, 128, site.habitatPos.z * 0.25 + 188);
      } else if (action.type === 'flyTo' && action.x !== undefined && action.z !== undefined) {
        const gy = sampleElevation(propsRef.current.siteId, action.x, action.z);
        flyLookTarget.set(action.x, gy + 2, action.z);
        flyCamTarget.set(action.x - 52, gy + 58, action.z + 68);
      } else if (action.type === 'zoomIn' || action.type === 'zoomOut') {
        _vec3A.copy(camera.position).sub(controls.target);
        const factor = action.type === 'zoomIn' ? 0.68 : 1.42;
        const len = THREE.MathUtils.clamp(_vec3A.length() * factor, 28, 500);
        _vec3A.setLength(len);
        flyLookTarget.copy(controls.target);
        flyCamTarget.copy(controls.target).add(_vec3A);
      } else if (action.type === 'tilt') {
        _vec3A.copy(camera.position).sub(controls.target);
        const currentPolar = Math.acos(THREE.MathUtils.clamp(_vec3A.y / _vec3A.length(), -1, 1));
        const targetPolar = currentPolar > 0.72 ? 0.35 : 1.08; // toggle top-down vs oblique 3D
        const dist = _vec3A.length();
        const az = Math.atan2(_vec3A.x, _vec3A.z);
        flyLookTarget.copy(controls.target);
        flyCamTarget.set(
          controls.target.x + dist * Math.sin(targetPolar) * Math.sin(az),
          controls.target.y + dist * Math.cos(targetPolar),
          controls.target.z + dist * Math.sin(targetPolar) * Math.cos(az)
        );
      }
      requestRender();
    };

    const startRouteWalk = (walking: boolean) => {
      evaState.walkingRoute = walking;
      if (walking) {
        if (evaState.routeDistCursor >= evaState.totalRouteLen - 1) {
          evaState.routeDistCursor = 0;
        }
        startLoop();
      }
    };

    engineRef.current = {
      rebuildSite,
      updateLayer,
      updateSolLighting,
      updateRouteVisual,
      setEvaMode,
      handleCameraAction,
      startRouteWalk,
    };

    // Raycasting & Input handlers
    const raycaster = new THREE.Raycaster();
    const mouseNdc = new THREE.Vector2();
    let lastHoverTime = 0;

    const getCanvasNdc = (clientX: number, clientY: number) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouseNdc.x = ((clientX - rect.left) / rect.width) * 2 - 1;
      mouseNdc.y = -((clientY - rect.top) / rect.height) * 2 + 1;
    };

    const onPointerDown = (e: PointerEvent) => {
      pointerDownPos = { x: e.clientX, y: e.clientY };
      if (propsRef.current.evaMode) {
        isLookingEva = true;
        lastLookX = e.clientX;
        lastLookY = e.clientY;
      }
    };

    const onPointerMove = (e: PointerEvent) => {
      if (propsRef.current.evaMode) {
        if (isLookingEva) {
          const dx = e.clientX - lastLookX;
          const dy = e.clientY - lastLookY;
          lastLookX = e.clientX;
          lastLookY = e.clientY;
          evaState.yaw -= dx * 0.0038;
          evaState.pitch = THREE.MathUtils.clamp(evaState.pitch - dy * 0.0032, -0.75, 0.85);
        }
        return;
      }

      const now = performance.now();
      if (now - lastHoverTime < 65) return;
      lastHoverTime = now;

      if (!terrainMesh) return;
      getCanvasNdc(e.clientX, e.clientY);
      raycaster.setFromCamera(mouseNdc, camera);

      const poiHits = raycaster.intersectObjects(poiBeaconMeshes, true);
      if (poiHits.length > 0) {
        renderer.domElement.style.cursor = 'pointer';
      } else {
        renderer.domElement.style.cursor = propsRef.current.pickRouteMode ? 'crosshair' : 'grab';
      }

      const terrHits = raycaster.intersectObject(terrainMesh, false);
      if (terrHits.length > 0) {
        const pt = terrHits[0].point;
        const sample = sampleTerrainFull(propsRef.current.siteId, pt.x, pt.z);
        callbacksRef.current.onHoverSample(sample);
      } else {
        callbacksRef.current.onHoverSample(null);
      }
    };

    const onPointerUp = (e: PointerEvent) => {
      isLookingEva = false;
      const moved = Math.hypot(e.clientX - pointerDownPos.x, e.clientY - pointerDownPos.y);
      if (moved > 6 || propsRef.current.evaMode) return;

      getCanvasNdc(e.clientX, e.clientY);
      raycaster.setFromCamera(mouseNdc, camera);

      // 1. Check POI beacon click first
      const poiHits = raycaster.intersectObjects(poiBeaconMeshes, true);
      if (poiHits.length > 0) {
        const poiId = poiHits[0].object.userData.poiId as string | undefined;
        if (poiId) {
          const poi = MARS_SITES[propsRef.current.siteId].pois.find((p) => p.id === poiId) ?? null;
          if (poi) {
            if (propsRef.current.pickRouteMode) {
              callbacksRef.current.onTerrainClickForRoute(poi.x, poi.z);
            } else {
              callbacksRef.current.onSelectPoi(poi);
            }
            return;
          }
        }
      }

      // 2. Terrain click (for custom route waypoint picking)
      if (propsRef.current.pickRouteMode && terrainMesh) {
        const terrHits = raycaster.intersectObject(terrainMesh, false);
        if (terrHits.length > 0) {
          const pt = terrHits[0].point;
          callbacksRef.current.onTerrainClickForRoute(pt.x, pt.z);
        }
      }
    };

    const onKeyDown = (e: KeyboardEvent) => {
      keysDown[e.code] = true;
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keysDown[e.code] = false;
    };

    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    // Cancel scripted camera fly-to when user grabs controls
    controls.addEventListener('start', () => {
      flyActive = false;
    });

    // Render loop & on-demand pacing
    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let continuousActive = false;
    let lastClock = performance.now();
    let lastHudEmit = 0;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      if (!sync) {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      gl.flush();
      const poll = () => {
        const status = gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (status === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function stepSimulation(dt: number, now: number) {
      const { siteId: sId, evaMode: isEva, route: activeRoute, selectedPoiId: selId } = propsRef.current;

      // Subtle floating rotation on POI beacons and scale highlight on active selection
      for (let i = 0; i < poiBeaconMeshes.length; i++) {
        const b = poiBeaconMeshes[i];
        b.rotation.y += dt * 0.65;
        const targetScale = b.userData.poiId === selId ? 1.45 : 1.0;
        b.scale.setScalar(THREE.MathUtils.damp(b.scale.x, targetScale, 8, dt));
      }

      // Natural Mars Rover surface traverse hugging terrain slopes & spinning wheels
      if (roverRig) {
        roverTime += dt * 0.075; // realistic deliberate pace
        const cx = sId === 'jezero' ? -34 : -82;
        const cz = sId === 'jezero' ? -14 : 46;
        const rx = cx + Math.cos(roverTime) * 24 + Math.sin(roverTime * 2) * 5;
        const rz = cz + Math.sin(roverTime) * 16;
        const ry = sampleElevation(sId, rx, rz);

        const moveDist = Math.hypot(rx - roverLastX, rz - roverLastZ);
        const dirX = rx - roverLastX;
        const dirZ = rz - roverLastZ;
        roverLastX = rx;
        roverLastZ = rz;

        roverRig.group.position.set(rx, ry, rz);

        // Align rover up-axis to local terrain normal + smooth heading yaw
        const n = sampleTerrainNormal(sId, rx, rz, 2.2);
        _vec3B.set(n.nx, n.ny, n.nz).normalize();
        _quatA.setFromUnitVectors(_vec3Up, _vec3B);

        if (moveDist > 0.0001) {
          const yaw = Math.atan2(dirX, dirZ);
          _quatB.setFromAxisAngle(_vec3Up, yaw);
          _quatA.multiply(_quatB);
        }
        roverRig.group.quaternion.slerp(_quatA, Math.min(1, dt * 6));

        // Rotate all 6 wheels proportionally to distance traveled (wheel radius = 0.42m)
        const wheelSpin = moveDist / 0.42;
        for (let w = 0; w < roverRig.wheels.length; w++) {
          roverRig.wheels[w].rotation.x += wheelSpin;
        }
        // Subtle Mastcam-Z head scanning side-to-side
        roverRig.mastHead.rotation.y = Math.sin(now * 0.0009) * 0.65;
        roverRig.mastHead.rotation.x = Math.sin(now * 0.0005) * 0.12;
      }

      if (isEva) {
        const site = MARS_SITES[sId];
        const halfLimit = site.terrainScaleM * 0.47;
        let movedDist = 0;

        // Manual WASD / Arrow walking
        const forward =
          (keysDown['KeyW'] || keysDown['ArrowUp'] ? 1 : 0) -
          (keysDown['KeyS'] || keysDown['ArrowDown'] ? 1 : 0);
        const strafe =
          (keysDown['KeyD'] || keysDown['ArrowRight'] ? 1 : 0) -
          (keysDown['KeyA'] || keysDown['ArrowLeft'] ? 1 : 0);

        if (forward !== 0 || strafe !== 0) {
          evaState.walkingRoute = false;
          const speed = keysDown['ShiftLeft'] ? 14 : 7.5; // m/s simulated Marswalk pace
          const sinY = Math.sin(evaState.yaw);
          const cosY = Math.cos(evaState.yaw);
          const vx = (-sinY * forward + cosY * strafe) * speed * dt;
          const vz = (-cosY * forward - sinY * strafe) * speed * dt;

          const nextX = THREE.MathUtils.clamp(evaState.x + vx, -halfLimit, halfLimit);
          const nextZ = THREE.MathUtils.clamp(evaState.z + vz, -halfLimit, halfLimit);
          movedDist = Math.hypot(nextX - evaState.x, nextZ - evaState.z);
          evaState.x = nextX;
          evaState.z = nextZ;
        } else if (evaState.walkingRoute && activeRoute && activeRoute.points.length >= 2) {
          // Autopilot traverse along planned safe EVA route
          const walkSpeed = 12.0; // m/s brisk preview pace
          evaState.routeDistCursor += walkSpeed * dt;
          movedDist = walkSpeed * dt;

          if (evaState.routeDistCursor >= evaState.totalRouteLen) {
            evaState.routeDistCursor = evaState.totalRouteLen;
            evaState.walkingRoute = false;
            callbacksRef.current.onWalkComplete();
          }

          // Interpolate along cumulative distance table
          const cum = evaState.routeCumDist;
          let seg = 0;
          while (seg < cum.length - 2 && cum[seg + 1] < evaState.routeDistCursor) {
            seg++;
          }
          const segStart = cum[seg];
          const segEnd = cum[seg + 1];
          const frac = segEnd > segStart ? (evaState.routeDistCursor - segStart) / (segEnd - segStart) : 0;
          const p0 = activeRoute.points[seg];
          const p1 = activeRoute.points[seg + 1];

          evaState.x = THREE.MathUtils.lerp(p0.x, p1.x, frac);
          evaState.z = THREE.MathUtils.lerp(p0.z, p1.z, frac);

          const targetYaw = Math.atan2(-(p1.x - p0.x), -(p1.z - p0.z));
          // Shortest-angle smooth yaw interpolation
          let diff = targetYaw - evaState.yaw;
          while (diff > Math.PI) diff -= Math.PI * 2;
          while (diff < -Math.PI) diff += Math.PI * 2;
          evaState.yaw += diff * Math.min(1, dt * 4.5);
        }

        const sample = sampleTerrainFull(sId, evaState.x, evaState.z);
        const eyeY = sample.height + 1.85;

        // Subtle walking head-bob only when moving
        const bob = movedDist > 0.001 ? Math.sin(now * 0.012) * 0.06 : 0;
        camera.position.set(evaState.x, eyeY + bob, evaState.z);

        const lookDx = -Math.sin(evaState.yaw) * Math.cos(evaState.pitch);
        const lookDy = Math.sin(evaState.pitch);
        const lookDz = -Math.cos(evaState.yaw) * Math.cos(evaState.pitch);
        _vec3A.set(evaState.x + lookDx * 12, eyeY + lookDy * 12, evaState.z + lookDz * 12);
        camera.lookAt(_vec3A);

        // Update helmet headlamp
        headlamp.position.copy(camera.position);
        headlamp.target.position.copy(_vec3A);

        // Metabolic O2 & battery decay based on distance & slope
        if (movedDist > 0) {
          evaState.distanceWalkedM += movedDist;
          const slopeFactor = 1 + sample.slopeDeg * 0.04;
          evaState.oxygenPct = Math.max(0, evaState.oxygenPct - movedDist * 0.022 * slopeFactor);
          evaState.batteryPct = Math.max(0, evaState.batteryPct - movedDist * 0.012);
        } else {
          evaState.oxygenPct = Math.max(0, evaState.oxygenPct - dt * 0.015);
        }

        // Emit HUD telemetry & projected 2D markers (~15 Hz)
        if (now - lastHudEmit > 66) {
          lastHudEmit = now;
          const headingDeg = ((THREE.MathUtils.radToDeg(-evaState.yaw) % 360) + 360) % 360;
          callbacksRef.current.onEvaTelemetry({
            x: evaState.x,
            z: evaState.z,
            elevationM: site.baseElevationM + sample.height,
            slopeDeg: sample.slopeDeg,
            radiationMsv: sample.radiationMsv,
            thermalInertia: sample.thermalInertia,
            mineralCode: sample.mineralCode,
            headingDeg,
            oxygenPct: evaState.oxygenPct,
            batteryPct: evaState.batteryPct,
            distanceWalkedM: evaState.distanceWalkedM,
            routeProgress:
              evaState.totalRouteLen > 0 ? evaState.routeDistCursor / evaState.totalRouteLen : 0,
          });

          const w = renderer.domElement.clientWidth;
          const h = renderer.domElement.clientHeight;
          const projected: ProjectedMarker[] = site.pois.map((poi) => {
            const py = sampleElevation(sId, poi.x, poi.z) + 4.2;
            _vec3B.set(poi.x, py, poi.z);
            const distM = _vec3B.distanceTo(camera.position);
            _vec3C.copy(_vec3B).project(camera);
            const inFront = _vec3C.z < 1 && _vec3C.z > -1;
            const sx = ((_vec3C.x + 1) / 2) * w;
            const sy = (-(_vec3C.y - 1) / 2) * h;
            const onScreen = inFront && sx > 40 && sx < w - 40 && sy > 40 && sy < h - 40;
            return {
              id: poi.id,
              name: poi.name,
              category: poi.category,
              screenX: sx,
              screenY: sy,
              distanceM: distM,
              visible: onScreen,
            };
          });
          callbacksRef.current.onProjectedMarkers(projected);
          callbacksRef.current.onCameraAzimuthChange(headingDeg);
        }
      } else {
        // Orbital Google-Earth style smooth fly-to damping
        if (flyActive) {
          const lambda = 4.8;
          camera.position.x = THREE.MathUtils.damp(camera.position.x, flyCamTarget.x, lambda, dt);
          camera.position.y = THREE.MathUtils.damp(camera.position.y, flyCamTarget.y, lambda, dt);
          camera.position.z = THREE.MathUtils.damp(camera.position.z, flyCamTarget.z, lambda, dt);
          controls.target.x = THREE.MathUtils.damp(controls.target.x, flyLookTarget.x, lambda, dt);
          controls.target.y = THREE.MathUtils.damp(controls.target.y, flyLookTarget.y, lambda, dt);
          controls.target.z = THREE.MathUtils.damp(controls.target.z, flyLookTarget.z, lambda, dt);

          if (
            camera.position.distanceTo(flyCamTarget) < 0.6 &&
            controls.target.distanceTo(flyLookTarget) < 0.4
          ) {
            flyActive = false;
          }
        }
        controls.update();

        // Keep compass azimuth synced in orbital view
        if (now - lastHudEmit > 90) {
          lastHudEmit = now;
          _vec3A.copy(controls.target).sub(camera.position);
          const azDeg = ((THREE.MathUtils.radToDeg(Math.atan2(_vec3A.x, -_vec3A.z)) % 360) + 360) % 360;
          callbacksRef.current.onCameraAzimuthChange(azDeg);
        }
      }
    }

    function requestRender() {
      if (continuousActive) return;
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame((now) => {
        renderDirty = false;
        const dt = Math.min(0.1, (now - lastClock) / 1000);
        lastClock = now;

        stepSimulation(dt, now);
        renderer.render(scene, camera);

        const done = () => {
          renderBusy = false;
          if (flyActive || renderDirty) {
            requestRender();
          }
        };
        if (isSoftwareGl) afterDraw(done);
        else done();
      });
    }

    function startLoop() {
      if (continuousActive) return;
      continuousActive = true;
      lastClock = performance.now();

      const tick = () => {
        const now = performance.now();
        const dt = Math.min(0.08, (now - lastClock) / 1000);
        lastClock = now;

        stepSimulation(dt, now);
        renderer.render(scene, camera);

        if (isSoftwareGl) {
          afterDraw(tick);
        } else {
          frameId = requestAnimationFrame(tick);
        }
      };

      if (isSoftwareGl) afterDraw(tick);
      else frameId = requestAnimationFrame(tick);
    }

    controls.addEventListener('change', () => {
      if (!propsRef.current.evaMode && !continuousActive) requestRender();
    });

    // Resize handling
    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      if (!continuousActive) requestRender();
    };
    window.addEventListener('resize', onResize);

    // Initial scene build
    rebuildSite(propsRef.current.siteId);
    updateSolLighting(propsRef.current.solHour);
    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }
    startLoop();

    return () => {
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', handleContextRestored);

      disposeSiteObjects();
      routeGroup.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          (obj as THREE.Mesh).geometry?.dispose();
        }
      });
      skyGeo.dispose();
      skyMat.dispose();
      starGeo.dispose();
      starMat.dispose();
      skirtMesh.geometry.dispose();
      (skirtMesh.material as THREE.Material).dispose();
      controls.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
      engineRef.current = null;
    };
  }, []);

  // React prop bridges to imperative Three.js engine
  useEffect(() => {
    engineRef.current?.rebuildSite(siteId);
  }, [siteId]);

  useEffect(() => {
    engineRef.current?.updateLayer(activeLayer);
  }, [activeLayer]);

  useEffect(() => {
    engineRef.current?.updateSolLighting(solHour);
  }, [solHour]);

  useEffect(() => {
    engineRef.current?.updateRouteVisual(route);
  }, [route]);

  useEffect(() => {
    engineRef.current?.setEvaMode(evaMode);
  }, [evaMode]);

  useEffect(() => {
    engineRef.current?.startRouteWalk(isWalkingRoute);
  }, [isWalkingRoute]);

  useEffect(() => {
    if (cameraAction) {
      engineRef.current?.handleCameraAction(cameraAction);
    }
  }, [cameraAction]);

  return (
    <div className="relative w-full h-full">
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
      {contextLost && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#07090E] text-slate-200 z-50">
          <div className="text-center max-w-md px-6 py-5 border border-white/10 rounded-xl bg-[#0B0E17]">
            <p className="font-display text-lg font-semibold mb-1">WebGL Context Suspended</p>
            <p className="text-sm text-slate-400">
              Your browser temporarily paused the 3D terrain renderer. Reload or focus this tab to
              restore Martian surface telemetry.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

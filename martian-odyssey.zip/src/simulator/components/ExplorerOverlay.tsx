import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  ChevronDown,
  ChevronUp,
  Compass,
  Crosshair,
  Eye,
  Layers,
  MapPin,
  Minus,
  Navigation,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Route,
  Search,
  Sun,
  X,
} from 'lucide-react';
import {
  MARS_SITES,
  MarsPoi,
  MarsSiteConfig,
  OverlayLayerId,
  SITE_LIST,
  SiteId,
} from '../data/marsSites';
import { EvaRouteResult } from '../engine/pathfinding';
import { TerrainSample, getMineralLabel } from '../engine/terrainMath';

type DockTab = 'layers' | 'route' | 'sol';

interface ExplorerOverlayProps {
  site: MarsSiteConfig;
  activeLayer: OverlayLayerId;
  solHour: number;
  isSolPlaying: boolean;
  pickRouteMode: boolean;
  route: EvaRouteResult | null;
  routeTargetName: string;
  prioritizeShelter: boolean;
  selectedPoi: MarsPoi | null;
  hoverSample: TerrainSample | null;
  azimuthDeg: number;
  dockCollapsed: boolean;
  onSelectSite: (id: SiteId) => void;
  onSelectLayer: (layer: OverlayLayerId) => void;
  onChangeSolHour: (hour: number) => void;
  onToggleSolPlay: () => void;
  onEnterEvaMode: () => void;
  onWalkRouteInEva: () => void;
  onTogglePickRouteMode: () => void;
  onTogglePrioritizeShelter: () => void;
  onPlanRouteToPoi: (poi: MarsPoi) => void;
  onClearRoute: () => void;
  onSelectPoi: (poi: MarsPoi | null) => void;
  onFlyToPoi: (poi: MarsPoi) => void;
  onCameraAction: (type: 'reset' | 'zoomIn' | 'zoomOut' | 'tilt') => void;
  onToggleDock: () => void;
  onBackToHome?: () => void;
}

function formatSolTime(hour: number): string {
  const h = Math.floor(hour) % 24;
  const m = Math.floor((hour - Math.floor(hour)) * 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export const ExplorerOverlay: React.FC<ExplorerOverlayProps> = ({
  site,
  activeLayer,
  solHour,
  isSolPlaying,
  pickRouteMode,
  route,
  routeTargetName,
  prioritizeShelter,
  selectedPoi,
  hoverSample,
  azimuthDeg,
  dockCollapsed,
  onSelectSite,
  onSelectLayer,
  onChangeSolHour,
  onToggleSolPlay,
  onEnterEvaMode,
  onWalkRouteInEva,
  onTogglePickRouteMode,
  onTogglePrioritizeShelter,
  onPlanRouteToPoi,
  onClearRoute,
  onSelectPoi,
  onFlyToPoi,
  onCameraAction,
  onToggleDock,
  onBackToHome,
}) => {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<DockTab>('layers');

  const searchResults = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const entries: { kind: 'site' | 'poi'; siteId: SiteId; title: string; sub: string; poi?: MarsPoi }[] = [];
    SITE_LIST.forEach((s) => {
      if (!q || s.name.toLowerCase().includes(q) || s.region.toLowerCase().includes(q)) {
        entries.push({
          kind: 'site',
          siteId: s.id,
          title: s.name,
          sub: `${s.coordinates} · ${s.region}`,
        });
      }
      s.pois.forEach((p) => {
        if (!q || p.name.toLowerCase().includes(q) || p.subtitle.toLowerCase().includes(q)) {
          entries.push({
            kind: 'poi',
            siteId: s.id,
            title: p.name,
            sub: `${s.name} · ${p.subtitle}`,
            poi: p,
          });
        }
      });
    });
    return entries.slice(0, 8);
  }, [searchQuery]);

  // Environmental calculations from Sol hour
  const sunElevation = Math.sin(((solHour - 6) / 12.5) * Math.PI);
  const solarOutputKw = Math.max(0, Math.round(Math.max(0, sunElevation) * 18.4 * 10) / 10);
  const surfaceTempC = Math.round(-68 + Math.max(-0.2, sunElevation) * 52);

  const layerOptions: { id: OverlayLayerId; label: string; source: string }[] = [
    { id: 'natural', label: 'Natural Mars', source: 'HiRISE True Color' },
    { id: 'topography', label: 'Elevation & Slope', source: 'MOLA / HiRISE DEM' },
    { id: 'radiation', label: 'Radiation & Shelters', source: 'Curiosity RAD' },
    { id: 'thermal', label: 'Thermal & Minerals', source: 'THEMIS / CRISM' },
  ];

  const layerLegend: Record<OverlayLayerId, { title: string; stops: { color: string; label: string }[] }> = {
    natural: {
      title: 'HiRISE Surface Regolith & Outcrops',
      stops: [
        { color: '#C48258', label: 'Iron-Oxide Dust' },
        { color: '#7A442E', label: 'Basaltic Bedrock' },
        { color: '#C29872', label: 'Sulfate & Clay Strata' },
      ],
    },
    topography: {
      title: 'EVA Traversability Grade (2.5m Contours)',
      stops: [
        { color: '#20946C', label: '<10° Safe' },
        { color: '#E4B22A', label: '10°–15° Caution' },
        { color: '#E13E2E', label: '>15° Tip Hazard' },
      ],
    },
    radiation: {
      title: 'Modeled Surface Dose (mSv/day)',
      stops: [
        { color: '#0EA5E9', label: '<0.35 Shelter' },
        { color: '#10B981', label: '0.45 Shielded' },
        { color: '#F59E0B', label: '0.65 Ambient' },
        { color: '#EF4444', label: '>0.75 Exposed Ridge' },
      ],
    },
    thermal: {
      title: 'Thermal Inertia (TIU) & CRISM Minerals',
      stops: [
        { color: '#D94678', label: '<250 Loose Dust' },
        { color: '#3B82CE', label: '>500 Bedrock' },
        { color: '#34D399', label: 'Hydrated Clays' },
        { color: '#FBBF24', label: 'Carbonates' },
        { color: '#A78BFA', label: 'Sulfates' },
      ],
    },
  };

  return (
    <div className="absolute inset-0 z-10 pointer-events-none">
      {/* TOP-LEFT: Back Link + Location Search & Landing Site Bar */}
      <div className="absolute top-4 left-4 w-80 sm:w-96 flex flex-col gap-2 pointer-events-auto">
        {onBackToHome && (
          <button
            type="button"
            onClick={onBackToHome}
            className="w-fit flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0B0E17]/90 hover:bg-[#141A29] border border-white/12 text-xs font-medium text-slate-200 hover:text-white transition-colors whitespace-nowrap shadow-md cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5 text-amber-400" />
            <span>Back to Martian Odyssey</span>
          </button>
        )}
        <div className="bg-[#0B0E17]/90 border border-white/12 rounded-xl shadow-lg">
          <div className="flex items-center gap-2.5 px-3.5 py-2.5">
            <Search className="w-4 h-4 text-amber-400 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onFocus={() => setSearchOpen(true)}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setSearchOpen(true);
              }}
              placeholder={`Search Mars sites (${site.name})`}
              className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-400 focus:outline-none"
            />
            {searchQuery ? (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="text-slate-400 hover:text-slate-200 cursor-pointer"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setSearchOpen((v) => !v)}
                className="text-slate-400 hover:text-slate-200 cursor-pointer"
                aria-label="Toggle sites menu"
              >
                {searchOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
            )}
          </div>

          {/* Site Quick Switcher Row */}
          <div className="flex items-center gap-1 px-2.5 pb-2.5 border-t border-white/8 pt-2">
            {SITE_LIST.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => {
                  onSelectSite(s.id);
                  setSearchOpen(false);
                }}
                className={`flex-1 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap truncate cursor-pointer ${
                  site.id === s.id
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'text-slate-300 hover:bg-white/8 hover:text-white'
                }`}
              >
                {s.name}
              </button>
            ))}
          </div>

          {/* Search Dropdown */}
          {searchOpen && (
            <div className="border-t border-white/10 max-h-64 overflow-y-auto py-1.5">
              {searchResults.length === 0 ? (
                <div className="px-4 py-3 text-xs text-slate-400">No matching Martian targets.</div>
              ) : (
                searchResults.map((item, idx) => (
                  <button
                    key={`${item.siteId}-${item.title}-${idx}`}
                    type="button"
                    onClick={() => {
                      if (item.siteId !== site.id) {
                        onSelectSite(item.siteId);
                      }
                      if (item.poi) {
                        onSelectPoi(item.poi);
                        onFlyToPoi(item.poi);
                      }
                      setSearchOpen(false);
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-white/8 flex items-center gap-2.5 transition-colors cursor-pointer"
                  >
                    <MapPin
                      className={`w-3.5 h-3.5 shrink-0 ${
                        item.kind === 'site' ? 'text-amber-400' : 'text-sky-400'
                      }`}
                    />
                    <div className="min-w-0">
                      <div className="text-xs font-medium text-slate-100 truncate">{item.title}</div>
                      <div className="text-[11px] text-slate-400 truncate">{item.sub}</div>
                    </div>
                  </button>
                ))
              )}
            </div>
          )}
        </div>

        {/* Clean Unboxed Site Metadata Line */}
        <div className="mt-2 px-1 flex items-center gap-2 text-xs text-slate-300 drop-shadow">
          <span className="font-display font-semibold text-white">{site.name}</span>
          <span aria-hidden="true" className="text-slate-500">·</span>
          <span className="font-mono-tabular text-slate-200">{site.coordinates}</span>
          <span aria-hidden="true" className="text-slate-500">·</span>
          <span className="font-mono-tabular text-slate-300">{site.baseElevationM} m</span>
        </div>

        {/* Selected POI Inspector Card (only when a target is clicked) */}
        {selectedPoi && (
          <div className="mt-3 bg-[#0B0E17]/92 border border-white/14 rounded-xl p-4 shadow-lg space-y-3">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[11px] text-amber-400 font-medium">{selectedPoi.subtitle}</div>
                <h3 className="font-display text-base font-semibold text-white truncate">
                  {selectedPoi.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => onSelectPoi(null)}
                className="p-1 text-slate-400 hover:text-white rounded cursor-pointer"
                aria-label="Close inspector"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">{selectedPoi.description}</p>

            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/10 text-xs">
              <div>
                <div className="text-[11px] text-slate-400">Thermal Inertia</div>
                <div className="font-mono-tabular font-semibold text-slate-100">
                  {selectedPoi.thermalInertia} TIU
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-400">Radiation</div>
                <div className="font-mono-tabular font-semibold text-slate-100">
                  {selectedPoi.radiationMsvDay.toFixed(2)} mSv/d
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-400">Dataset</div>
                <div className="text-slate-200 truncate">{selectedPoi.instrumentSource}</div>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  onPlanRouteToPoi(selectedPoi);
                  setActiveTab('route');
                }}
                className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                <Route className="w-3.5 h-3.5" />
                <span>Plan Safe Route</span>
              </button>
              <button
                type="button"
                onClick={() => onFlyToPoi(selectedPoi)}
                className="px-3 py-2 rounded-lg bg-white/8 hover:bg-white/14 text-slate-100 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer"
              >
                Fly To
              </button>
            </div>
          </div>
        )}
      </div>

      {/* TOP-RIGHT: Sol Clock & Primary EVA Helmet Mode Action */}
      <div className="absolute top-4 right-4 flex items-center gap-2.5 pointer-events-auto">
        <div className="hidden md:flex items-center gap-3 bg-[#0B0E17]/90 border border-white/12 rounded-xl px-3.5 py-2 text-xs">
          <div className="flex items-center gap-1.5 text-amber-300 font-mono-tabular">
            <Sun className="w-3.5 h-3.5" />
            <span>{formatSolTime(solHour)} MTC</span>
          </div>
          <span className="text-slate-600">|</span>
          <span className="font-mono-tabular text-slate-300">{surfaceTempC} °C</span>
          <span className="text-slate-600">|</span>
          <span className="font-mono-tabular text-sky-300">{solarOutputKw} kW Solar</span>
        </div>

        <button
          type="button"
          onClick={onEnterEvaMode}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-semibold shadow-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Eye className="w-4 h-4" />
          <span>EVA Helmet View</span>
        </button>
      </div>

      {/* Pick Route Hint Banner (only when user clicked Pick on Terrain) */}
      {pickRouteMode && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 bg-[#0B0E17]/92 border border-sky-400/50 rounded-xl px-4 py-2 text-xs text-sky-200 flex items-center gap-3 pointer-events-auto">
          <Crosshair className="w-4 h-4 text-sky-400" />
          <span>Click anywhere on the 3D terrain or a beacon to compute a safe EVA route</span>
          <button
            type="button"
            onClick={onTogglePickRouteMode}
            className="text-slate-400 hover:text-white cursor-pointer"
          >
            Cancel
          </button>
        </div>
      )}

      {/* BOTTOM-LEFT: Quiet Live Cursor Terrain Sensor Readout */}
      <div className="hidden lg:flex absolute bottom-5 left-4 items-center gap-2.5 bg-[#0B0E17]/88 border border-white/10 rounded-lg px-3 py-1.5 text-[11px] font-mono-tabular text-slate-300">
        {hoverSample ? (
          <>
            <span>Elev {Math.round(site.baseElevationM + hoverSample.height)} m</span>
            <span className="text-slate-600">·</span>
            <span className={hoverSample.slopeDeg > 15 ? 'text-rose-400' : 'text-slate-200'}>
              Slope {hoverSample.slopeDeg.toFixed(1)}°
            </span>
            <span className="text-slate-600">·</span>
            <span>RAD {hoverSample.radiationMsv.toFixed(2)} mSv/d</span>
            <span className="text-slate-600">·</span>
            <span>{Math.round(hoverSample.thermalInertia)} TIU</span>
            <span className="text-slate-600">·</span>
            <span className="text-sky-300">{getMineralLabel(hoverSample.mineralCode)}</span>
          </>
        ) : (
          <span className="text-slate-400">
            Hover terrain for elevation, slope, RAD & thermal telemetry · Drag to orbit
          </span>
        )}
      </div>

      {/* BOTTOM-RIGHT: Google Earth-style Navigation Controls */}
      <div className="absolute bottom-5 right-4 flex flex-col items-center gap-1.5 pointer-events-auto">
        <button
          type="button"
          onClick={() => onCameraAction('reset')}
          title="Reset North-Up View"
          className="w-10 h-10 rounded-xl bg-[#0B0E17]/90 hover:bg-[#141A29] border border-white/12 flex items-center justify-center text-slate-200 transition-colors cursor-pointer"
        >
          <Compass
            className="w-4 h-4 text-amber-400 transition-transform duration-150"
            style={{ transform: `rotate(${-azimuthDeg}deg)` }}
          />
        </button>

        <div className="flex flex-col bg-[#0B0E17]/90 border border-white/12 rounded-xl overflow-hidden">
          <button
            type="button"
            onClick={() => onCameraAction('tilt')}
            title="Toggle 2D / 3D Tilt"
            className="w-10 h-9 hover:bg-white/10 flex items-center justify-center text-[11px] font-semibold text-slate-200 border-b border-white/10 cursor-pointer"
          >
            3D
          </button>
          <button
            type="button"
            onClick={() => onCameraAction('zoomIn')}
            title="Zoom In"
            className="w-10 h-9 hover:bg-white/10 flex items-center justify-center text-slate-200 border-b border-white/10 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => onCameraAction('zoomOut')}
            title="Zoom Out"
            className="w-10 h-9 hover:bg-white/10 flex items-center justify-center text-slate-200 border-b border-white/10 cursor-pointer"
          >
            <Minus className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => onCameraAction('reset')}
            title="Reset Camera"
            className="w-10 h-9 hover:bg-white/10 flex items-center justify-center text-slate-200 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* BOTTOM-CENTER: Collapsible Control Dock (Zero Viewport Occlusion) */}
      <div
        className={`absolute bottom-5 left-1/2 -translate-x-1/2 w-[min(680px,calc(100vw-8rem))] pointer-events-auto transition-transform duration-200 ${
          dockCollapsed ? 'translate-y-[calc(100%-30px)]' : 'translate-y-0'
        }`}
      >
        {/* Collapse / Expand Handle */}
        <div className="flex justify-center">
          <button
            type="button"
            onClick={onToggleDock}
            className="flex items-center gap-1.5 px-3.5 py-1 rounded-t-lg bg-[#0B0E17]/92 border border-b-0 border-white/12 text-[11px] font-medium text-slate-300 hover:text-white cursor-pointer"
          >
            {dockCollapsed ? (
              <>
                <ChevronUp className="w-3.5 h-3.5 text-amber-400" />
                <span>Show Controls (H)</span>
              </>
            ) : (
              <>
                <ChevronDown className="w-3.5 h-3.5 text-amber-400" />
                <span>Hide Controls (H)</span>
              </>
            )}
          </button>
        </div>

        {/* Main Dock Body */}
        <div className="bg-[#0B0E17]/92 border border-white/12 rounded-xl p-3 shadow-xl">
          {/* Tab Strip */}
          <div className="flex items-center justify-between gap-3 pb-2.5 border-b border-white/10">
            <div className="flex items-center gap-1 bg-white/5 p-1 rounded-lg">
              <button
                type="button"
                onClick={() => setActiveTab('layers')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === 'layers'
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Data Layers</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('route')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === 'route'
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <Route className="w-3.5 h-3.5" />
                <span>EVA Route</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('sol')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === 'sol'
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <Sun className="w-3.5 h-3.5" />
                <span>Sol Lighting</span>
              </button>
            </div>

            <div className="hidden sm:block text-[11px] text-slate-400 truncate">
              {site.missionRef}
            </div>
          </div>

          {/* Tab 1: Data Layers */}
          {activeTab === 'layers' && (
            <div className="pt-2.5 space-y-2.5">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                {layerOptions.map((layer) => (
                  <button
                    key={layer.id}
                    type="button"
                    onClick={() => onSelectLayer(layer.id)}
                    className={`text-left px-3 py-2 rounded-lg border transition-colors cursor-pointer ${
                      activeLayer === layer.id
                        ? 'bg-sky-500/15 border-sky-400/60 text-white'
                        : 'bg-white/4 border-white/8 text-slate-300 hover:bg-white/8'
                    }`}
                  >
                    <div className="text-xs font-medium truncate">{layer.label}</div>
                    <div className="text-[10px] text-slate-400 truncate">{layer.source}</div>
                  </button>
                ))}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-[11px]">
                <span className="text-slate-400">{layerLegend[activeLayer].title}</span>
                <div className="flex flex-wrap items-center gap-3">
                  {layerLegend[activeLayer].stops.map((st) => (
                    <span key={st.label} className="flex items-center gap-1.5 text-slate-200">
                      <span
                        className="w-2.5 h-2.5 rounded-sm inline-block shrink-0"
                        style={{ backgroundColor: st.color }}
                      />
                      <span>{st.label}</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Safe EVA Route Planner */}
          {activeTab === 'route' && (
            <div className="pt-2.5 space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-1.5">
                  {site.pois
                    .filter((p) => p.category !== 'habitat')
                    .map((poi) => (
                      <button
                        key={poi.id}
                        type="button"
                        onClick={() => onPlanRouteToPoi(poi)}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                          routeTargetName === poi.name
                            ? 'bg-sky-500/20 border border-sky-400/60 text-sky-200'
                            : 'bg-white/6 hover:bg-white/12 text-slate-200 border border-transparent'
                        }`}
                      >
                        {poi.name}
                      </button>
                    ))}
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={onTogglePickRouteMode}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap cursor-pointer ${
                      pickRouteMode
                        ? 'bg-sky-500 text-slate-950 border-sky-400 font-semibold'
                        : 'bg-white/6 text-slate-200 border-white/10 hover:bg-white/12'
                    }`}
                  >
                    <Crosshair className="w-3.5 h-3.5" />
                    <span>Pick Point</span>
                  </button>

                  <button
                    type="button"
                    onClick={onTogglePrioritizeShelter}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap cursor-pointer ${
                      prioritizeShelter
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/50'
                        : 'bg-white/6 text-slate-300 border-white/10 hover:bg-white/12'
                    }`}
                  >
                    {prioritizeShelter ? 'Shelter Bias: On' : 'Shelter Bias: Off'}
                  </button>
                </div>
              </div>

              {route ? (
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/10">
                  <div className="flex flex-wrap items-center gap-4 text-xs">
                    <div>
                      <span className="text-slate-400">Dist </span>
                      <span className="font-mono-tabular font-semibold text-white">
                        {Math.round(route.totalDistanceM)} m
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400">Max Slope </span>
                      <span
                        className={`font-mono-tabular font-semibold ${
                          route.maxSlopeDeg > 15 ? 'text-amber-400' : 'text-emerald-400'
                        }`}
                      >
                        {route.maxSlopeDeg.toFixed(1)}°
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400">Est. Time </span>
                      <span className="font-mono-tabular font-semibold text-white">
                        {Math.round(route.estimatedMinutes)} min
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400">O₂ Burn </span>
                      <span className="font-mono-tabular font-semibold text-sky-300">
                        -{route.oxygenCostPct.toFixed(1)}%
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400">Dose </span>
                      <span className="font-mono-tabular font-semibold text-slate-200">
                        {route.cumulativeDoseMsv.toFixed(3)} mSv
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={onClearRoute}
                      className="px-2.5 py-1.5 rounded-lg text-xs text-slate-300 hover:text-white hover:bg-white/8 cursor-pointer"
                    >
                      Clear
                    </button>
                    <button
                      type="button"
                      onClick={onWalkRouteInEva}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>Walk Route in EVA</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-xs text-slate-400 pt-1">
                  Select a scientific target or pick any terrain point to calculate a slope-safe EVA path.
                </div>
              )}
            </div>
          )}

          {/* Tab 3: Sol Time & Lighting */}
          {activeTab === 'sol' && (
            <div className="pt-2.5 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3 flex-1 min-w-[220px]">
                <button
                  type="button"
                  onClick={onToggleSolPlay}
                  className="flex items-center justify-center w-8 h-8 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 shrink-0 cursor-pointer"
                  aria-label={isSolPlaying ? 'Pause Sol cycle' : 'Play Sol cycle'}
                >
                  {isSolPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </button>
                <div className="flex-1">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-slate-300">Martian Solar Time</span>
                    <span className="font-mono-tabular font-semibold text-amber-300">
                      {formatSolTime(solHour)} MTC
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={24.6}
                    step={0.1}
                    value={solHour}
                    onChange={(e) => onChangeSolHour(parseFloat(e.target.value))}
                    className="w-full mars-slider"
                  />
                </div>
              </div>

              <div className="flex items-center gap-4 text-xs">
                <div>
                  <div className="text-[11px] text-slate-400">Solar Array</div>
                  <div className="font-mono-tabular font-semibold text-sky-300">
                    {solarOutputKw} kW
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">Surface Temp</div>
                  <div className="font-mono-tabular font-semibold text-slate-100">
                    {surfaceTempC} °C
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">Lighting</div>
                  <div className="text-slate-200">
                    {sunElevation > 0.12
                      ? 'Martian Daylight'
                      : sunElevation > -0.12
                        ? 'Blue Twilight'
                        : 'Starlit Night'}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Subtle site switch shortcut / attribution */}
      <span className="sr-only">
        {MARS_SITES[site.id].summary}
      </span>
    </div>
  );
};

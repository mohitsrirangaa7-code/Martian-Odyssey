import { MARS_SITES, SiteId } from '../data/marsSites';

// Fast deterministic 2D hash & value noise
function hash2(ix: number, iz: number, seed: number): number {
  let n = Math.imul(ix, 374761393) + Math.imul(iz, 668265263) + Math.imul(seed, 1442695041);
  n = (n ^ (n >>> 13)) * 1274126177;
  return ((n ^ (n >>> 16)) >>> 0) / 4294967295;
}

function smoothstep(t: number): number {
  return t * t * (3 - 2 * t);
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

export function noise2D(x: number, z: number, seed = 101): number {
  const ix = Math.floor(x);
  const iz = Math.floor(z);
  const fx = smoothstep(x - ix);
  const fz = smoothstep(z - iz);

  const v00 = hash2(ix, iz, seed);
  const v10 = hash2(ix + 1, iz, seed);
  const v01 = hash2(ix, iz + 1, seed);
  const v11 = hash2(ix + 1, iz + 1, seed);

  return lerp(lerp(v00, v10, fx), lerp(v01, v11, fx), fz) * 2 - 1;
}

export function fbm(x: number, z: number, octaves = 5, seed = 101): number {
  let value = 0;
  let amp = 0.5;
  let freq = 1;
  for (let i = 0; i < octaves; i++) {
    value += amp * noise2D(x * freq, z * freq, seed + i * 31);
    freq *= 2.03;
    amp *= 0.5;
  }
  return value;
}

function ridgeFbm(x: number, z: number, octaves = 4, seed = 307): number {
  let value = 0;
  let amp = 0.5;
  let freq = 1;
  for (let i = 0; i < octaves; i++) {
    const n = 1 - Math.abs(noise2D(x * freq, z * freq, seed + i * 19));
    value += amp * n * n;
    freq *= 2.1;
    amp *= 0.5;
  }
  return value;
}

function craterBowl(
  x: number,
  z: number,
  cx: number,
  cz: number,
  radius: number,
  depth: number,
  rimHeight: number
): number {
  const dx = x - cx;
  const dz = z - cz;
  const r = Math.sqrt(dx * dx + dz * dz) / radius;
  if (r > 1.8) return 0;
  if (r < 1.0) {
    const bowl = (r * r - 1) * depth;
    const rim = rimHeight * Math.exp(-Math.pow((r - 1.0) / 0.16, 2));
    return bowl + rim;
  }
  return rimHeight * Math.exp(-Math.pow((r - 1.0) / 0.22, 2));
}

function flattenPad(
  x: number,
  z: number,
  cx: number,
  cz: number,
  radius: number,
  currentH: number,
  targetH: number
): number {
  const d = Math.hypot(x - cx, z - cz);
  if (d >= radius * 1.8) return currentH;
  const t = Math.max(0, Math.min(1, (d - radius * 0.6) / (radius * 1.2)));
  const s = t * t * (3 - 2 * t);
  return lerp(targetH, currentH, s);
}

export function sampleElevation(siteId: SiteId, x: number, z: number): number {
  const site = MARS_SITES[siteId];

  if (siteId === 'jezero') {
    // Broad paleolake basin gently sloping downward North (-Z) to South (+Z)
    let h = fbm(x * 0.0055, z * 0.0055, 5, 11) * 7.8;
    h += fbm(x * 0.022, z * 0.022, 3, 29) * 1.9;
    h += -z * 0.022;

    // Western & Northwestern Jezero Crater inner rim uplift (x < -145 or outer NW)
    const rimArc = Math.max(0, (-x - 140) / 160) + Math.max(0, (-z - 190) / 140) * 0.65;
    if (rimArc > 0) {
      h += Math.pow(Math.min(1.5, rimArc), 1.45) * 34;
    }

    // Breached Neretva Vallis inlet river gorge cutting through the western/NW rim
    // Valley runs roughly from (-280, -145) through (-158, -88) into delta apex (-120, -68)
    const vx = -120 - -280;
    const vz = -68 - -145;
    const vLenSq = vx * vx + vz * vz;
    const tProj = Math.max(0, Math.min(1, ((x - -280) * vx + (z - -145) * vz) / vLenSq));
    const gorgeDist = Math.hypot(x - (-280 + tProj * vx), z - (-145 + tProj * vz));
    if (gorgeDist < 42) {
      const carve = Math.exp(-(gorgeDist * gorgeDist) / (2 * 16 * 16));
      h -= carve * 24;
    }

    // Terraced Neretva Fan Delta spreading East-Southeast from (-125, -70) toward (-70, -45)
    const dxDelta = (x + 92) * 0.85 + (z + 58) * 0.32;
    const dzDelta = -(x + 92) * 0.32 + (z + 58) * 1.15;
    const deltaDist = Math.hypot(dxDelta, dzDelta);
    const deltaShelf = Math.max(0, 1 - deltaDist / 88);
    if (deltaShelf > 0) {
      h += Math.pow(deltaShelf, 1.35) * 15.5;
      if (deltaShelf > 0.14) {
        h += Math.sin(deltaShelf * 15) * 0.52; // Foreset strata benches
      }
    }

    // Belva Crater (~900 m-scale bowl crater) at (128, 58) exposing dipping beds & western alcove
    h += craterBowl(x, z, 134, 58, 46, 15.5, 7.2);

    // Secondary craterlets on crater floor
    h += craterBowl(x, z, -24, -148, 24, 5.8, 2.0);
    h += craterBowl(x, z, 158, -112, 30, 7.2, 2.4);

    // Subtle low-relief Séítah ribbed olivine trough around (-12, 124)
    const seitahDist = Math.hypot((x + 12) * 0.85, z - 124);
    if (seitahDist < 68) {
      const w = 1 - seitahDist / 68;
      h -= w * 2.4;
      h += Math.sin(x * 0.22 + z * 0.16) * 0.55 * w; // Aeolian megaripples
    }

    // Smooth landing pads around Octavia E. Butler Outpost, MAV, Solar, and Comms
    const habBase = -1.6;
    h = flattenPad(x, z, site.habitatPos.x, site.habitatPos.z, 22, h, habBase);
    h = flattenPad(x, z, site.mavPos.x, site.mavPos.z, 20, h, habBase - 0.2);
    h = flattenPad(x, z, site.solarPos.x, site.solarPos.z, 16, h, habBase);
    h = flattenPad(x, z, site.commsPos.x, site.commsPos.z, 14, h, habBase);
    return h;
  }

  // Candor Chasma (Valles Marineris): deep canyon floor (-4,250 m datum),
  // towering northern Ophir-Candor escarpment, western Ceti Mensa, and eastern two-tier Candor Mensa
  let h = fbm(x * 0.005, z * 0.005, 5, 57) * 4.8;
  h += fbm(x * 0.022, z * 0.022, 3, 71) * 1.3;

  // Towering northern Valles Marineris canyon wall (Ophir–Candor divide, z < -115)
  const northWall = Math.max(0, (-z - 112) / 180);
  if (northWall > 0) {
    const spurWave = 0.82 + 0.26 * Math.sin(x * 0.048);
    h += Math.pow(northWall, 1.4) * 58 * spurWave;
  }

  // Deeply incised Ophir-Candor North Wall Cliff Alcove radiation shelter around (8, -144)
  const alcoveX = x - 8;
  const alcoveZ = z + 144;
  const alcoveCarve =
    Math.exp(-(alcoveX * alcoveX) / (2 * 22 * 22)) *
    Math.exp(-(alcoveZ * alcoveZ) / (2 * 28 * 28));
  h -= alcoveCarve * 20.0;

  // Ceti Mensa (Western Candor, 5.73° S, 283.70° E) around (-54, -26) with gentler SW access ramp
  const cetiDx = (x + 54) * 0.95;
  const cetiDz = (z + 26) * 1.1;
  const cetiDist = Math.hypot(cetiDx, cetiDz);
  if (cetiDist < 68) {
    const cetiPlateau = Math.pow(Math.max(0, 1 - cetiDist / 68), 0.72) * 18.5;
    const cetiStep = Math.floor(cetiPlateau / 3.4) * 0.65;
    h += Math.min(16.5, cetiPlateau) + cetiStep;
  }

  // Candor Mensa (Eastern Candor, 6.26° S, 286.48° E) around (88, 32)
  // Two-tier ILD mesa: thick monohydrated sulfate lower ledges + unconformable polyhydrated cap
  const mesaDx = (x - 88) * 0.85;
  const mesaDz = (z - 32) * 1.08;
  const mesaDist = Math.hypot(mesaDx, mesaDz);
  if (mesaDist < 84) {
    const lowerTier = Math.pow(Math.max(0, 1 - mesaDist / 84), 0.7) * 19.5;
    const upperCap = mesaDist < 42 ? Math.pow(1 - mesaDist / 42, 0.55) * 8.5 : 0;
    const strataStep = Math.floor(lowerTier / 3.2) * 0.75;
    h += Math.min(17.5, lowerTier) + Math.min(6.8, upperCap) + strataStep;
  }

  // East Ceti Aeolian Dune Sheet ripple relief around (16, 112)
  const duneDist = Math.hypot((x - 16) * 0.85, z - 112);
  if (duneDist < 54) {
    const dw = 1 - duneDist / 54;
    h += Math.sin(x * 0.2 + z * 0.22) * 0.65 * dw;
  }

  // Subtle ridge spur along far eastern canyon margin
  h += ridgeFbm(x * 0.011, z * 0.011, 3, 97) * 3.5;

  const habBase = -2.4;
  h = flattenPad(x, z, site.habitatPos.x, site.habitatPos.z, 22, h, habBase);
  h = flattenPad(x, z, site.mavPos.x, site.mavPos.z, 20, h, habBase);
  h = flattenPad(x, z, site.solarPos.x, site.solarPos.z, 16, h, habBase);
  h = flattenPad(x, z, site.commsPos.x, site.commsPos.z, 14, h, habBase);
  return h;
}

export interface TerrainSample {
  x: number;
  z: number;
  height: number;
  slopeDeg: number;
  radiationMsv: number;
  thermalInertia: number;
  mineralCode: number; // 0: basalt, 1: clay, 2: carbonate, 3: sulfate, 4: water ice
  boulderDensity: number; // 0..1
  isShelter: boolean;
}

export function sampleTerrainFull(siteId: SiteId, x: number, z: number): TerrainSample {
  const eps = 2.0;
  const h = sampleElevation(siteId, x, z);
  const hx1 = sampleElevation(siteId, x + eps, z);
  const hx0 = sampleElevation(siteId, x - eps, z);
  const hz1 = sampleElevation(siteId, x, z + eps);
  const hz0 = sampleElevation(siteId, x, z - eps);

  const dhdx = (hx1 - hx0) / (2 * eps);
  const dhdz = (hz1 - hz0) / (2 * eps);
  const grad = Math.sqrt(dhdx * dhdx + dhdz * dhdz);
  const slopeDeg = Math.atan(grad) * (180 / Math.PI);

  // Horizon sky-view occlusion for radiation shielding (Curiosity RAD ~0.67 mSv/day open sky)
  let horizonOcclusion = 0;
  const sampleR = 26;
  const dirs = 8;
  for (let i = 0; i < dirs; i++) {
    const a = (i / dirs) * Math.PI * 2;
    const nh = sampleElevation(siteId, x + Math.cos(a) * sampleR, z + Math.sin(a) * sampleR);
    if (nh > h) {
      horizonOcclusion += Math.min(0.9, (nh - h) / sampleR);
    }
  }
  horizonOcclusion = Math.min(0.78, horizonOcclusion / dirs);

  // Extra canyon-wall / crater-alcove shielding
  let alcoveShield = 0;
  if (siteId === 'candor') {
    const alcoveDist = Math.hypot(x - 8, z + 144);
    if (alcoveDist < 34) {
      alcoveShield = (1 - alcoveDist / 34) * 0.4;
    }
  } else {
    const belvaAlcoveDist = Math.hypot(x - 128, z - 58);
    if (belvaAlcoveDist < 28) {
      alcoveShield = (1 - belvaAlcoveDist / 28) * 0.24;
    }
  }

  const baseRad = (siteId === 'candor' ? 0.58 : 0.66) + Math.max(0, h) * 0.0022;
  const radiationMsv = Math.max(0.14, baseRad * (1 - horizonOcclusion * 0.68 - alcoveShield));
  const isShelter = radiationMsv < 0.44;

  // Thermal inertia & mineral composition
  const nTi = fbm(x * 0.015, z * 0.015, 3, 211);
  let thermalInertia = 430 + slopeDeg * 14 + nTi * 125;
  let mineralCode = 0; // Basaltic regolith

  if (siteId === 'jezero') {
    // Séítah loose dust ripple field south of landing site
    const dustDist = Math.hypot(x + 12, z - 124);
    if (dustDist < 58) {
      thermalInertia = lerp(142, thermalInertia, dustDist / 58);
    }
    // Neretva Fan Delta clays (NW lobe spreading SE)
    if (Math.hypot(x + 88, z + 56) < 68) {
      mineralCode = 1;
      thermalInertia += 65;
    } else if (Math.hypot(x + 162, z + 24) < 64 || Math.hypot(x + 12, z - 124) < 34) {
      mineralCode = 2; // Margin Carbonate shoreline + Séítah olivine bedrock
      thermalInertia += dustDist < 40 ? 25 : 145;
    }
  } else {
    // East Ceti Aeolian Dune Sheet SE of Ceti Mensa
    const duneDist = Math.hypot(x - 16, z - 112);
    if (duneDist < 54) {
      thermalInertia = lerp(152, thermalInertia, duneDist / 54);
    }
    // Candor Mensa polyhydrated sulfates (east)
    if (Math.hypot(x - 88, z - 32) < 68) {
      mineralCode = 3;
      thermalInertia += 115;
    } else if (Math.hypot(x + 54, z + 26) < 56) {
      mineralCode = 1; // Ceti Mensa hydrated clay + hematite
      thermalInertia += 165;
    }
  }

  thermalInertia = Math.max(110, Math.min(860, thermalInertia));

  // Boulder density peaks on crater rims & moderate-high slopes (low on landing pads)
  const site = MARS_SITES[siteId];
  const distToHab = Math.hypot(x - site.habitatPos.x, z - site.habitatPos.z);
  const distToMav = Math.hypot(x - site.mavPos.x, z - site.mavPos.z);
  let boulderDensity = Math.max(0, Math.min(1, (slopeDeg - 6) / 16 + (fbm(x * 0.04, z * 0.04, 2, 503) + 0.2) * 0.35));
  if (distToHab < 32 || distToMav < 28) boulderDensity *= 0.05;

  return {
    x,
    z,
    height: h,
    slopeDeg,
    radiationMsv,
    thermalInertia,
    mineralCode,
    boulderDensity,
    isShelter,
  };
}

export function sampleTerrainNormal(
  siteId: SiteId,
  x: number,
  z: number,
  span = 1.6
): { nx: number; ny: number; nz: number } {
  const hx1 = sampleElevation(siteId, x + span, z);
  const hx0 = sampleElevation(siteId, x - span, z);
  const hz1 = sampleElevation(siteId, x, z + span);
  const hz0 = sampleElevation(siteId, x, z - span);
  const dx = (hx1 - hx0) / (2 * span);
  const dz = (hz1 - hz0) / (2 * span);
  const len = Math.hypot(-dx, 1, -dz);
  return { nx: -dx / len, ny: 1 / len, nz: -dz / len };
}

export interface TerrainGrid {
  siteId: SiteId;
  size: number;
  worldSpan: number; // e.g. 600m
  halfSpan: number;
  cellSize: number;
  heights: Float32Array;
  slopes: Float32Array;
  radiation: Float32Array;
  thermalInertia: Float32Array;
  minerals: Uint8Array;
  boulders: Float32Array;
  minHeight: number;
  maxHeight: number;
}

export function bakeTerrainGrid(siteId: SiteId, gridSize = 176): TerrainGrid {
  const site = MARS_SITES[siteId];
  const worldSpan = site.terrainScaleM;
  const halfSpan = worldSpan / 2;
  const cellSize = worldSpan / (gridSize - 1);

  const count = gridSize * gridSize;
  const heights = new Float32Array(count);
  const slopes = new Float32Array(count);
  const radiation = new Float32Array(count);
  const thermalInertia = new Float32Array(count);
  const minerals = new Uint8Array(count);
  const boulders = new Float32Array(count);

  let minHeight = Infinity;
  let maxHeight = -Infinity;

  for (let gz = 0; gz < gridSize; gz++) {
    const z = -halfSpan + gz * cellSize;
    for (let gx = 0; gx < gridSize; gx++) {
      const x = -halfSpan + gx * cellSize;
      const idx = gz * gridSize + gx;
      const s = sampleTerrainFull(siteId, x, z);
      heights[idx] = s.height;
      slopes[idx] = s.slopeDeg;
      radiation[idx] = s.radiationMsv;
      thermalInertia[idx] = s.thermalInertia;
      minerals[idx] = s.mineralCode;
      boulders[idx] = s.boulderDensity;
      if (s.height < minHeight) minHeight = s.height;
      if (s.height > maxHeight) maxHeight = s.height;
    }
  }

  return {
    siteId,
    size: gridSize,
    worldSpan,
    halfSpan,
    cellSize,
    heights,
    slopes,
    radiation,
    thermalInertia,
    minerals,
    boulders,
    minHeight,
    maxHeight,
  };
}

export function getMineralLabel(code: number): string {
  switch (code) {
    case 1:
      return 'Hydrated Phyllosilicates';
    case 2:
      return 'Mg-Carbonate / Olivine';
    case 3:
      return 'Polyhydrated Sulfates';
    case 4:
      return 'Shallow Water Ice (H₂O)';
    default:
      return 'Basaltic Regolith';
  }
}

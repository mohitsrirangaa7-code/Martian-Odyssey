import * as THREE from 'three';
import { MarsPoi, OverlayLayerId, SiteId } from '../data/marsSites';
import {
  TerrainGrid,
  noise2D,
  sampleElevation,
  sampleTerrainNormal,
} from './terrainMath';

export interface TerrainLayerTextures {
  natural: THREE.CanvasTexture;
  topography: THREE.CanvasTexture;
  radiation: THREE.CanvasTexture;
  thermal: THREE.CanvasTexture;
  roughnessMap: THREE.CanvasTexture;
  normalMap: THREE.CanvasTexture;
}

export interface MarsRoverRig {
  group: THREE.Group;
  wheels: THREE.Object3D[];
  mastHead: THREE.Object3D;
}

function lerpColor(
  c1: [number, number, number],
  c2: [number, number, number],
  t: number
): [number, number, number] {
  const k = Math.max(0, Math.min(1, t));
  return [
    Math.round(c1[0] + (c2[0] - c1[0]) * k),
    Math.round(c1[1] + (c2[1] - c1[1]) * k),
    Math.round(c1[2] + (c2[2] - c1[2]) * k),
  ];
}

function createCanvasTex(
  canvas: HTMLCanvasElement,
  isColor: boolean,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = isColor ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.anisotropy = maxAnisotropy;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.needsUpdate = true;
  return tex;
}

// Fast deterministic pseudo-random grit for 1024x1024 micro-detail
function fastHash(x: number, y: number): number {
  let n = Math.imul(x, 374761393) + Math.imul(y, 668265263);
  n = (n ^ (n >>> 13)) * 1274126177;
  return ((n ^ (n >>> 16)) >>> 0) / 4294967295;
}

export function generateTerrainLayerTextures(
  grid: TerrainGrid,
  maxAnisotropy: number
): TerrainLayerTextures {
  const texSize = 1024;
  const N = grid.size;

  const sampleBilinear = (arr: Float32Array, u: number, v: number): number => {
    const gx = Math.max(0, Math.min(N - 1.001, u * (N - 1)));
    const gz = Math.max(0, Math.min(N - 1.001, v * (N - 1)));
    const ix = Math.floor(gx);
    const iz = Math.floor(gz);
    const fx = gx - ix;
    const fz = gz - iz;
    const a = arr[iz * N + ix];
    const b = arr[iz * N + ix + 1];
    const c = arr[(iz + 1) * N + ix];
    const d = arr[(iz + 1) * N + ix + 1];
    return a + (b - a) * fx + (c - a) * fz + (a - b - c + d) * fx * fz;
  };

  const sampleNearestByte = (arr: Uint8Array, u: number, v: number): number => {
    const ix = Math.round(u * (N - 1));
    const iz = Math.round(v * (N - 1));
    return arr[iz * N + ix];
  };

  const makeCanvas = () => {
    const c = document.createElement('canvas');
    c.width = texSize;
    c.height = texSize;
    return c;
  };

  const cNat = makeCanvas();
  const cTopo = makeCanvas();
  const cRad = makeCanvas();
  const cTherm = makeCanvas();
  const cRough = makeCanvas();
  const cNorm = makeCanvas();

  const ctxNat = cNat.getContext('2d')!;
  const ctxTopo = cTopo.getContext('2d')!;
  const ctxRad = cRad.getContext('2d')!;
  const ctxTherm = cTherm.getContext('2d')!;
  const ctxRough = cRough.getContext('2d')!;
  const ctxNorm = cNorm.getContext('2d')!;

  const imgNat = ctxNat.createImageData(texSize, texSize);
  const imgTopo = ctxTopo.createImageData(texSize, texSize);
  const imgRad = ctxRad.createImageData(texSize, texSize);
  const imgTherm = ctxTherm.createImageData(texSize, texSize);
  const imgRough = ctxRough.createImageData(texSize, texSize);
  const imgNorm = ctxNorm.createImageData(texSize, texSize);

  const microHeight = new Float32Array(texSize * texSize);
  const heightSpan = Math.max(1, grid.maxHeight - grid.minHeight);

  for (let py = 0; py < texSize; py++) {
    const v = py / (texSize - 1);
    const wz = -grid.halfSpan + v * grid.worldSpan;

    for (let px = 0; px < texSize; px++) {
      const u = px / (texSize - 1);
      const wx = -grid.halfSpan + u * grid.worldSpan;
      const pIdx = py * texSize + px;
      const offset = pIdx * 4;

      const h = sampleBilinear(grid.heights, u, v);
      const slope = sampleBilinear(grid.slopes, u, v);
      const rad = sampleBilinear(grid.radiation, u, v);
      const ti = sampleBilinear(grid.thermalInertia, u, v);
      const mineral = sampleNearestByte(grid.minerals, u, v);

      // Authentic multi-scale Martian surface micro-features
      const grit = (fastHash(px, py) - 0.5) * 20;
      const pebbleCluster = Math.sin(wx * 0.63 + wz * 0.41) * Math.cos(wx * 0.47 - wz * 0.71);
      const windWave = Math.sin(wx * 0.95 + wz * 0.35 + Math.sin(wz * 0.14) * 2.2);
      const strataBand = Math.sin(h * 2.85 + Math.sin(wx * 0.08 + wz * 0.07) * 1.4);

      // Aeolian ripples stronger on dust/flats, strata ledges stronger on steep cliffs
      const dustWeight = Math.max(0.15, Math.min(1.0, (480 - ti) / 320 + (12 - slope) / 24));
      const cliffWeight = Math.max(0, Math.min(1, (slope - 7) / 14));

      const microH =
        windWave * 0.42 * dustWeight +
        strataBand * 0.55 * cliffWeight +
        pebbleCluster * 0.22 +
        (grit / 20) * 0.35;
      microHeight[pIdx] = microH;

      // 1. REALISTIC MARTIAN SURFACE ALBEDO (Perseverance Mastcam-Z / HiRISE tones)
      // Base regolith shifts from warm dusty ochre in basins to darker weathered basalt on slopes
      let baseRgb = lerpColor([158, 98, 66], [102, 66, 52], Math.min(1, (h - grid.minHeight) / heightSpan * 0.7 + cliffWeight * 0.5));

      // Mineralogical variations (subtle & realistic in Natural Mars view)
      if (ti < 245) {
        // Bright wind-blown iron-oxide dust ripples
        baseRgb = lerpColor(baseRgb, [196, 130, 88], 0.72);
      } else if (mineral === 1) {
        // Phyllosilicate clay mudstone (warm tan-olive)
        baseRgb = lerpColor(baseRgb, [166, 122, 86], 0.52);
      } else if (mineral === 2) {
        // Carbonate / olivine bench
        baseRgb = lerpColor(baseRgb, [176, 132, 96], 0.48);
      } else if (mineral === 3) {
        // Polyhydrated sulfate strata (Candor Mensa pale buff layers)
        baseRgb = lerpColor(baseRgb, [194, 152, 114], 0.55);
      }

      // Apply sedimentary strata bands on canyon/delta walls + wind-ripple crest brightening + basaltic dark sand streaks
      const windStreak = Math.sin(wx * 0.045 + wz * 0.02) * Math.cos(wz * 0.055 - wx * 0.015) * 12;
      const strataShade = strataBand * cliffWeight * 16;
      const rippleShade = windWave * dustWeight * 9;
      const aoCrevice = Math.max(-18, Math.min(10, (h < 0 ? h * 0.6 : 0) - cliffWeight * 10));

      const nr = Math.max(0, Math.min(255, baseRgb[0] + grit * 0.65 + windStreak + strataShade + rippleShade + aoCrevice));
      const ng = Math.max(0, Math.min(255, baseRgb[1] + grit * 0.48 + windStreak * 0.75 + strataShade * 0.8 + rippleShade * 0.78 + aoCrevice * 0.85));
      const nb = Math.max(0, Math.min(255, baseRgb[2] + grit * 0.36 + windStreak * 0.55 + strataShade * 0.65 + rippleShade * 0.62 + aoCrevice * 0.7));

      imgNat.data[offset] = nr;
      imgNat.data[offset + 1] = ng;
      imgNat.data[offset + 2] = nb;
      imgNat.data[offset + 3] = 255;

      // Roughness map: dusty regolith very matte (0.94), exposed bedrock slightly lower (0.76)
      const roughVal = Math.max(175, Math.min(250, 240 - cliffWeight * 38 + grit * 0.6));
      imgRough.data[offset] = roughVal;
      imgRough.data[offset + 1] = roughVal;
      imgRough.data[offset + 2] = roughVal;
      imgRough.data[offset + 3] = 255;

      // 2. TOPOGRAPHY & SLOPE HAZARD LAYER
      let topoRgb: [number, number, number];
      if (slope < 10) {
        topoRgb = lerpColor([32, 148, 108], [160, 185, 72], slope / 10);
      } else if (slope < 15) {
        topoRgb = lerpColor([228, 178, 42], [240, 124, 34], (slope - 10) / 5);
      } else {
        topoRgb = lerpColor([225, 62, 46], [168, 22, 48], Math.min(1, (slope - 15) / 10));
      }
      const contourFrac = Math.abs(((h / 2.5) % 1 + 1) % 1 - 0.5);
      const isContour = contourFrac > 0.465;
      const natBlend = isContour ? 0.12 : 0.36;
      imgTopo.data[offset] = Math.round(topoRgb[0] * (1 - natBlend) + nr * natBlend);
      imgTopo.data[offset + 1] = Math.round(topoRgb[1] * (1 - natBlend) + ng * natBlend);
      imgTopo.data[offset + 2] = Math.round(topoRgb[2] * (1 - natBlend) + nb * natBlend);
      imgTopo.data[offset + 3] = 255;

      // 3. RADIATION & SHELTER ZONE LAYER
      const radNorm = Math.max(0, Math.min(1, (rad - 0.14) / 0.62));
      let radRgb: [number, number, number];
      if (radNorm < 0.38) {
        radRgb = lerpColor([14, 165, 233], [16, 185, 129], radNorm / 0.38);
      } else if (radNorm < 0.72) {
        radRgb = lerpColor([16, 185, 129], [245, 158, 11], (radNorm - 0.38) / 0.34);
      } else {
        radRgb = lerpColor([245, 158, 11], [239, 68, 68], (radNorm - 0.72) / 0.28);
      }
      imgRad.data[offset] = Math.round(radRgb[0] * 0.7 + nr * 0.3);
      imgRad.data[offset + 1] = Math.round(radRgb[1] * 0.7 + ng * 0.3);
      imgRad.data[offset + 2] = Math.round(radRgb[2] * 0.7 + nb * 0.3);
      imgRad.data[offset + 3] = 255;

      // 4. COMPOSITION & THERMAL INERTIA LAYER
      let thermRgb: [number, number, number];
      if (mineral === 4) {
        thermRgb = [56, 189, 248];
      } else if (mineral === 1) {
        thermRgb = [52, 211, 153];
      } else if (mineral === 2) {
        thermRgb = [251, 191, 36];
      } else if (mineral === 3) {
        thermRgb = [167, 139, 250];
      } else {
        const tiNorm = Math.max(0, Math.min(1, (ti - 130) / 600));
        thermRgb = lerpColor([217, 70, 120], [59, 130, 206], tiNorm);
      }
      imgTherm.data[offset] = Math.round(thermRgb[0] * 0.66 + nr * 0.34);
      imgTherm.data[offset + 1] = Math.round(thermRgb[1] * 0.66 + ng * 0.34);
      imgTherm.data[offset + 2] = Math.round(thermRgb[2] * 0.66 + nb * 0.34);
      imgTherm.data[offset + 3] = 255;
    }
  }

  // Second tight pass: bake tangent-space normal map from microHeight
  const normalStrength = 2.4;
  for (let py = 0; py < texSize; py++) {
    const py0 = Math.max(0, py - 1);
    const py1 = Math.min(texSize - 1, py + 1);
    for (let px = 0; px < texSize; px++) {
      const px0 = Math.max(0, px - 1);
      const px1 = Math.min(texSize - 1, px + 1);
      const dX = (microHeight[py * texSize + px1] - microHeight[py * texSize + px0]) * normalStrength;
      const dY = (microHeight[py1 * texSize + px] - microHeight[py0 * texSize + px]) * normalStrength;
      const invLen = 1 / Math.hypot(dX, dY, 1);
      const offset = (py * texSize + px) * 4;
      imgNorm.data[offset] = Math.round(((-dX * invLen) * 0.5 + 0.5) * 255);
      imgNorm.data[offset + 1] = Math.round(((dY * invLen) * 0.5 + 0.5) * 255);
      imgNorm.data[offset + 2] = Math.round(((invLen) * 0.5 + 0.5) * 255);
      imgNorm.data[offset + 3] = 255;
    }
  }

  ctxNat.putImageData(imgNat, 0, 0);
  ctxTopo.putImageData(imgTopo, 0, 0);
  ctxRad.putImageData(imgRad, 0, 0);
  ctxTherm.putImageData(imgTherm, 0, 0);
  ctxRough.putImageData(imgRough, 0, 0);
  ctxNorm.putImageData(imgNorm, 0, 0);

  return {
    natural: createCanvasTex(cNat, true, maxAnisotropy),
    topography: createCanvasTex(cTopo, true, maxAnisotropy),
    radiation: createCanvasTex(cRad, true, maxAnisotropy),
    thermal: createCanvasTex(cTherm, true, maxAnisotropy),
    roughnessMap: createCanvasTex(cRough, false, maxAnisotropy),
    normalMap: createCanvasTex(cNorm, false, maxAnisotropy),
  };
}

export function buildTerrainGeometry(grid: TerrainGrid): THREE.BufferGeometry {
  const N = grid.size;
  const geom = new THREE.PlaneGeometry(grid.worldSpan, grid.worldSpan, N - 1, N - 1);
  geom.rotateX(-Math.PI / 2);

  const pos = geom.attributes.position as THREE.BufferAttribute;
  for (let gz = 0; gz < N; gz++) {
    for (let gx = 0; gx < N; gx++) {
      const idx = gz * N + gx;
      pos.setY(idx, grid.heights[idx]);
    }
  }
  pos.needsUpdate = true;
  geom.computeVertexNormals();
  geom.computeBoundingSphere();
  return geom;
}

// Distant sculpted crater rim / canyon wall skirt fading into Martian dust haze
export function buildHorizonSkirt(minHeight: number): THREE.Mesh {
  const geo = new THREE.PlaneGeometry(2400, 2400, 72, 72);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position as THREE.BufferAttribute;

  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const maxAxis = Math.max(Math.abs(x), Math.abs(z));
    if (maxAxis <= 295) {
      pos.setY(i, minHeight - 4.0);
    } else {
      const outer = Math.min(1, (maxAxis - 295) / 650);
      const ridge =
        Math.pow(outer, 1.35) * 68 +
        noise2D(x * 0.004, z * 0.004, 809) * 26 * outer +
        Math.sin(x * 0.009 + z * 0.006) * 14 * outer;
      pos.setY(i, minHeight - 3.0 + ridge);
    }
  }
  pos.needsUpdate = true;
  geo.computeVertexNormals();

  const mat = new THREE.MeshStandardMaterial({
    color: 0x92553a,
    roughness: 0.95,
    metalness: 0.02,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.receiveShadow = true;
  return mesh;
}

function createSolarPanelTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#0f2147';
  ctx.fillRect(0, 0, 256, 256);

  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 1;
  ctx.globalAlpha = 0.45;
  for (let x = 0; x <= 256; x += 32) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 256);
    ctx.stroke();
  }
  for (let y = 0; y <= 256; y += 16) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(256, y);
    ctx.stroke();
  }
  ctx.globalAlpha = 0.25;
  ctx.fillStyle = '#93c5fd';
  for (let y = 0; y < 256; y += 32) {
    for (let x = 0; x < 256; x += 32) {
      ctx.fillRect(x + 2, y + 2, 28, 12);
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createRoverWheelTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#2b2826';
  ctx.fillRect(0, 0, 256, 128);

  // Titanium chevron cleats with Martian dust trapped in grooves
  for (let x = 0; x < 256; x += 16) {
    ctx.fillStyle = '#474340';
    ctx.fillRect(x, 0, 7, 128);
    ctx.fillStyle = '#78503c';
    ctx.fillRect(x + 7, 0, 4, 128);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

// Perseverance-inspired 6-wheel Mars Rover (14+ articulated parts)
export function buildMarsRover(maxAnisotropy: number): MarsRoverRig {
  const group = new THREE.Group();
  const wheels: THREE.Object3D[] = [];

  const bodyWhite = new THREE.MeshStandardMaterial({
    color: 0xe6e2d8, // dusty off-white thermal paint
    roughness: 0.48,
    metalness: 0.25,
  });
  const goldKapton = new THREE.MeshStandardMaterial({
    color: 0xd98218,
    roughness: 0.26,
    metalness: 0.84,
  });
  const titaniumMat = new THREE.MeshStandardMaterial({
    color: 0x7c828a,
    roughness: 0.42,
    metalness: 0.78,
  });
  const darkMetal = new THREE.MeshStandardMaterial({
    color: 0x24262b,
    roughness: 0.55,
    metalness: 0.72,
  });
  const wheelMat = new THREE.MeshStandardMaterial({
    map: createRoverWheelTexture(maxAnisotropy),
    roughness: 0.68,
    metalness: 0.52,
  });
  const lensMat = new THREE.MeshPhysicalMaterial({
    color: 0x09111e,
    roughness: 0.08,
    metalness: 0.2,
    clearcoat: 1.0,
  });

  // Soft radial contact shadow beneath rover chassis
  const shadowCanvas = document.createElement('canvas');
  shadowCanvas.width = 128;
  shadowCanvas.height = 128;
  const sCtx = shadowCanvas.getContext('2d')!;
  const grad = sCtx.createRadialGradient(64, 64, 10, 64, 64, 60);
  grad.addColorStop(0, 'rgba(15, 8, 4, 0.58)');
  grad.addColorStop(0.65, 'rgba(15, 8, 4, 0.22)');
  grad.addColorStop(1, 'rgba(15, 8, 4, 0)');
  sCtx.fillStyle = grad;
  sCtx.fillRect(0, 0, 128, 128);
  const shadowTex = new THREE.CanvasTexture(shadowCanvas);
  const contactShadow = new THREE.Mesh(
    new THREE.PlaneGeometry(4.2, 5.2),
    new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false })
  );
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.y = 0.05;
  group.add(contactShadow);

  // 1. Warm Electronics Box (WEB) main chassis (rover faces +Z forward)
  const webBox = new THREE.Mesh(new THREE.BoxGeometry(1.75, 0.78, 2.55), bodyWhite);
  webBox.position.set(0, 1.05, 0);
  webBox.castShadow = true;
  webBox.receiveShadow = true;
  group.add(webBox);

  // 2. Gold Kapton thermal insulation side bays & lower belly pan
  const bellyPan = new THREE.Mesh(new THREE.BoxGeometry(1.52, 0.22, 2.3), goldKapton);
  bellyPan.position.set(0, 0.62, 0);
  bellyPan.castShadow = true;
  group.add(bellyPan);

  const topDeck = new THREE.Mesh(new THREE.BoxGeometry(1.88, 0.1, 2.68), titaniumMat);
  topDeck.position.set(0, 1.46, 0);
  topDeck.castShadow = true;
  group.add(topDeck);

  // 3. Rear angled MMRTG nuclear power cylinder + radiator fins
  const rtgGroup = new THREE.Group();
  rtgGroup.position.set(0, 1.25, -1.48);
  rtgGroup.rotation.x = -0.42;
  const rtgCore = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.28, 1.15, 14), darkMetal);
  rtgCore.rotation.x = Math.PI / 2;
  rtgCore.castShadow = true;
  rtgGroup.add(rtgCore);
  for (let f = 0; f < 6; f++) {
    const a = (f * Math.PI) / 3;
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.72, 1.05), darkMetal);
    fin.rotation.z = a;
    rtgGroup.add(fin);
  }
  group.add(rtgGroup);

  // 4. Rocker-Bogie differential cross-axle & suspension arms + 6 cleated wheels
  const wheelRadius = 0.42;
  const wheelZPositions = [1.22, 0.0, -1.22];
  const sideSigns = [-1, 1];

  for (const side of sideSigns) {
    const trackX = side * 1.16;

    // Differential rocker tube
    const mainStrut = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 1.55, 8), titaniumMat);
    mainStrut.position.set(side * 0.98, 0.92, 0.55);
    mainStrut.rotation.x = 0.58;
    mainStrut.castShadow = true;
    group.add(mainStrut);

    const bogieStrut = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.45, 8), titaniumMat);
    bogieStrut.position.set(side * 0.98, 0.78, -0.62);
    bogieStrut.rotation.x = Math.PI / 2 - 0.12;
    bogieStrut.castShadow = true;
    group.add(bogieStrut);

    const pivotHub = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.25, 12), goldKapton);
    pivotHub.rotation.z = Math.PI / 2;
    pivotHub.position.set(side * 0.92, 1.08, 0.15);
    group.add(pivotHub);

    for (const wz of wheelZPositions) {
      const wheelAssembly = new THREE.Group();
      wheelAssembly.position.set(trackX, wheelRadius, wz);

      // Vertical steering fork / strut
      const fork = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.42, 8), titaniumMat);
      fork.rotation.z = side * 0.22;
      fork.position.set(trackX - side * 0.14, wheelRadius + 0.24, wz);
      fork.castShadow = true;
      group.add(fork);

      const tire = new THREE.Mesh(
        new THREE.CylinderGeometry(wheelRadius, wheelRadius, 0.34, 20),
        wheelMat
      );
      tire.rotation.z = Math.PI / 2;
      tire.castShadow = true;
      tire.receiveShadow = true;
      wheelAssembly.add(tire);

      const rim = new THREE.Mesh(
        new THREE.CylinderGeometry(wheelRadius * 0.62, wheelRadius * 0.62, 0.36, 14),
        darkMetal
      );
      rim.rotation.z = Math.PI / 2;
      wheelAssembly.add(rim);

      const hub = new THREE.Mesh(
        new THREE.CylinderGeometry(0.11, 0.11, 0.4, 10),
        goldKapton
      );
      hub.rotation.z = Math.PI / 2;
      wheelAssembly.add(hub);

      group.add(wheelAssembly);
      wheels.push(wheelAssembly);
    }
  }

  // 5. Remote Sensing Mast (RSM) + Mastcam-Z / SuperCam optical head
  const mastBase = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.14, 0.22, 12), titaniumMat);
  mastBase.position.set(0.52, 1.58, 0.85);
  group.add(mastBase);

  const mastNeck = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.085, 1.15, 10), bodyWhite);
  mastNeck.position.set(0.52, 2.22, 0.85);
  mastNeck.castShadow = true;
  group.add(mastNeck);

  const mastHead = new THREE.Group();
  mastHead.position.set(0.52, 2.82, 0.85);

  const headBox = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.28, 0.38), bodyWhite);
  headBox.castShadow = true;
  mastHead.add(headBox);

  const superCamEye = new THREE.Mesh(new THREE.CylinderGeometry(0.095, 0.095, 0.08, 16), lensMat);
  superCamEye.rotation.x = Math.PI / 2;
  superCamEye.position.set(0, 0.04, 0.2);
  mastHead.add(superCamEye);

  for (const lx of [-0.18, 0.18]) {
    const camPod = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.14), darkMetal);
    camPod.position.set(lx, -0.04, 0.18);
    mastHead.add(camPod);
    const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.042, 0.04, 12), lensMat);
    lens.rotation.x = Math.PI / 2;
    lens.position.set(lx, -0.04, 0.25);
    mastHead.add(lens);
  }
  group.add(mastHead);

  // 6. High-Gain Parabolic Dish Antenna on aft starboard deck
  const dishPts: THREE.Vector2[] = [];
  for (let i = 0; i <= 7; i++) {
    const t = i / 7;
    dishPts.push(new THREE.Vector2(t * 0.42, t * t * 0.14));
  }
  const hgaMast = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.045, 0.55, 8), titaniumMat);
  hgaMast.position.set(-0.55, 1.72, -0.78);
  group.add(hgaMast);

  const hgaDish = new THREE.Mesh(new THREE.LatheGeometry(dishPts, 18), bodyWhite);
  hgaDish.position.set(-0.55, 1.98, -0.78);
  hgaDish.rotation.x = 0.55;
  hgaDish.castShadow = true;
  group.add(hgaDish);

  // 7. Folded 5-DOF Robotic Arm & Turret Drill at front bow (+Z)
  const shoulder = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.22, 10), goldKapton);
  shoulder.position.set(-0.48, 1.05, 1.32);
  group.add(shoulder);

  const upperArm = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.06, 0.78, 8), titaniumMat);
  upperArm.position.set(-0.22, 1.02, 1.62);
  upperArm.rotation.z = Math.PI / 2;
  upperArm.rotation.y = 0.45;
  upperArm.castShadow = true;
  group.add(upperArm);

  const turret = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.24, 12), darkMetal);
  turret.rotation.x = Math.PI / 2;
  turret.position.set(0.08, 0.96, 1.88);
  turret.castShadow = true;
  group.add(turret);

  return { group, wheels, mastHead };
}

// Composite 3-12 part Habitat Complex (bottom-center grounded)
export function buildHabitatComplex(siteId: SiteId, x: number, z: number): THREE.Group {
  const group = new THREE.Group();
  const groundY = sampleElevation(siteId, x, z);
  group.position.set(x, groundY, z);

  const hullMat = new THREE.MeshStandardMaterial({
    color: 0xe2dfd7,
    roughness: 0.48,
    metalness: 0.22,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    roughness: 0.54,
    metalness: 0.68,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: 0xd97706,
    roughness: 0.42,
    metalness: 0.35,
  });
  const windowMat = new THREE.MeshStandardMaterial({
    color: 0xfef3c7,
    emissive: 0xf59e0b,
    emissiveIntensity: 0.65,
    roughness: 0.12,
    metalness: 0.1,
  });

  const pad = new THREE.Mesh(new THREE.CylinderGeometry(8.2, 8.8, 0.45, 24), trimMat);
  pad.position.y = 0.22;
  pad.receiveShadow = true;
  group.add(pad);

  const dome = new THREE.Mesh(
    new THREE.SphereGeometry(5.6, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.56),
    hullMat
  );
  dome.position.y = 0.45;
  dome.castShadow = true;
  dome.receiveShadow = true;
  group.add(dome);

  const collar = new THREE.Mesh(new THREE.CylinderGeometry(5.75, 5.75, 1.1, 24), trimMat);
  collar.position.y = 0.9;
  collar.castShadow = true;
  group.add(collar);

  const band = new THREE.Mesh(new THREE.TorusGeometry(5.58, 0.16, 10, 32), accentMat);
  band.rotation.x = Math.PI / 2;
  band.position.y = 1.65;
  group.add(band);

  const airlock = new THREE.Mesh(new THREE.CylinderGeometry(1.45, 1.45, 4.4, 16), hullMat);
  airlock.rotation.z = Math.PI / 2;
  airlock.position.set(5.4, 1.5, 0);
  airlock.castShadow = true;
  group.add(airlock);

  const hatch = new THREE.Mesh(new THREE.BoxGeometry(0.45, 2.2, 1.8), trimMat);
  hatch.position.set(7.65, 1.45, 0);
  hatch.castShadow = true;
  group.add(hatch);

  for (let i = 0; i < 3; i++) {
    const angle = (i * Math.PI * 2) / 3 + 0.6;
    const win = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.25, 14), windowMat);
    win.rotation.z = Math.PI / 2;
    win.rotation.y = -angle;
    win.position.set(Math.cos(angle) * 5.25, 2.35, Math.sin(angle) * 5.25);
    group.add(win);
  }

  const cupola = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 1.35, 0.9, 16), trimMat);
  cupola.position.y = 6.1;
  cupola.castShadow = true;
  group.add(cupola);

  const spire = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.1, 2.6, 8), trimMat);
  spire.position.y = 7.6;
  group.add(spire);

  return group;
}

export function buildMarsAscentVehicle(siteId: SiteId, x: number, z: number): THREE.Group {
  const group = new THREE.Group();
  const groundY = sampleElevation(siteId, x, z);
  group.position.set(x, groundY, z);

  const hullMat = new THREE.MeshStandardMaterial({
    color: 0xeae7e0,
    roughness: 0.38,
    metalness: 0.32,
  });
  const darkMetal = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.45,
    metalness: 0.82,
  });
  const goldFoil = new THREE.MeshStandardMaterial({
    color: 0xe59417,
    roughness: 0.25,
    metalness: 0.86,
  });

  const pad = new THREE.Mesh(new THREE.CylinderGeometry(6.5, 7.2, 0.35, 8), darkMetal);
  pad.position.y = 0.17;
  pad.receiveShadow = true;
  group.add(pad);

  const stage = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 3.0, 1.8, 12), goldFoil);
  stage.position.y = 2.0;
  stage.castShadow = true;
  group.add(stage);

  for (let i = 0; i < 4; i++) {
    const a = (i * Math.PI) / 2 + Math.PI / 4;
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 3.1, 8), darkMetal);
    leg.position.set(Math.cos(a) * 3.1, 1.35, Math.sin(a) * 3.1);
    leg.rotation.z = -Math.cos(a) * 0.48;
    leg.rotation.x = Math.sin(a) * 0.48;
    leg.castShadow = true;
    group.add(leg);

    const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.65, 0.25, 10), darkMetal);
    foot.position.set(Math.cos(a) * 3.85, 0.35, Math.sin(a) * 3.85);
    group.add(foot);
  }

  const fuselage = new THREE.Mesh(new THREE.CylinderGeometry(1.55, 2.25, 6.2, 18), hullMat);
  fuselage.position.y = 5.9;
  fuselage.castShadow = true;
  group.add(fuselage);

  const nose = new THREE.Mesh(new THREE.ConeGeometry(1.55, 2.9, 18), hullMat);
  nose.position.y = 10.45;
  nose.castShadow = true;
  group.add(nose);

  const bell = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.95, 1.1, 16), darkMetal);
  bell.position.y = 0.85;
  group.add(bell);

  return group;
}

export function buildSolarArray(
  siteId: SiteId,
  x: number,
  z: number,
  maxAnisotropy: number
): THREE.Group {
  const group = new THREE.Group();
  const groundY = sampleElevation(siteId, x, z);
  group.position.set(x, groundY, z);

  const frameMat = new THREE.MeshStandardMaterial({
    color: 0x475569,
    roughness: 0.45,
    metalness: 0.78,
  });
  const panelTex = createSolarPanelTexture(maxAnisotropy);
  const panelMat = new THREE.MeshStandardMaterial({
    map: panelTex,
    roughness: 0.22,
    metalness: 0.52,
  });

  for (let r = -1; r <= 1; r += 2) {
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.3, 2.6, 10), frameMat);
    mast.position.set(0, 1.3, r * 4.2);
    mast.castShadow = true;
    group.add(mast);

    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 0.95, 0.3, 10), frameMat);
    base.position.set(0, 0.15, r * 4.2);
    group.add(base);

    const wing = new THREE.Mesh(new THREE.BoxGeometry(9.5, 0.12, 3.1), panelMat);
    wing.position.set(0, 2.65, r * 4.2);
    wing.rotation.x = 0.32;
    wing.castShadow = true;
    wing.receiveShadow = true;
    group.add(wing);
  }

  return group;
}

export function buildCommsTower(siteId: SiteId, x: number, z: number): THREE.Group {
  const group = new THREE.Group();
  const groundY = sampleElevation(siteId, x, z);
  group.position.set(x, groundY, z);

  const metalMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    roughness: 0.4,
    metalness: 0.75,
  });
  const dishMat = new THREE.MeshStandardMaterial({
    color: 0xf1f5f9,
    roughness: 0.34,
    metalness: 0.28,
    side: THREE.DoubleSide,
  });

  const base = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.35, 0.4, 8), metalMat);
  base.position.y = 0.2;
  group.add(base);

  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.28, 7.2, 10), metalMat);
  mast.position.y = 3.8;
  mast.castShadow = true;
  group.add(mast);

  const pts: THREE.Vector2[] = [];
  for (let i = 0; i <= 8; i++) {
    const t = i / 8;
    pts.push(new THREE.Vector2(t * 1.9, t * t * 0.65));
  }
  const dishGeo = new THREE.LatheGeometry(pts, 20);
  const dish = new THREE.Mesh(dishGeo, dishMat);
  dish.position.set(0, 7.2, 0.2);
  dish.rotation.x = Math.PI / 3;
  dish.castShadow = true;
  group.add(dish);

  const feed = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.2, 8), metalMat);
  feed.position.set(0, 7.6, 0.9);
  feed.rotation.x = Math.PI / 3;
  group.add(feed);

  return group;
}

export function buildPoiBeacon(siteId: SiteId, poi: MarsPoi): THREE.Group {
  const group = new THREE.Group();
  const groundY = sampleElevation(siteId, poi.x, poi.z);
  group.position.set(poi.x, groundY, poi.z);
  group.userData.poiId = poi.id;

  const colorMap: Record<MarsPoi['category'], number> = {
    science: 0x38bdf8,
    shelter: 0x10b981,
    habitat: 0xf59e0b,
    hazard: 0xf43f5e,
  };
  const accentHex = colorMap[poi.category];

  const tripodMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    roughness: 0.45,
    metalness: 0.72,
  });
  const glowMat = new THREE.MeshStandardMaterial({
    color: accentHex,
    emissive: accentHex,
    emissiveIntensity: 1.25,
    roughness: 0.2,
    metalness: 0.3,
  });

  for (let i = 0; i < 3; i++) {
    const a = (i * Math.PI * 2) / 3;
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.1, 2.2, 6), tripodMat);
    leg.position.set(Math.cos(a) * 0.55, 1.0, Math.sin(a) * 0.55);
    leg.rotation.z = Math.cos(a) * 0.24;
    leg.rotation.x = -Math.sin(a) * 0.24;
    leg.userData.poiId = poi.id;
    group.add(leg);
  }

  const core = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.28, 1.6, 12), tripodMat);
  core.position.y = 2.1;
  core.userData.poiId = poi.id;
  group.add(core);

  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.09, 10, 24), glowMat);
  ring.rotation.x = Math.PI / 2;
  ring.position.y = 3.2;
  ring.userData.poiId = poi.id;
  group.add(ring);

  const orb = new THREE.Mesh(new THREE.OctahedronGeometry(0.38, 0), glowMat);
  orb.position.y = 3.2;
  orb.userData.poiId = poi.id;
  group.add(orb);

  const hitProxy = new THREE.Mesh(
    new THREE.CylinderGeometry(3.2, 3.2, 6.5, 10),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitProxy.position.y = 3.0;
  hitProxy.userData.poiId = poi.id;
  group.add(hitProxy);

  return group;
}

// Angular, cleaved basaltic boulders seated deeply in regolith
export function buildBoulderInstances(siteId: SiteId, grid: TerrainGrid): THREE.InstancedMesh {
  const geo = new THREE.DodecahedronGeometry(1.0, 1);
  const pos = geo.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < pos.count; i++) {
    const vx = pos.getX(i);
    const vy = pos.getY(i);
    const vz = pos.getZ(i);
    const k = 0.78 + 0.36 * Math.abs(Math.sin(vx * 3.9 + vz * 4.3 + vy * 2.1));
    pos.setXYZ(i, vx * k, vy * k * 0.62, vz * k);
  }
  geo.computeVertexNormals();

  const mat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.92,
    metalness: 0.04,
  });

  const maxBoulders = 520;
  const placements: {
    x: number;
    y: number;
    z: number;
    sx: number;
    sy: number;
    sz: number;
    rx: number;
    ry: number;
    rz: number;
    color: THREE.Color;
  }[] = [];

  for (let i = 0; i < maxBoulders * 3 && placements.length < maxBoulders; i++) {
    const rx = noise2D(i * 0.37, 1.7, 911);
    const rz = noise2D(2.3, i * 0.41, 977);
    const x = rx * (grid.halfSpan - 18);
    const z = rz * (grid.halfSpan - 18);

    const gx = Math.max(0, Math.min(grid.size - 1, Math.round((x + grid.halfSpan) / grid.cellSize)));
    const gz = Math.max(0, Math.min(grid.size - 1, Math.round((z + grid.halfSpan) / grid.cellSize)));
    const idx = gz * grid.size + gx;
    const density = grid.boulders[idx];

    if (density < 0.22 && i % 4 !== 0) continue;
    const y = sampleElevation(siteId, x, z);
    const norm = sampleTerrainNormal(siteId, x, z, 1.5);

    const scaleBase = 0.35 + Math.pow(Math.abs(noise2D(x * 0.12, z * 0.12, 313)), 1.3) * 1.65;
    const tint = 0.36 + Math.abs(noise2D(z * 0.2, x * 0.2, 419)) * 0.24;
    // Dusty Martian basaltic charcoal-rust rock tone
    const color = new THREE.Color().setRGB(tint * 1.12, tint * 0.78, tint * 0.62);

    placements.push({
      x,
      // Sink ~35% into soil so boulders look naturally embedded
      y: y + scaleBase * 0.14,
      z,
      sx: scaleBase * (0.85 + (i % 5) * 0.09),
      sy: scaleBase * (0.62 + (i % 3) * 0.16),
      sz: scaleBase * (0.85 + ((i + 2) % 4) * 0.1),
      rx: norm.nz * 0.6 + (i % 7) * 0.08,
      ry: (i * 1.618) % (Math.PI * 2),
      rz: -norm.nx * 0.6 + (i % 5) * 0.08,
      color,
    });
  }

  const instanced = new THREE.InstancedMesh(geo, mat, placements.length);
  instanced.castShadow = true;
  instanced.receiveShadow = true;

  const dummy = new THREE.Object3D();
  for (let i = 0; i < placements.length; i++) {
    const p = placements[i];
    dummy.position.set(p.x, p.y, p.z);
    dummy.rotation.set(p.rx, p.ry, p.rz);
    dummy.scale.set(p.sx, p.sy, p.sz);
    dummy.updateMatrix();
    instanced.setMatrixAt(i, dummy.matrix);
    instanced.setColorAt(i, p.color);
  }
  instanced.instanceMatrix.needsUpdate = true;
  if (instanced.instanceColor) instanced.instanceColor.needsUpdate = true;
  instanced.computeBoundingSphere();

  return instanced;
}

// Flat stratified sedimentary bedrock slabs tilted to match terrain slope
export function buildOutcropSlabs(siteId: SiteId, grid: TerrainGrid): THREE.InstancedMesh {
  const geo = new THREE.CylinderGeometry(1.15, 1.35, 0.32, 7, 1);
  const pos = geo.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < pos.count; i++) {
    const vx = pos.getX(i);
    const vy = pos.getY(i);
    const vz = pos.getZ(i);
    const warp = 0.82 + 0.32 * Math.sin(vx * 2.7 + vz * 3.1);
    pos.setXYZ(i, vx * warp, vy, vz * warp);
  }
  geo.computeVertexNormals();

  const mat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.88,
    metalness: 0.04,
  });

  const targetCount = 190;
  const dummy = new THREE.Object3D();
  const upVec = new THREE.Vector3(0, 1, 0);
  const normVec = new THREE.Vector3();
  const alignQuat = new THREE.Quaternion();
  const yawQuat = new THREE.Quaternion();

  const items: { matrix: THREE.Matrix4; color: THREE.Color }[] = [];

  for (let i = 0; i < targetCount * 3 && items.length < targetCount; i++) {
    const rx = noise2D(i * 0.53, 4.1, 613);
    const rz = noise2D(3.7, i * 0.47, 659);
    const x = rx * (grid.halfSpan - 25);
    const z = rz * (grid.halfSpan - 25);

    const gx = Math.max(0, Math.min(grid.size - 1, Math.round((x + grid.halfSpan) / grid.cellSize)));
    const gz = Math.max(0, Math.min(grid.size - 1, Math.round((z + grid.halfSpan) / grid.cellSize)));
    const ti = grid.thermalInertia[gz * grid.size + gx];
    if (ti < 380) continue; // slabs appear on exposed bedrock, not loose dust

    const y = sampleElevation(siteId, x, z);
    const n = sampleTerrainNormal(siteId, x, z, 2.0);
    normVec.set(n.nx, n.ny, n.nz).normalize();
    alignQuat.setFromUnitVectors(upVec, normVec);
    yawQuat.setFromAxisAngle(upVec, (i * 2.399) % (Math.PI * 2));
    alignQuat.multiply(yawQuat);

    const s = 0.9 + Math.abs(noise2D(x * 0.07, z * 0.07, 719)) * 2.4;
    dummy.position.set(x, y - 0.04, z);
    dummy.quaternion.copy(alignQuat);
    dummy.scale.set(s * 1.25, 0.7 + (i % 3) * 0.25, s * 0.92);
    dummy.updateMatrix();

    const tone = 0.44 + Math.abs(noise2D(z * 0.15, x * 0.15, 787)) * 0.2;
    items.push({
      matrix: dummy.matrix.clone(),
      color: new THREE.Color().setRGB(tone * 1.25, tone * 0.86, tone * 0.64),
    });
  }

  const instanced = new THREE.InstancedMesh(geo, mat, items.length);
  instanced.castShadow = true;
  instanced.receiveShadow = true;
  for (let i = 0; i < items.length; i++) {
    instanced.setMatrixAt(i, items[i].matrix);
    instanced.setColorAt(i, items[i].color);
  }
  instanced.instanceMatrix.needsUpdate = true;
  if (instanced.instanceColor) instanced.instanceColor.needsUpdate = true;
  instanced.computeBoundingSphere();
  return instanced;
}

export function getLayerTexture(
  textures: TerrainLayerTextures,
  layer: OverlayLayerId
): THREE.CanvasTexture {
  return textures[layer];
}

import { TerrainGrid } from './terrainMath';

export interface RoutePoint {
  x: number;
  y: number;
  z: number;
  slopeDeg: number;
  radiationMsv: number;
  thermalInertia: number;
}

export interface EvaRouteResult {
  points: RoutePoint[];
  totalDistanceM: number;
  maxSlopeDeg: number;
  avgSlopeDeg: number;
  estimatedMinutes: number;
  oxygenCostPct: number;
  cumulativeDoseMsv: number;
  hazardSegments: number; // segments > 14 deg
  usedFallbackSlopeRelax: boolean;
}

class MinHeap {
  private data: { idx: number; f: number }[] = [];

  get length(): number {
    return this.data.length;
  }

  push(item: { idx: number; f: number }): void {
    this.data.push(item);
    let i = this.data.length - 1;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (this.data[p].f <= this.data[i].f) break;
      [this.data[p], this.data[i]] = [this.data[i], this.data[p]];
      i = p;
    }
  }

  pop(): { idx: number; f: number } | undefined {
    const top = this.data[0];
    const last = this.data.pop();
    if (this.data.length > 0 && last) {
      this.data[0] = last;
      let i = 0;
      const len = this.data.length;
      while (true) {
        let smallest = i;
        const l = 2 * i + 1;
        const r = 2 * i + 2;
        if (l < len && this.data[l].f < this.data[smallest].f) smallest = l;
        if (r < len && this.data[r].f < this.data[smallest].f) smallest = r;
        if (smallest === i) break;
        [this.data[i], this.data[smallest]] = [this.data[smallest], this.data[i]];
        i = smallest;
      }
    }
    return top;
  }
}

export function computeSafeEvaRoute(
  grid: TerrainGrid,
  startWorld: { x: number; z: number },
  endWorld: { x: number; z: number },
  options: { prioritizeShelter?: boolean; maxSlopeLimitDeg?: number } = {}
): EvaRouteResult | null {
  const { prioritizeShelter = false, maxSlopeLimitDeg = 18.5 } = options;
  const N = grid.size;

  const worldToGrid = (wx: number, wz: number): [number, number] => {
    const gx = Math.max(1, Math.min(N - 2, Math.round((wx + grid.halfSpan) / grid.cellSize)));
    const gz = Math.max(1, Math.min(N - 2, Math.round((wz + grid.halfSpan) / grid.cellSize)));
    return [gx, gz];
  };

  const [sx, sz] = worldToGrid(startWorld.x, startWorld.z);
  const [ex, ez] = worldToGrid(endWorld.x, endWorld.z);

  const runAStar = (slopeLimit: number): number[] | null => {
    const total = N * N;
    const gScore = new Float32Array(total).fill(Infinity);
    const cameFrom = new Int32Array(total).fill(-1);
    const closed = new Uint8Array(total);
    const heap = new MinHeap();

    const startIdx = sz * N + sx;
    const endIdx = ez * N + ex;
    gScore[startIdx] = 0;
    heap.push({ idx: startIdx, f: Math.hypot(ex - sx, ez - sz) });

    const dirs = [
      [1, 0, 1],
      [-1, 0, 1],
      [0, 1, 1],
      [0, -1, 1],
      [1, 1, Math.SQRT2],
      [1, -1, Math.SQRT2],
      [-1, 1, Math.SQRT2],
      [-1, -1, Math.SQRT2],
    ];

    while (heap.length > 0) {
      const curr = heap.pop()!;
      if (curr.idx === endIdx) {
        const path: number[] = [];
        let p = endIdx;
        while (p !== -1) {
          path.push(p);
          p = cameFrom[p];
        }
        path.reverse();
        return path;
      }

      if (closed[curr.idx]) continue;
      closed[curr.idx] = 1;

      const cx = curr.idx % N;
      const cz = Math.floor(curr.idx / N);
      const ch = grid.heights[curr.idx];

      for (let d = 0; d < dirs.length; d++) {
        const nx = cx + dirs[d][0];
        const nz = cz + dirs[d][1];
        if (nx < 0 || nx >= N || nz < 0 || nz >= N) continue;

        const nIdx = nz * N + nx;
        if (closed[nIdx]) continue;

        const nh = grid.heights[nIdx];
        const horizDist = dirs[d][2] * grid.cellSize;
        const stepSlopeDeg = Math.atan(Math.abs(nh - ch) / horizDist) * (180 / Math.PI);
        const cellSlope = Math.max(stepSlopeDeg, grid.slopes[nIdx]);

        // Hard limit on steep inclines unless start/goal itself is on steep ground
        const nearEndpoints =
          Math.hypot(nx - ex, nz - ez) < 3 || Math.hypot(nx - sx, nz - sz) < 3;
        if (cellSlope > slopeLimit && !nearEndpoints) continue;

        // Multi-factor EVA cost function
        let penalty = 1.0;

        // Slope penalty: mild below 10°, steep rise above 12°
        if (cellSlope > 15) {
          penalty += (cellSlope - 15) * 1.4 + 2.2;
        } else if (cellSlope > 10) {
          penalty += (cellSlope - 10) * 0.35;
        }

        // Loose dust / low thermal inertia penalty (< 250 TIU)
        const ti = grid.thermalInertia[nIdx];
        if (ti < 260) {
          penalty += ((260 - ti) / 150) * 1.8;
        }

        // Boulder hazard penalty
        const boulder = grid.boulders[nIdx];
        if (boulder > 0.45) {
          penalty += (boulder - 0.45) * 3.0;
        }

        // Optional radiation shelter weighting
        if (prioritizeShelter) {
          const radNorm = Math.max(0, (grid.radiation[nIdx] - 0.25) / 0.45);
          penalty += radNorm * 1.65;
        }

        const tentativeG = gScore[curr.idx] + horizDist * penalty;
        if (tentativeG < gScore[nIdx]) {
          cameFrom[nIdx] = curr.idx;
          gScore[nIdx] = tentativeG;
          const hCost = Math.hypot(ex - nx, ez - nz) * grid.cellSize;
          heap.push({ idx: nIdx, f: tentativeG + hCost });
        }
      }
    }

    return null;
  };

  let usedFallback = false;
  let rawPath = runAStar(maxSlopeLimitDeg);
  if (!rawPath) {
    usedFallback = true;
    rawPath = runAStar(28);
  }
  if (!rawPath || rawPath.length < 2) return null;

  // Subsample slightly & smooth Y/XZ gently while preserving terrain contact
  const rawPoints: RoutePoint[] = rawPath.map((idx) => {
    const gx = idx % N;
    const gz = Math.floor(idx / N);
    const x = -grid.halfSpan + gx * grid.cellSize;
    const z = -grid.halfSpan + gz * grid.cellSize;
    return {
      x,
      y: grid.heights[idx],
      z,
      slopeDeg: grid.slopes[idx],
      radiationMsv: grid.radiation[idx],
      thermalInertia: grid.thermalInertia[idx],
    };
  });

  // Gentle 1-pass Chaikin-like smoothing on XZ, keeping terrain-faithful elevation
  const points: RoutePoint[] = [rawPoints[0]];
  for (let i = 1; i < rawPoints.length - 1; i++) {
    const prev = rawPoints[i - 1];
    const curr = rawPoints[i];
    const next = rawPoints[i + 1];
    points.push({
      x: prev.x * 0.2 + curr.x * 0.6 + next.x * 0.2,
      y: prev.y * 0.2 + curr.y * 0.6 + next.y * 0.2,
      z: prev.z * 0.2 + curr.z * 0.6 + next.z * 0.2,
      slopeDeg: curr.slopeDeg,
      radiationMsv: curr.radiationMsv,
      thermalInertia: curr.thermalInertia,
    });
  }
  points.push(rawPoints[rawPoints.length - 1]);

  let totalDistanceM = 0;
  let maxSlopeDeg = 0;
  let slopeSum = 0;
  let doseSum = 0;
  let hazardSegments = 0;

  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1];
    const b = points[i];
    const segLen = Math.hypot(b.x - a.x, b.y - a.y, b.z - a.z);
    totalDistanceM += segLen;
    if (b.slopeDeg > maxSlopeDeg) maxSlopeDeg = b.slopeDeg;
    slopeSum += b.slopeDeg;
    if (b.slopeDeg > 14) hazardSegments++;
  }

  const avgSlopeDeg = slopeSum / Math.max(1, points.length - 1);
  // Astronaut Marswalk speed ~0.85 m/s (approx 51 m/min) on moderate slopes
  const speedMPerMin = Math.max(28, 52 - avgSlopeDeg * 1.2);
  const estimatedMinutes = totalDistanceM / speedMPerMin;

  // Oxygen burn: ~0.16% per min baseline + slope/dust metabolic exertion factor
  const oxygenCostPct = Math.min(99, estimatedMinutes * (0.16 + avgSlopeDeg * 0.012));

  // Cumulative dose during EVA (mSv)
  for (let i = 0; i < points.length; i++) {
    doseSum += points[i].radiationMsv;
  }
  const avgRadDay = doseSum / points.length;
  const cumulativeDoseMsv = (avgRadDay / 1440) * estimatedMinutes;

  return {
    points,
    totalDistanceM,
    maxSlopeDeg,
    avgSlopeDeg,
    estimatedMinutes,
    oxygenCostPct,
    cumulativeDoseMsv,
    hazardSegments,
    usedFallbackSlopeRelax: usedFallback,
  };
}

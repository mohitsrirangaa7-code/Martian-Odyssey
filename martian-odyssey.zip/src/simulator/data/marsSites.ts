export type SiteId = 'jezero' | 'candor';

export type OverlayLayerId = 'natural' | 'topography' | 'radiation' | 'thermal';

export interface MarsPoi {
  id: string;
  name: string;
  category: 'science' | 'shelter' | 'habitat' | 'hazard';
  subtitle: string;
  description: string;
  x: number; // world meters (-280 .. +280)
  z: number; // world meters (-280 .. +280)
  mineralSignature: string;
  thermalInertia: number; // J m^-2 K^-1 s^-1/2
  radiationMsvDay: number;
  instrumentSource: string;
}

export interface MarsSiteConfig {
  id: SiteId;
  name: string;
  region: string;
  coordinates: string;
  latitudeDeg: number;
  baseElevationM: number;
  missionRef: string;
  summary: string;
  terrainScaleM: number; // total width/depth in meters (e.g. 600m x 600m local EVA sector)
  habitatPos: { x: number; z: number };
  mavPos: { x: number; z: number };
  solarPos: { x: number; z: number };
  commsPos: { x: number; z: number };
  defaultTargetId: string;
  pois: MarsPoi[];
}

export const MARS_SITES: Record<SiteId, MarsSiteConfig> = {
  jezero: {
    id: 'jezero',
    name: 'Jezero Crater',
    region: 'Western Isidis Rim',
    coordinates: '18.44° N, 77.45° E',
    latitudeDeg: 18.44,
    baseElevationM: -2560,
    missionRef: 'MRO HiRISE · Perseverance · CRISM · USGS',
    summary:
      'Ancient paleolake basin featuring the western Neretva Vallis inlet and fan delta, shoreline Margin Carbonate unit, Séítah olivine-dune trough, and Belva Crater.',
    terrainScaleM: 600,
    habitatPos: { x: 8, z: 18 },
    mavPos: { x: 54, z: 32 },
    solarPos: { x: -22, z: 48 },
    commsPos: { x: 28, z: -12 },
    defaultTargetId: 'jezero-delta',
    pois: [
      {
        id: 'jezero-hab',
        name: 'Octavia E. Butler Outpost',
        category: 'habitat',
        subtitle: 'Máaz Crater-Floor Landing Hub',
        description:
          'Primary EVA staging hub at Octavia E. Butler Landing on the consolidated Máaz basaltic floor (<4° grade), with clear sightlines NW to Neretva Delta and SE to Belva Crater.',
        x: 8,
        z: 18,
        mineralSignature: 'Consolidated Máaz Basalt',
        thermalInertia: 545,
        radiationMsvDay: 0.64,
        instrumentSource: 'HiRISE DTM / MRO',
      },
      {
        id: 'jezero-delta',
        name: 'Neretva Fan Delta',
        category: 'science',
        subtitle: 'NW Inlet · Phyllosilicate Clays',
        description:
          'Terraced sedimentary delta spreading east-southeast from the breached western Neretva Vallis river gorge. Rich in Fe/Mg-smectite lacustrine mudstones.',
        x: -88,
        z: -56,
        mineralSignature: 'Fe/Mg-Smectite Clays',
        thermalInertia: 495,
        radiationMsvDay: 0.61,
        instrumentSource: 'CRISM / Perseverance',
      },
      {
        id: 'jezero-carbonate',
        name: 'Margin Carbonate Unit',
        category: 'science',
        subtitle: 'Western Inner Rim Shoreline',
        description:
          'Fractured Mg-carbonate shoreline crust hugging the inner western crater rim just south of Neretva Vallis; firm high-TIU bedrock for safe EVA footing.',
        x: -162,
        z: -24,
        mineralSignature: 'Mg-Carbonate + Olivine',
        thermalInertia: 655,
        radiationMsvDay: 0.66,
        instrumentSource: 'CRISM / THEMIS',
      },
      {
        id: 'jezero-shelter',
        name: 'Belva Crater Wall Alcove',
        category: 'shelter',
        subtitle: 'SE Cross-Section & RAD Shelter',
        description:
          '900 m-class impact crater northeast of Séítah exposing dipping delta/floor breccia beds. Recessed western crater wall blocks ~52% of sky-view cosmic radiation.',
        x: 128,
        z: 58,
        mineralSignature: 'Fractured Rim Breccia',
        thermalInertia: 695,
        radiationMsvDay: 0.32,
        instrumentSource: 'RAD Shielding Model',
      },
      {
        id: 'jezero-dunes',
        name: 'Séítah Olivine & Dune Field',
        category: 'hazard',
        subtitle: 'Southern Low-TIU Sand Trap',
        description:
          'Low-relief olivine-cumulate outcrop south of Octavia Landing mantled by deep aeolian sand ripples (145 TIU). High wheel/boot sinkage hazard.',
        x: -12,
        z: 124,
        mineralSignature: 'Olivine Sand & Dust',
        thermalInertia: 145,
        radiationMsvDay: 0.69,
        instrumentSource: 'THEMIS Night IR',
      },
    ],
  },
  candor: {
    id: 'candor',
    name: 'Candor Chasma',
    region: 'Central Valles Marineris',
    coordinates: '5.95° S, 285.10° E',
    latitudeDeg: -5.95,
    baseElevationM: -4250,
    missionRef: 'USGS SIM 3359 · MRO HiRISE · CRISM · MOLA',
    summary:
      'Deep interconnected trough of central Valles Marineris bounded by the Ophir–Candor north escarpment, western Ceti Mensa, and eastern sulfate-capped Candor Mensa.',
    terrainScaleM: 600,
    habitatPos: { x: -128, z: 96 },
    mavPos: { x: -172, z: 124 },
    solarPos: { x: -96, z: 128 },
    commsPos: { x: -146, z: 68 },
    defaultTargetId: 'candor-mesa',
    pois: [
      {
        id: 'candor-hab',
        name: 'West Candor Floor Outpost',
        category: 'habitat',
        subtitle: 'SW Canyon-Floor Staging Base',
        description:
          'Anchored on scoured basaltic floor strata in western Candor Chasma (-4,250 m MOLA datum), framing Ceti Mensa to the northeast and Candor Mensa to the east.',
        x: -128,
        z: 96,
        mineralSignature: 'Consolidated Canyon Basalt',
        thermalInertia: 565,
        radiationMsvDay: 0.53,
        instrumentSource: 'HiRISE / MOLA',
      },
      {
        id: 'candor-hematite',
        name: 'Ceti Mensa Layered Block',
        category: 'science',
        subtitle: 'West Candor · 5.73° S, 283.70° E',
        description:
          'Western Candor interior layered deposit exposing older wet-playa sandstones, hydrated clays, and crystalline hematite along its southern bench.',
        x: -54,
        z: -26,
        mineralSignature: 'Hematite + Hydrated Clays',
        thermalInertia: 710,
        radiationMsvDay: 0.58,
        instrumentSource: 'USGS SIM 3359 / CRISM',
      },
      {
        id: 'candor-mesa',
        name: 'Candor Mensa Sulfates',
        category: 'science',
        subtitle: 'East Candor · 6.26° S, 286.48° E',
        description:
          'Two-tier eastern ILD mesa with parallel monohydrated sulfate lower ledges capped unconformably by bright polyhydrated sulfate beds.',
        x: 88,
        z: 32,
        mineralSignature: 'Polyhydrated Sulfates',
        thermalInertia: 640,
        radiationMsvDay: 0.62,
        instrumentSource: 'USGS / CRISM Spectral',
      },
      {
        id: 'candor-shelter',
        name: 'Ophir-Candor North Alcove',
        category: 'shelter',
        subtitle: 'North Wall Spur-and-Gully Refuge',
        description:
          'Deeply incised chasm wall separating Ophir and Candor Chasmas, masking >64% of sky-view cosmic radiation and solar particle flux.',
        x: 8,
        z: -144,
        mineralSignature: 'Noachian Wallrock Breccia',
        thermalInertia: 750,
        radiationMsvDay: 0.24,
        instrumentSource: 'RAD Shielding Model',
      },
      {
        id: 'candor-dunes',
        name: 'East Ceti Aeolian Dune Sheet',
        category: 'hazard',
        subtitle: 'SE Low-TIU Sand Sheet',
        description:
          'Younger dark basaltic sand sheet extending southeast of Ceti Mensa (155 TIU), forming unstable slip-faces and boot-sinkage traps.',
        x: 16,
        z: 112,
        mineralSignature: 'Loose Aeolian Sand',
        thermalInertia: 155,
        radiationMsvDay: 0.57,
        instrumentSource: 'USGS SIM 3359 / THEMIS',
      },
    ],
  },
};

export const SITE_LIST: MarsSiteConfig[] = [
  MARS_SITES.jezero,
  MARS_SITES.candor,
];
